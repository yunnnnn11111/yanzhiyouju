#!/usr/bin/env python3
"""言之有据 助农溢价值工作台 —— 本地服务

    python app.py            # 默认 http://127.0.0.1:8000
    python app.py 8123       # 指定端口

零第三方依赖（Python 3.10+）。只有 Python 标准库。
"""

from __future__ import annotations

import json
import mimetypes
import os
import sys
import traceback
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from core import compliance, evidence as gate_mod, ledger, llm, prompts, web_extract  # noqa: E402

WEB_DIR = ROOT / "web"
DATA_DIR = ROOT / "data"
PRODUCT_DIR = DATA_DIR / "products"

mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("text/css", ".css")


# ------------------------------------------------------------------ 业务辅助

class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def load_product(pid: str) -> dict:
    if not PRODUCT_DIR.exists():
        raise ApiError(500, "产品目录不存在")
    for f in sorted(PRODUCT_DIR.glob("*.json")):
        data = json.loads(f.read_text(encoding="utf-8"))
        if data.get("id") == pid or f.stem == pid:
            return data
    raise ApiError(404, f"未找到产品档案：{pid}")


def list_products() -> list[dict]:
    out = []
    for f in sorted(PRODUCT_DIR.glob("*.json")):
        d = json.loads(f.read_text(encoding="utf-8"))
        p = d.get("product", {})
        out.append(
            {
                "id": d.get("id"),
                "name": p.get("name"),
                "origin": p.get("origin"),
                "price": p.get("price"),
                "org": d.get("org"),
                "operator": d.get("operator"),
                "evidence_provided": sum(1 for e in d.get("evidence", []) if e.get("provided")),
                "evidence_total": len(d.get("evidence", [])),
            }
        )
    return out


def apply_evidence(product: dict, overrides: dict | None) -> list[dict]:
    evs = []
    for e in product.get("evidence", []):
        item = dict(e)
        if overrides and e["type"] in overrides:
            item["provided"] = bool(overrides[e["type"]])
            if overrides[e["type"]] and not item.get("source"):
                item["source"] = "本次运行人工指定为已提供（需在归档时核验原件）"
        evs.append(item)
    return evs


def product_brief(p: dict) -> str:
    pr = p["product"]
    return "\n".join(
        [
            f"- 产品：{pr['name']}（{pr['category']}）",
            f"- 产地：{pr['origin']}",
            f"- 品种：{pr['variety']}",
            f"- 规格：{pr['spec']}",
            f"- 售价：{pr['price']}；同类竞品：{pr['competitor_price']}",
            f"- 采收与贮藏：{pr['harvest']}",
            f"- 种植与加工工艺：{pr['process']}",
            f"- 目标人群：{pr['target_audience']}",
            f"- 现有草稿（供参考，含未证实表述）：{p['content_draft']['body']}",
        ]
    )


def evidence_brief(evs: list[dict]) -> str:
    if not evs:
        return "（无）"
    return "\n".join(
        f"- {e['label']}｜{'已提供' if e.get('provided') else '未提供'}｜{e.get('detail', '')}"
        for e in evs
    )


def demo_claims(version: str) -> dict:
    return {"v1": llm.DEMO_CLAIMS_V1, "v2": llm.DEMO_CLAIMS_V2}.get(version, llm.DEMO_CLAIMS)


def web_url_for(product: dict) -> str:
    """优先使用配置中的网页地址；没有时从产品证据中找公开来源。"""
    cfg = llm.load_config()
    configured = (cfg.get("web_url") or "").strip()
    if configured:
        return configured
    for evidence in product.get("evidence", []):
        url = evidence.get("url", "")
        if url.startswith(("http://", "https://")):
            return url
    return llm.DEFAULT_WEB_URL


def web_claims(product: dict, page: web_extract.WebPage | None) -> dict:
    """根据产品档案与公开网页提取结果生成保守的本地主张。"""
    pr = product["product"]
    source_title = page.title if page else "未成功读取公开网页"
    refs = web_extract.find_references(page) if page else []
    prices = web_extract.find_prices(page) if page else []
    source_note = f"公开网页：{source_title[:100]}"
    if page:
        source_note += f"（抓取时间 {page.fetched_at}）"
    claims = [
        {
            "claim": f"产自{pr['origin']}"[:60],
            "why": f"产品档案与公开网页来源可交叉核验。{source_note}",
            "required_evidence": ["GI_CERT", "ORIGIN_PROOF"],
            "evidence_hint": "核验地理标志保护范围文件、地块记录及公开网页来源",
            "risk": "low",
        },
        {
            "claim": f"{pr['variety']}，规格为{pr['spec']}"[:60],
            "why": "规格信息来自产品档案，网页提取结果只作为公开来源线索。",
            "required_evidence": ["ORIGIN_PROOF"],
            "evidence_hint": "补充批次、规格与采摘记录，核对网页展示信息",
            "risk": "low",
        },
        {
            "claim": "套袋、去袋、摘叶转果、铺反光膜等工艺可被记录核验",
            "why": "产品档案给出了工艺描述，网页抓取用于定位公开标准或页面依据。",
            "required_evidence": ["PROCESS_RECORD"],
            "evidence_hint": "作业时间记录、果园照片和对应标准条款",
            "risk": "low",
        },
        {
            "claim": (f"公开页面提取到的标准线索：{'、'.join(refs[:3])}"
                      if refs else "公开页面提供了可追溯的标准来源线索"),
            "why": "这是网页提取结果，不等同于检测报告、认证证书或产品批次证明。",
            "required_evidence": ["GI_CERT"],
            "evidence_hint": "打开来源网页核对标准原文，并补充与本批产品对应的证明材料",
            "risk": "medium",
        },
        {
            "claim": (f"售价为{pr['price']}，网页抓取到价格线索：{'、'.join(prices[:3])}"
                      if prices else f"售价为{pr['price']}，需以当前商品页为准"),
            "why": "价格来自产品档案或公开网页提取，发布前应确认抓取时间与商品规格一致。",
            "required_evidence": ["PRICE_REF"],
            "evidence_hint": "保存同规格商品页链接、截图与抓取时间",
            "risk": "medium",
        },
    ]
    return {"claims": claims}


def local_content(product: dict, claims: list[dict], page: web_extract.WebPage | None,
                  source_url: str | None = None) -> dict:
    """不调用模型，基于已通过门禁的主张生成三种基础文案。"""
    pr = product["product"]
    source = source_url or (page.url if page else web_url_for(product))
    items = [c["claim"] for c in claims]
    lines = [f"{i + 1}. {value}" for i, value in enumerate(items)]
    detail = "\n".join([
        f"一、{pr['name']}",
        "\n".join(lines[:2]) or "本次没有通过门禁的主张。",
        "",
        "二、产地与工艺",
        "；".join(items[2:4]) or "相关信息待补充证据。",
        "",
        "三、规格与价格",
        f"{pr['spec']}；{pr['price']}。发布前请核对商品页当前信息。",
        "",
        f"来源网页：{source}",
    ])
    oral = f"这是{pr['name']}。" + "。".join(items[:3]) + f"。规格为{pr['spec']}。详情请查看来源网页：{source}"
    social = f"{pr['name']}：" + "；".join(items[:3]) + f"。规格 {pr['spec']}，价格 {pr['price']}。来源：{source}"
    return {"detail_page": detail, "oral_script": oral, "social_post": social}


def normalize_claims(raw: dict) -> list[dict]:
    items = raw.get("claims") or []
    out = []
    for i, c in enumerate(items):
        if not isinstance(c, dict):
            continue
        claim = str(c.get("claim") or "").strip()
        if not claim:
            continue
        req = c.get("required_evidence") or []
        if isinstance(req, str):
            req = [req]
        req = [r for r in req if isinstance(r, str) and r in gate_mod.EVIDENCE_TYPES]
        out.append(
            {
                "id": f"C{len(out) + 1}",
                "claim": claim,
                "why": str(c.get("why") or "").strip(),
                "required_evidence": req,
                "evidence_hint": str(c.get("evidence_hint") or "").strip(),
                "risk": c.get("risk") if c.get("risk") in ("low", "medium", "high") else "medium",
            }
        )
    return out


# ------------------------------------------------------------------ 各接口

def api_generate(body: dict) -> dict:
    pid = body.get("product_id")
    if not pid:
        raise ApiError(400, "缺少 product_id")
    product = load_product(pid)
    evs = apply_evidence(product, body.get("evidence_overrides"))

    version = body.get("prompt_version") or prompts.PROMPT_REGISTRY["claim_gen"]["current"]
    if version not in [v["version"] for v in prompts.PROMPT_REGISTRY["claim_gen"]["versions"]]:
        raise ApiError(400, f"不存在的提示词版本：{version}")

    user_text, ver_used = prompts.render(
        "claim_gen", version, product=product_brief(product), evidence=evidence_brief(evs)
    )
    llm_error = None
    fallback = False
    usage = None
    page = None
    cfg = llm.public_config()
    if not cfg["configured"] and ver_used == "v3":
        source_url = (body.get("web_url") or web_url_for(product)).strip()
        try:
            page = web_extract.fetch(source_url)
        except web_extract.WebExtractError as exc:
            raise ApiError(502, f"无法从公开网页提取数据：{exc}") from exc
        raw = web_claims(product, page)
        user_text = f"联网网页提取：{page.title}｜{page.url}｜抓取时间 {page.fetched_at}"
        res = {
            "ok": False,
            "demo": False,
            "web": True,
            "elapsed": 0.0,
            "model": "本地网页提取",
            "source": page.url,
        }
    elif not cfg["configured"]:
        raw = demo_claims(ver_used)
        res = {"ok": False, "demo": True, "elapsed": 0.0, "model": "历史版本样例"}
    else:
        res = llm.chat(prompts.SYSTEM_CLAIM, user_text, temperature=0.4)
        elapsed = res.get("elapsed")
        if res["ok"]:
            parsed = llm.parse_json_content(res["content"])
            if parsed and parsed.get("claims"):
                raw = parsed
            else:
                llm_error = "模型返回内容无法解析为约定的 JSON 结构。"
                fallback = True
                raw = demo_claims(ver_used)
            usage = res.get("usage")
        elif res.get("demo"):
            raw = demo_claims(ver_used)
            elapsed = 0.0
        else:
            llm_error = res.get("error", "模型调用失败")
            fallback = True
            raw = demo_claims(ver_used)

    elapsed = res.get("elapsed")
    model = None
    model = res.get("model")

    claims = normalize_claims(raw)
    if not claims:
        raise ApiError(502, "模型没有返回可用的价值主张，请调整产品档案后重试")

    gated = gate_mod.run_gate(claims, evs)

    mode = "web" if res.get("web") else ("live" if res["ok"] else ("demo" if res.get("demo") else "fallback"))

    rec = ledger.create(
        {"id": product["id"], "name": product["product"]["name"], "price": product["product"]["price"],
         "region": product["product"]["origin"], "evidence": evs},
        mode,
        {"claim_gen": ver_used},
    )
    web_snapshot = None
    if page:
        web_snapshot = {
            "url": page.url,
            "title": page.title,
            "fetched_at": page.fetched_at,
            "status": page.status,
            "text": page.text[:6000],
            "prices": web_extract.find_prices(page),
            "references": web_extract.find_references(page),
        }
    ledger.update(rec["id"], {"claims": gated["claims"], "gate_summary": gated["summary"],
                               "web_source": web_snapshot})
    ledger.add_stage(rec["id"], "① 主张生成", {
        "model": model or cfg["model"],
        "source": page.url if page else None,
        "prompt_version": ver_used,
        "claims": len(gated["claims"]),
        "elapsed": elapsed,
        "usage": usage,
        "llm_error": llm_error,
    })
    ledger.add_stage(rec["id"], "② 证据门禁", {
        "passed": gated["summary"]["passed"],
        "blocked": gated["summary"]["blocked"],
        "provided_evidence": gated["provided_count"],
        "gaps": len(gated["evidence_gaps"]),
    })

    return {
        "ok": True,
        "record_id": rec["id"],
        "mode": mode,
        "demo": False if res.get("web") else not res["ok"],
        "fallback": fallback,
        "llm_error": llm_error,
        "prompt_version": ver_used,
        "prompt_text": user_text,
        "claims": gated["claims"],
        "summary": gated["summary"],
        "evidence_gaps": gated["evidence_gaps"],
        "evidence": evs,
        "product": product,
        "usage": usage,
        "elapsed": elapsed,
        "model": model or cfg["model"],
        "web_source": web_snapshot,
    }


def api_content(body: dict) -> dict:
    rec_id = body.get("record_id")
    rec = ledger.get(rec_id) if rec_id else None
    if not rec:
        raise ApiError(404, "运行记录不存在，请先生成价值主张")

    adopted = set(body.get("adopted") or [])
    claims = [c for c in rec["claims"] if c["id"] in adopted]
    if not claims:
        raise ApiError(400, "请至少勾选一条价值主张")

    allowed = {c["id"] for c in rec["claims"] if c["gate"] == "PASS"}
    overridden = {d["target"] for d in rec["decisions"] if d["action"] == "gate_override"}
    illegal = [c["id"] for c in claims if c["id"] not in allowed and c["id"] not in overridden]
    if illegal:
        raise ApiError(403, f"以下主张未通过证据门禁且未走人工豁免：{', '.join(illegal)}")

    product = load_product(rec["product_id"])
    version = body.get("content_version") or prompts.PROMPT_REGISTRY["content_gen"]["current"]
    claim_text = "\n".join(
        f"{i + 1}. {c['claim']}（依据：{'、'.join(gate_mod.EVIDENCE_TYPES[r]['label'] for r in c['required_evidence'])}）"
        for i, c in enumerate(claims)
    )
    user_text, ver_used = prompts.render(
        "content_gen", version, product=product_brief(product), claims=claim_text
    )
    llm_error = None
    fallback = False
    usage = None
    cfg = llm.public_config()
    web_source = rec.get("web_source") or {}
    web_mode = rec.get("mode") == "web" or not cfg["configured"]
    if web_mode:
        source_url = (web_source.get("url") or web_url_for(product)).strip()
        content = local_content(product, claims, None, source_url)
        mode = "web"
    else:
        res = llm.chat(prompts.SYSTEM_CONTENT, user_text, temperature=0.7)
        if res["ok"]:
            parsed = llm.parse_json_content(res["content"])
            if parsed and parsed.get("detail_page"):
                content = {
                    "detail_page": str(parsed.get("detail_page") or ""),
                    "oral_script": str(parsed.get("oral_script") or ""),
                    "social_post": str(parsed.get("social_post") or ""),
                }
            else:
                llm_error = "模型返回内容无法解析，已回退到演示样例。"
                fallback = True
                content = dict(llm.DEMO_CONTENT)
            usage = res.get("usage")
        elif res.get("demo"):
            content = dict(llm.DEMO_CONTENT)
        else:
            llm_error = res.get("error")
            fallback = True
            content = dict(llm.DEMO_CONTENT)
        mode = "live" if res["ok"] else ("demo" if res.get("demo") else "fallback")

    ledger.update(rec_id, {"content": content, "adopted_claim_ids": sorted(adopted), "mode": mode})
    ledger.add_stage(rec_id, "③ 内容产出", {
        "prompt_version": ver_used,
        "adopted_claims": sorted(adopted),
        "char_counts": {k: len(v) for k, v in content.items()},
        "usage": usage,
        "llm_error": llm_error,
    })

    return {
        "ok": True,
        "content": content,
        "mode": mode,
        "demo": False if web_mode else not res["ok"],
        "fallback": fallback,
        "llm_error": llm_error,
        "prompt_version": ver_used,
        "prompt_text": user_text,
        "usage": usage,
        "web_source": web_source if web_mode else None,
    }


REVIEW_SYSTEM = prompts.SYSTEM_COMPLIANCE


def llm_review(text: str, a_result: dict) -> dict:
    cfg = llm.public_config()
    if not cfg["configured"]:
        return {
            "ok": True,
            "mode": "web",
            "demo": False,
            "model": "本地规则引擎（通道 B 未执行）",
            "findings": [],
            "overall": "未配置模型，通道 B 未执行；本次结果以本地规则通道 A 为准。",
        }

    covered = [h["matched"] for h in a_result["hits"]]
    user = (
        f"【待审文本】\n{text}\n\n"
        f"【本地规则库已命中的表述，不要重复报告】\n{json.dumps(covered, ensure_ascii=False)}\n\n"
        "【请补充以下方向的风险】\n"
        "1. 规则库覆盖不到的长尾表述：暗示性功效、打擦边球的人群指向、隐性比较、夸大场景；\n"
        "2. 同一含义换了说法的绝对化表达；\n"
        "3. 数据与引证的语境问题：数字缺单位、对比对象不明、引用标准版本过旧、转述标准时失真；\n"
        "4. 图文组合可能造成的误解。\n\n"
        '输出 JSON：{"findings":[{"quote":"原文片段","category":"类别","severity":"high|medium|low",'
        '"why":"为什么有风险","suggestion":"具体改法"}],"overall":"一句话结论"}'
    )
    res = llm.chat(REVIEW_SYSTEM, user, temperature=0.2)
    if not res["ok"]:
        return {"ok": False, "mode": "error", "demo": False, "error": res.get("error"),
                "findings": [], "overall": "通道 B 未执行"}
    parsed = llm.parse_json_content(res["content"]) or {}
    findings = []
    for f in parsed.get("findings") or []:
        if not isinstance(f, dict) or not f.get("quote"):
            continue
        findings.append({
            "quote": str(f.get("quote"))[:120],
            "category": str(f.get("category") or "语境风险"),
            "severity": f.get("severity") if f.get("severity") in ("high", "medium", "low") else "medium",
            "why": str(f.get("why") or ""),
            "suggestion": str(f.get("suggestion") or ""),
        })
    return {
        "ok": True,
        "mode": "live",
        "demo": False,
        "model": res.get("model"),
        "findings": findings,
        "overall": str(parsed.get("overall") or ""),
        "usage": res.get("usage"),
        "elapsed": res.get("elapsed"),
    }


def api_compliance(body: dict) -> dict:
    text = (body.get("text") or "").strip()
    if not text:
        raise ApiError(400, "待审文本为空")
    if len(text) > 20000:
        raise ApiError(400, "文本过长（上限 20000 字）")

    evs = []
    rec_id = body.get("record_id")
    rec = ledger.get(rec_id) if rec_id else None
    if rec:
        product = load_product(rec["product_id"])
        evs = apply_evidence(product, body.get("evidence_overrides"))
    elif body.get("product_id"):
        product = load_product(body["product_id"])
        evs = apply_evidence(product, body.get("evidence_overrides"))

    a = compliance.review(text, evs)
    b = None
    if body.get("with_llm", True):
        try:
            b = llm_review(text, a)
        except Exception as e:  # 通道 B 失败绝不影响通道 A
            b = {"ok": False, "mode": "error", "demo": False, "error": f"{type(e).__name__}: {e}",
                 "findings": [], "overall": "通道 B 异常"}

    merged = merge_findings(a, b)
    if rec:
        ledger.update(rec_id, {"compliance": {"A": a, "B": b, "merged": merged, "text": text}})
        revisit = bool(rec.get("compliance"))
        ledger.add_stage(rec_id, "④′ 整改复审" if revisit else "④ 合规审查", {
            "channel_a_hits": len(a["hits"]),
            "channel_a_score": a["score"],
            "channel_b_findings": len((b or {}).get("findings") or []),
            "level": a["level"],
        })

    return {"ok": True, "A": a, "B": b, "merged": merged, "text": text}


def merge_findings(a: dict, b: dict | None) -> dict:
    """把两条通道的结论合到一张表上，并标出重复项。"""
    rows = []
    for h in a["hits"]:
        rows.append({
            "source": "A",
            "severity": h["severity"],
            "title": h["rule_name"],
            "quote": h["matched"],
            "detail": h["basis"],
            "advice": h["advice"],
            "rule_id": h["rule_id"],
            "evidence_note": h["evidence_note"],
            "dup": False,
        })
    for f in (b or {}).get("findings") or []:
        quote = f["quote"]
        dup = any(quote and (quote in r["quote"] or r["quote"] in quote) for r in rows if r["source"] == "A")
        rows.append({
            "source": "B",
            "severity": f["severity"],
            "title": f["category"],
            "quote": quote,
            "detail": f["why"],
            "advice": f["suggestion"],
            "rule_id": "",
            "evidence_note": "大模型补充，需人工确认",
            "dup": dup,
        })
    order = {"blocker": 0, "high": 1, "medium": 2, "low": 3, "notice": 4}
    rows.sort(key=lambda r: order.get(r["severity"], 5))
    return {
        "rows": rows,
        "total": len(rows),
        "by_source": {"A": sum(1 for r in rows if r["source"] == "A"),
                      "B": sum(1 for r in rows if r["source"] == "B")},
        "duplicates": sum(1 for r in rows if r["dup"]),
    }


def api_decision(body: dict) -> dict:
    rec_id = body.get("record_id")
    if not rec_id or not ledger.get(rec_id):
        raise ApiError(404, "运行记录不存在")
    action = body.get("action")
    valid = {"adopt_claim", "reject_claim", "gate_override", "content_edit",
             "compliance_override", "fix_compliance", "archive"}
    if action not in valid:
        raise ApiError(400, f"未知操作：{action}")
    reason = (body.get("reason") or "").strip()
    if action in ("gate_override", "compliance_override") and len(reason) < 4:
        raise ApiError(400, "强行放行必须填写不少于 4 个字的理由，并会被写入台账")

    decision = ledger.add_decision(
        rec_id, action, body.get("actor") or "运营", str(body.get("target") or ""),
        reason, body.get("before"), body.get("after"),
    )
    if action == "archive":
        ledger.update(rec_id, {"status": "已归档", "final_content": body.get("after"),
                               "archived_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
    return {"ok": True, "decision": decision, "record": ledger.get(rec_id)}


def build_export_md(rec: dict) -> str:
    A = (rec.get("compliance") or {}).get("A") or {}
    B = (rec.get("compliance") or {}).get("B") or {}
    content = rec.get("final_content") or rec.get("content") or {}
    lines = [
        f"# 运行案例 {rec['id']}",
        "",
        f"- 产品：{rec['product_name']}",
        f"- 运行时间：{rec['created_at']}",
        f"- 运行模式：{'真实模型调用' if rec['mode'] == 'live' else ('联网网页提取 + 本地规则' if rec['mode'] == 'web' else '演示模式（固定输出）')}",
        f"- 提示词版本：价值主张生成 {rec['prompt_versions'].get('claim_gen', '-')}",
        f"- 归档状态：{rec['status']}",
        "",
        "## 一、输入",
        "",
        f"产地：{rec['input_snapshot'].get('region', '')}｜售价：{rec['input_snapshot'].get('price', '')}",
        "",
        "| 证据类型 | 是否提供 | 来源 |",
        "| --- | --- | --- |",
    ]
    for e in rec["input_snapshot"].get("evidence", []):
        lines.append(f"| {e['label']} | {'已提供' if e['provided'] else '未提供'} | {e.get('source', '') or '—'} |")

    lines += ["", "## 二、处理过程", "", "| 阶段 | 时间 | 关键结果 |", "| --- | --- | --- |"]
    for s in rec.get("stages", []):
        detail = "；".join(f"{k}={v}" for k, v in s["detail"].items() if v not in (None, "", 0, [], {}))
        lines.append(f"| {s['stage']} | {s['at']} | {detail} |")

    lines += ["", "## 三、价值主张与证据门禁", "",
              "| 编号 | 主张 | 需要的证据 | 门禁 | 说明 |", "| --- | --- | --- | --- | --- |"]
    for c in rec.get("claims", []):
        need = "、".join(gate_mod.EVIDENCE_TYPES[r]["label"] for r in c.get("required_evidence", [])) or "未声明"
        lines.append(f"| {c['id']} | {c['claim']} | {need} | {'PASS' if c['gate'] == 'PASS' else 'BLOCK'} | {c.get('gate_reason', '')} |")

    gs = rec.get("gate_summary") or {}
    if gs:
        lines += ["", f"门禁小结：共 {gs.get('total')} 条，通过 {gs.get('passed')} 条，"
                      f"拦截 {gs.get('blocked')} 条，通过率 {gs.get('pass_rate')}%。"]

    lines += ["", "## 四、内容产出", ""]
    labels = {"detail_page": "商品详情页", "oral_script": "短视频口播稿", "social_post": "社群文案"}
    if isinstance(content, dict) and content:
        printed = False
        for k in ("detail_page", "oral_script", "social_post"):
            if content.get(k):
                lines += [f"### {labels[k]}", "", content[k], ""]
                printed = True
        for k, v in content.items():
            if k not in labels and v:
                lines += [f"### {k}", "", str(v), ""]
                printed = True
        if not printed:
            lines += ["（未产出内容）", ""]
    elif isinstance(content, str) and content.strip():
        lines += [content, ""]
    else:
        lines += ["（未产出内容）", ""]

    lines += ["## 五、合规审查（通道 A 本地规则引擎 + 通道 B 大模型长尾补充）", ""]
    if A:
        lines += [f"- 规则库版本：{A.get('ruleset_version')}", f"- A 通道风险分值：{A.get('score')}/100",
                  f"- 判定：{A.get('level_text')}", ""]
        if A.get("hits"):
            lines += ["| 规则 | 严重度 | 命中 | 依据 | 建议 |", "| --- | --- | --- | --- | --- |"]
            for h in A["hits"]:
                lines.append(f"| {h['rule_name']} | {h['severity']} | {h['matched']} | {h['basis']} | {h['advice']} |")
            lines.append("")
        if A.get("citations_ok"):
            lines.append(f"已标注出处的数据：{len(A['citations_ok'])} 处（按规则第四条视为合规引证）。")
            lines.append("")
    else:
        lines += ["（未执行合规审查）", ""]
    if B and B.get("findings"):
        lines += ["### B 通道补充", "", "| 类别 | 严重度 | 原文 | 风险 | 建议 |", "| --- | --- | --- | --- | --- |"]
        for f in B["findings"]:
            lines.append(f"| {f['category']} | {f['severity']} | {f['quote']} | {f['why']} | {f['suggestion']} |")
        lines.append("")

    lines += ["## 六、人工干预记录", ""]
    if rec.get("decisions"):
        lines += ["| # | 时间 | 操作人 | 动作 | 对象 | 理由 |", "| --- | --- | --- | --- | --- | --- |"]
        label = {"adopt_claim": "采纳主张", "reject_claim": "驳回主张", "gate_override": "门禁强行放行",
                 "content_edit": "人工修改文案", "compliance_override": "合规风险强制通过",
                 "fix_compliance": "标记整改完成", "archive": "归档发布"}
        for d in rec["decisions"]:
            lines.append(f"| {d['seq']} | {d['at']} | {d['actor']} | {label.get(d['action'], d['action'])} | "
                         f"{d['target']} | {d['reason'] or '—'} |")
        lines.append("")
    else:
        lines += ["（本次运行无人工干预记录）", ""]

    diffs = [d for d in rec.get("decisions", [])
             if isinstance(d.get("before"), str) or isinstance(d.get("after"), str)]
    if diffs:
        lines += ["### 人工修改前后对照（可溯源）", ""]
        action_label = {"content_edit": "人工修改文案", "fix_compliance": "整改后文案",
                        "gate_override": "强行放行说明", "compliance_override": "风险强制通过说明"}
        for d in diffs:
            lines += [f"**#{d['seq']} {action_label.get(d['action'], d['action'])}｜{d['target']}**", ""]
            if isinstance(d.get("before"), str) and d["before"]:
                lines += ["修改前：", "", "```text", d["before"], "```", ""]
            if isinstance(d.get("after"), str) and d["after"]:
                lines += ["修改后：", "", "```text", d["after"], "```", ""]

    lines += [
        "## 七、验证结果",
        "",
        f"- 归档状态：{rec['status']}",
        f"- 未通过门禁的主张：{gs.get('blocked', 0)} 条（已给出补证建议，补齐后可重新运行）",
        f"- 合规判定：{A.get('level_text', '未审查')}",
        f"- 导出时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "- 说明：本导出内容由系统按运行记录自动生成，未做任何美化修改。",
    ]
    return "\n".join(lines)


def api_export(body: dict) -> dict:
    rec = ledger.get(body.get("record_id", ""))
    if not rec:
        raise ApiError(404, "运行记录不存在")
    fmt = body.get("format", "md")
    if fmt == "json":
        return {"ok": True, "filename": f"{rec['id']}.json",
                "text": json.dumps(rec, ensure_ascii=False, indent=2),
                "mime": "application/json"}
    return {"ok": True, "filename": f"{rec['id']}.md", "text": build_export_md(rec), "mime": "text/markdown"}


def api_cases() -> dict:
    path = DATA_DIR / "cases.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    products = {p["id"]: p for p in list_products()}
    for c in data["cases"]:
        prod = products.get(c["product_id"])
        c["product_name"] = prod["name"] if prod else c["product_id"]
        if c["text_source"] == "v1_output":
            c["resolved_text"] = "\n".join(x["claim"] for x in llm.DEMO_CLAIMS_V1["claims"])
        elif c["text_source"] == "custom":
            c["resolved_text"] = c.get("custom_text", "")
        else:
            c["resolved_text"] = ""
    return data


# ------------------------------------------------------------------ HTTP

ROUTES_GET = {
    "/api/health": lambda q: {"ok": True, "service": "言之有据", "time": datetime.now().isoformat(timespec="seconds"),
                              "python": sys.version.split()[0]},
    "/api/config": lambda q: {"ok": True, **llm.public_config()},
    "/api/products": lambda q: {"ok": True, "products": list_products()},
    "/api/evidence-types": lambda q: {"ok": True, "types": [
        {"type": k, **v} for k, v in gate_mod.EVIDENCE_TYPES.items()]},
    "/api/compliance/rules": lambda q: {"ok": True, **compliance.rules_public()},
    "/api/prompts": lambda q: {"ok": True, "registry": {
        pid: prompts.history(pid) for pid in prompts.PROMPT_REGISTRY}},
    "/api/prompts/<id>": None,
    "/api/ledger": lambda q: {"ok": True, "records": ledger.list_summaries(), "stats": ledger.stats()},
    "/api/cases": lambda q: {"ok": True, **api_cases()},
}

ROUTES_POST = {
    "/api/config": lambda b: {"ok": True, **llm.save_config(b)},
    "/api/generate": api_generate,
    "/api/content": api_content,
    "/api/compliance": api_compliance,
    "/api/decision": api_decision,
    "/api/export": api_export,
}


class Handler(BaseHTTPRequestHandler):
    server_version = "YanZhiYouJu/1.0"

    def log_message(self, fmt, *args):  # 安静一点，只打错误
        if sys.stderr is not None and str(args[1] if len(args) > 1 else "").startswith("4"):
            sys.stderr.write("  %s\n" % (fmt % args))

    # -- 工具
    def _json(self, status: int, payload: dict):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path: Path):
        if not path.exists() or not path.is_file():
            self._json(404, {"ok": False, "error": "not found"})
            return
        data = path.read_bytes()
        ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        if path.suffix in (".js", ".css", ".html"):
            ctype += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    # -- GET
    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        if path == "/" or path == "/index.html":
            self._file(WEB_DIR / "index.html")
            return
        if path.startswith("/api/"):
            if path.startswith("/api/ledger/"):
                rec = ledger.get(path.rsplit("/", 1)[-1])
                if rec:
                    self._json(200, {"ok": True, "record": rec})
                else:
                    self._json(404, {"ok": False, "error": "记录不存在"})
                return
            if path.startswith("/api/prompts/"):
                pid = path.rsplit("/", 1)[-1]
                if pid in prompts.PROMPT_REGISTRY:
                    detail = prompts.history(pid)
                    detail["versions"] = [
                        v | {"prompt_text": next(x["prompt"] for x in prompts.PROMPT_REGISTRY[pid]["versions"]
                                                 if x["version"] == v["version"])}
                        for v in detail["versions"]
                    ]
                    self._json(200, {"ok": True, "prompt": detail})
                else:
                    self._json(404, {"ok": False, "error": "未知提示词"})
                return
            if path.startswith("/api/product/"):
                try:
                    p = load_product(path.rsplit("/", 1)[-1])
                    self._json(200, {"ok": True, "product": p})
                except ApiError as e:
                    self._json(e.status, {"ok": False, "error": e.message})
                return
            fn = ROUTES_GET.get(path)
            if fn:
                try:
                    self._json(200, fn(parsed.query))
                except ApiError as e:
                    self._json(e.status, {"ok": False, "error": e.message})
                except Exception as e:
                    traceback.print_exc()
                    self._json(500, {"ok": False, "error": f"{type(e).__name__}: {e}"})
                return
            self._json(404, {"ok": False, "error": "未知接口"})
            return
        rel = path.lstrip("/")
        target = (WEB_DIR / rel).resolve()
        if WEB_DIR.resolve() not in target.parents and target != WEB_DIR.resolve():
            self._json(403, {"ok": False, "error": "forbidden"})
            return
        self._file(target)

    # -- POST
    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        fn = ROUTES_POST.get(path)
        if not fn:
            self._json(404, {"ok": False, "error": "未知接口"})
            return
        try:
            length = int(self.headers.get("Content-Length") or 0)
            if length > 5 * 1024 * 1024:
                raise ApiError(413, "请求体过大")
            raw = self.rfile.read(length) if length else b"{}"
            body = json.loads(raw.decode("utf-8") or "{}")
        except ApiError as e:
            self._json(e.status, {"ok": False, "error": e.message})
            return
        except Exception:
            self._json(400, {"ok": False, "error": "请求体不是合法 JSON"})
            return
        try:
            self._json(200, fn(body))
        except ApiError as e:
            self._json(e.status, {"ok": False, "error": e.message})
        except Exception as e:
            traceback.print_exc()
            self._json(500, {"ok": False, "error": f"{type(e).__name__}: {e}"})


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    port = 8000
    if len(sys.argv) > 1 and sys.argv[1].isdigit():
        port = int(sys.argv[1])
    elif os.environ.get("PORT", "").isdigit():
        port = int(os.environ["PORT"])

    for attempt in range(20):
        try:
            httpd = ThreadingHTTPServer(("127.0.0.1", port + attempt), Handler)
            break
        except OSError:
            continue
    else:
        print("端口被占用，请手动指定端口：python app.py 8080")
        return

    cfg = llm.public_config()
    print()
    print("  言之有据 · 助农溢价值工作台")
    print("  " + "-" * 46)
    print(f"  访问地址   http://127.0.0.1:{httpd.server_address[1]}")
    print(f"  模型配置   {'已配置（real）' if cfg['configured'] else '未配置 API Key → 联网网页提取模式'}")
    print(f"  模型       {cfg['model']}")
    print(f"  提示词     价值主张生成 {prompts.PROMPT_REGISTRY['claim_gen']['current']} / "
          f"内容产出 {prompts.PROMPT_REGISTRY['content_gen']['current']}")
    print("  按 Ctrl+C 停止")
    print()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  已停止。")


if __name__ == "__main__":
    main()
