"""言之有据云端 WSGI 入口：账号、批次、证据、分析、合规与管理。"""
from __future__ import annotations

import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import threading
import time
import traceback
from collections import OrderedDict, deque
from datetime import datetime, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import unquote, urlsplit

import app
from core import account_store, api_client, audit_store, batch_store, channel_analysis, compliance, evidence as evidence_rules, prompts, retrieval_db, settings_store, web_extract, web_search, workflow
from core.cloud_context import DATA_ROOT, cleanup_guests, current_access, reset_access, set_access

ROOT = Path(__file__).resolve().parent
WEB_DIR = ROOT / "web"
COOKIE = "yzyj_session"
MAX_BODY = 12 * 1024 * 1024
USER_TTL = 30 * 24 * 3600
GUEST_TTL = 2 * 3600
LOCK = threading.RLock()
RATE_LOCK = threading.Lock()
RATE = OrderedDict()


def _load_secret() -> bytes:
    env = os.environ.get("SESSION_SECRET", "").encode("utf-8")
    if len(env) >= 24:
        return env
    path = DATA_ROOT / ".secrets" / "session.key"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        return path.read_bytes()
    value = secrets.token_bytes(48)
    path.write_bytes(value)
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return value


SECRET = _load_secret()


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _sign(value: str) -> str:
    return hmac.new(SECRET, value.encode("utf-8"), hashlib.sha256).hexdigest()


def _make_session(kind: str, subject: str) -> str:
    ttl = GUEST_TTL if kind == "guest" else USER_TTL
    version = int((account_store.get_user(subject) or {}).get("session_version", 0)) if kind == "user" else 0
    payload = f"{kind}:{subject}:{int(time.time()) + ttl}:{version}"
    return payload + ":" + _sign(payload)


def _read_session(value: str) -> dict | None:
    try:
        kind, subject, expires, version, signature = value.split(":", 4)
        payload = f"{kind}:{subject}:{expires}:{version}"
        if not hmac.compare_digest(signature, _sign(payload)):
            return None
        if int(expires) < int(time.time()) or kind not in ("user", "guest"):
            return None
        if kind == "user":
            user = account_store.get_user(subject)
            if not user or not user.get("active", True) or int(version) != int(user.get("session_version", 0)):
                return None
            return {"kind": "user", "subject": subject, "user": user,
                    "storage_id": account_store.storage_id(subject)}
        if not re.fullmatch(r"[a-f0-9]{48}", subject):
            return None
        return {"kind": "guest", "subject": subject,
                "user": {"id": "guest_" + subject, "username": "游客", "role": "guest"},
                "storage_id": subject}
    except (ValueError, TypeError):
        return None


def _cookie(value: str, max_age: int, environ) -> str:
    secure = "; Secure" if environ.get("wsgi.url_scheme") == "https" or environ.get("HTTP_X_FORWARDED_PROTO") == "https" else ""
    return f"{COOKIE}={value}; Path=/; HttpOnly; SameSite=Lax; Max-Age={max_age}{secure}"


def _identity(environ, create_guest: bool = False) -> tuple[dict | None, str | None]:
    try:
        cookies = SimpleCookie(environ.get("HTTP_COOKIE", ""))
        raw = cookies[COOKIE].value
        identity = _read_session(raw)
        if identity:
            return identity, None
    except (KeyError, ValueError):
        pass
    if create_guest and settings_store.public_settings()["features"].get("guest_analysis_enabled", True):
        sid = secrets.token_hex(24)
        value = _make_session("guest", sid)
        return _read_session(value), _cookie(value, GUEST_TTL, environ)
    return None, None


def _client_key(environ, identity: dict | None) -> str:
    if identity:
        return identity.get("kind", "anon") + ":" + identity.get("subject", "")
    forwarded = (environ.get("HTTP_X_FORWARDED_FOR") or "").split(",", 1)[0].strip()
    return "ip:" + (forwarded or environ.get("REMOTE_ADDR", "unknown"))


def _limit(environ, identity: dict | None) -> None:
    key = _client_key(environ, identity)
    with RATE_LOCK:
        now = time.monotonic()
        queue = RATE.setdefault(key, deque())
        RATE.move_to_end(key)
        while queue and queue[0] < now - 60:
            queue.popleft()
        if len(queue) >= 90:
            raise ApiError(429, "操作较频繁，请稍等一分钟再试")
        queue.append(now)
        while len(RATE) > 5000:
            RATE.popitem(last=False)


def _json_body(environ) -> dict:
    if environ.get("HTTP_X_REQUESTED_WITH") != "YanZhiYouJu":
        raise ApiError(403, "请从本应用页面提交操作")
    origin = environ.get("HTTP_ORIGIN")
    if origin and urlsplit(origin).netloc != environ.get("HTTP_HOST"):
        raise ApiError(403, "不允许跨站提交操作")
    try:
        length = int(environ.get("CONTENT_LENGTH") or "0")
    except ValueError as exc:
        raise ApiError(400, "请求长度无效") from exc
    if length < 0 or length > MAX_BODY:
        raise ApiError(413, "请求内容过大，请压缩照片或减少附件数量")
    try:
        body = json.loads(environ["wsgi.input"].read(length) or b"{}")
    except (ValueError, UnicodeError) as exc:
        raise ApiError(400, "请求不是有效 JSON") from exc
    if not isinstance(body, dict):
        raise ApiError(400, "请求内容必须是 JSON 对象")
    return body


def _require_user(identity: dict | None, pending_allowed: bool = False) -> dict:
    if not identity or identity.get("kind") != "user":
        raise ApiError(401, "请先注册或登录")
    user = identity["user"]
    if user.get("must_change_password") and not pending_allowed:
        raise ApiError(403, "首次登录或管理员重置密码后，请先修改密码")
    return user


def _require_admin(identity: dict | None) -> dict:
    user = _require_user(identity)
    if user.get("role") != "admin":
        raise ApiError(403, "仅管理员可操作")
    return user


def _match(pattern: str, path: str):
    return re.fullmatch(pattern, path)

# ---------------------------------------------------------------------------
# HTTP 响应、权限上下文与路由
# ---------------------------------------------------------------------------


def _features() -> dict:
    return settings_store.public_settings()["features"]


def _require_feature(name: str) -> None:
    if not _features().get(name, False):
        labels = {
            "guest_analysis_enabled": "游客分析",
            "web_collection_enabled": "公开网页采集",
            "export_enabled": "报告导出",
            "manual_override_enabled": "人工强制放行",
            "user_api_enabled": "用户自有 API",
        }
        raise ApiError(403, f"管理员已关闭{labels.get(name, name)}功能")


def _json_result(payload: dict, status: int = 200, headers: list[tuple[str, str]] | None = None):
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    merged = [
        ("Content-Type", "application/json; charset=utf-8"),
        ("Content-Length", str(len(raw))),
        ("Cache-Control", "no-store"),
    ]
    merged.extend(headers or [])
    return int(status), raw, merged


def _error_result(exc: Exception, status: int) -> tuple[int, bytes, list[tuple[str, str]]]:
    message = exc.message if isinstance(exc, ApiError) else str(exc)
    return _json_result({"ok": False, "error": message or "请求处理失败"}, status)


def _static(name: str) -> tuple[int, bytes, list[tuple[str, str]]]:
    path = (WEB_DIR / name).resolve()
    if WEB_DIR.resolve() not in path.parents or not path.is_file():
        return _error_result(ApiError(404, "页面资源不存在"), 404)
    raw = path.read_bytes()
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    if path.suffix in (".html", ".css", ".js", ".svg"):
        mime += "; charset=utf-8"
    headers = [
        ("Content-Type", mime),
        ("Content-Length", str(len(raw))),
        ("Cache-Control", "no-cache" if path.suffix == ".html" else "public, max-age=300"),
        ("X-Content-Type-Options", "nosniff"),
    ]
    return int(HTTPStatus.OK), raw, headers


def _identity_summary(identity: dict | None) -> dict:
    if not identity:
        return {"kind": "anonymous", "user": None, "storage": "none"}
    user = identity.get("user") or {}
    public = account_store.public_user(user) if identity.get("kind") == "user" else {
        "id": user.get("id"), "username": "游客", "role": "guest",
        "active": True, "must_change_password": False,
    }
    return {
        "kind": identity.get("kind"),
        "user": public,
        "storage": "account" if identity.get("kind") == "user" else "temporary",
        "session_notice": "游客结果临时保存 2 小时，不会形成长期历史。" if identity.get("kind") == "guest" else "",
    }


def _public_state(identity: dict | None) -> dict:
    data = settings_store.public_settings()
    user = (identity or {}).get("user") or {}
    out = {
        "ok": True,
        "identity": _identity_summary(identity),
        "features": data["features"],
        "data_sources": data["data_sources"],
        "platform_api": data["platform_api"],
        "api_config": api_client.public_config() if identity else None,
        "guest_ttl_seconds": GUEST_TTL,
        "disclaimer": "金额、销量和利润均为情景测算；系统不承诺成交、收益或法律绝对合规。",
    }
    if identity:
        out["stats"] = batch_store.stats_for_user(user)
    return out


def _owner_batch(identity: dict | None, batch_id: str, mutation: bool = False) -> dict:
    if not identity:
        raise ApiError(401, "请先建立会话")
    user = identity["user"]
    batch = batch_store.get(batch_id, user)
    if not batch:
        raise ApiError(404, "批次不存在或无权访问")
    if mutation and batch.get("owner_id") != user.get("id"):
        raise ApiError(403, "管理员可查看全部批次，但不能代替其他用户修改；请由批次所有者操作")
    return batch


def _change_session_cookie(user: dict, environ) -> str:
    value = _make_session("user", user["id"])
    return _cookie(value, USER_TTL, environ)


def _admin_only_payload(identity: dict | None) -> dict:
    admin = _require_admin(identity)
    users = account_store.list_users()
    return {
        "ok": True, "users": users,
        "stats": {
            "users": len(users),
            "active_users": sum(1 for u in users if u.get("active")),
            "admins": sum(1 for u in users if u.get("role") == "admin"),
            "batches": len(batch_store.list_all(1000)),
        },
        "acting_admin": account_store.public_user(admin),
    }


def _get(environ, path: str, identity: dict | None):
    query = environ.get("QUERY_STRING", "")

    if path in ("/", "/index.html"):
        return _static("index.html")
    if path in ("/app.js", "/styles.css", "/evidence-ui.js", "/favicon.svg"):
        return _static(path.lstrip("/"))
    if path == "/api/health":
        return _json_result({"ok": True, "service": "言之有据", "version": "2026-11-03-workbench-r6", "time": _now()})
    if path == "/api/auth/me":
        return _json_result(_public_state(identity))
    if path == "/api/api-config":
        if not identity:
            raise ApiError(401, "请先建立会话")
        return _json_result({"ok": True, "config": api_client.public_config(),
                             "features": _features()})
    if path == "/api/retrieval/status":
        return _json_result({"ok": True, **retrieval_db.stats(),
                             "notice": "案例库只保存公开网页快照，命中不等于事实通过。"})
    if path == "/api/batches":
        if not identity:
            raise ApiError(401, "请先建立会话")
        user = identity["user"]
        rows = batch_store.list_mine(user, 100)
        return _json_result({"ok": True, "batches": rows, "stats": batch_store.stats_for_user(user),
                             "guest": identity.get("kind") == "guest"})
    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/media/([^/]+)", path)
    if match:
        batch = _owner_batch(identity, match.group(1))
        media = batch_store.get_media(batch, unquote(match.group(2)))
        if not media:
            raise ApiError(404, "媒体文件不存在或无权访问")
        media_path, mime = media
        raw = media_path.read_bytes()
        return int(HTTPStatus.OK), raw, [
            ("Content-Type", mime), ("Content-Length", str(len(raw))),
            ("Cache-Control", "private, max-age=300"), ("X-Content-Type-Options", "nosniff"),
            ("Content-Disposition", f'inline; filename="{media_path.name}"'),
        ]
    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})", path)
    if match:
        batch = _owner_batch(identity, match.group(1))
        return _json_result({"ok": True, "batch": batch, "followups": workflow.followups(batch),
                             "evidence_types": evidence_rules.EVIDENCE_TYPES,
                             "source_levels": batch_store.SOURCE_LEVELS,
                             "can_edit": batch.get("owner_id") == identity["user"].get("id")})

    if path == "/api/admin/users":
        return _json_result(_admin_only_payload(identity))
    if path == "/api/admin/batches":
        _require_admin(identity)
        rows = batch_store.list_all(1000)
        return _json_result({"ok": True, "batches": rows, "count": len(rows)})
    match = _match(r"/api/admin/batch/(BAT-[A-Z0-9-]{8,40})", path)
    if match:
        _require_admin(identity)
        batch = batch_store.get(match.group(1), identity["user"])
        if not batch:
            raise ApiError(404, "批次不存在")
        return _json_result({"ok": True, "batch": batch,
                             "audit": audit_store.list_entries(limit=300, resource_type="batch", resource_id=batch["id"])})
    if path == "/api/admin/settings":
        _require_admin(identity)
        return _json_result({"ok": True, "settings": settings_store.admin_settings()})
    if path == "/api/admin/audit":
        _require_admin(identity)
        limit = 200
        for part in query.split("&"):
            if part.startswith("limit="):
                try:
                    limit = max(1, min(1000, int(part.split("=", 1)[1])))
                except ValueError:
                    pass
        return _json_result({"ok": True, "entries": audit_store.list_entries(limit=limit),
                             "verification": audit_store.verify_chain()})
    if path == "/api/admin/audit/verify":
        _require_admin(identity)
        return _json_result({"ok": True, **audit_store.verify_chain()})
    if path == "/api/admin/rules":
        _require_admin(identity)
        return _json_result({"ok": True, **compliance.rules_public()})
    if path == "/api/admin/prompts":
        _require_admin(identity)
        registry = prompts.PROMPT_REGISTRY
        rows = []
        for prompt_id, item in registry.items():
            rows.append({
                "id": prompt_id,
                "name": item.get("name", prompt_id),
                "current": item.get("current", ""),
                **prompts.history(prompt_id),
            })
        return _json_result({"ok": True, "prompts": rows})

    raise ApiError(404, "接口不存在")


def _post(environ, path: str, identity: dict | None):
    body = _json_body(environ)

    if path == "/api/auth/register":
        if not _features().get("registration_enabled", True):
            raise ApiError(403, "平台当前已关闭自助注册")
        username = body.get("username", "")
        password = body.get("password", "")
        try:
            user = account_store.register(username, password, allow_registration=True)
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        audit_store.log("auth.register", user, "user", user["id"])
        storage = account_store.storage_id(user["id"])
        temp = set_access("user", storage, user)
        try:
            state = _public_state({"kind": "user", "subject": user["id"], "storage_id": storage, "user": user})
        finally:
            reset_access(temp)
        return _json_result({"ok": True, "user": user, "state": state},
                            headers=[("Set-Cookie", _change_session_cookie(user, environ))])

    if path == "/api/auth/login":
        try:
            user = account_store.authenticate(body.get("username", ""), body.get("password", ""))
        except ValueError as exc:
            raise ApiError(401, str(exc)) from exc
        audit_store.log("auth.login", user, "user", user["id"])
        storage = account_store.storage_id(user["id"])
        temp = set_access("user", storage, user)
        try:
            state = _public_state({"kind": "user", "subject": user["id"], "storage_id": storage, "user": user})
        finally:
            reset_access(temp)
        return _json_result({"ok": True, "user": user, "state": state},
                            headers=[("Set-Cookie", _change_session_cookie(user, environ))])

    if path == "/api/auth/logout":
        if identity and identity.get("kind") == "user":
            audit_store.log("auth.logout", identity.get("user"), "user", identity.get("subject"))
        return _json_result({"ok": True}, headers=[("Set-Cookie", _cookie("", 0, environ))])

    if path == "/api/auth/password":
        user = _require_user(identity, pending_allowed=True)
        try:
            account_store.change_password(user["id"], body.get("old_password", ""), body.get("new_password", ""))
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        fresh = account_store.get_user(user["id"])
        public = account_store.public_user(fresh)
        audit_store.log("auth.password_change", public, "user", user["id"])
        return _json_result({"ok": True, "user": public}, headers=[("Set-Cookie", _change_session_cookie(public, environ))])

    if not identity:
        raise ApiError(401, "请先建立会话或登录")

    user = identity["user"]
    if identity.get("kind") == "user":
        _require_user(identity)
    elif not _features().get("guest_analysis_enabled", True):
        raise ApiError(403, "管理员已关闭游客使用，请登录")

    if path == "/api/api-config":
        if body.get("action") == "test":
            source = body.get("source") or "auto"
            config = api_client.resolve_config(source)
            result = api_client.test_connection(config)
            if not result.get("ok"):
                raise ApiError(502, result.get("message", "连接失败"))
            return _json_result({"ok": True, "test": result, "config": api_client.public_config()})
        try:
            config = api_client.save_config(body)
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        audit_store.log("api.user_config", user, "api_config", identity.get("subject"), {
            "base_url": config["own"]["base_url"], "model": config["own"]["model"],
            "configured": config["own"]["configured"],
        })
        return _json_result({"ok": True, "config": config})

    if path == "/api/batches":
        mode = body.get("mode", "web")
        if mode not in ("web", "agent"):
            raise ApiError(400, "分析模式只能是联网模式或 Agent 模式")
        try:
            batch = batch_store.create(body, user)
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        return _json_result({"ok": True, "batch": batch, "followups": workflow.followups(batch),
                             "guest": identity.get("kind") == "guest"})

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        allowed = {"product", "mode", "feedback"}
        if set(body) - allowed:
            raise ApiError(400, "存在不支持的批次修改项")
        try:
            old_mode = batch.get("mode")
            updated = batch_store.update(batch, body, user, "修改批次档案")
            if body.get("mode") in ("web", "agent") and body.get("mode") != old_mode:
                updated = batch_store.update_pipeline(updated, {
                    "status": "paused", "mode_switch_pending": True,
                    "previous_mode": old_mode,
                    "status_detail": "模式已切换；历史档案和人工修改保留，请按当前模式重新分析。",
                }, user, "切换分析模式并暂停旧结果")
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        return _json_result({"ok": True, "batch": updated, "followups": workflow.followups(updated)})

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/photos", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        try:
            updated = batch_store.add_photo(batch, body.get("data", ""), body.get("caption", ""), user)
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        return _json_result({"ok": True, "batch": updated})

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/extract", path)
    if match:
        batch = _owner_batch(identity, match.group(1))
        _require_feature("web_collection_enabled")
        try:
            page = web_extract.fetch(body.get("url", ""), timeout=15)
        except (ValueError, web_extract.WebExtractError) as exc:
            raise ApiError(502, f"网页提取失败：{exc}") from exc
        return _json_result({
            "ok": True, "batch_id": batch["id"], "url": page.url, "title": page.title,
            "text": page.text[:12000], "excerpt": page.text[:1200],
            "fetched_at": page.fetched_at, "source_level": workflow.source_level(page.url, page.title),
            "suggested_type": workflow.classify_source(page.title, page.text),
            "references": web_extract.find_references(page)[:20],
            "prices": web_extract.find_prices(page)[:20],
            "notice": "提取结果只是候选材料，不能自动视为已验证证据。",
        })

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/collect", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        _require_feature("web_collection_enabled")
        try:
            result = workflow.collect_public(batch, user, body.get("query", ""), body.get("max_pages"))
        except (web_search.SearchError, ValueError) as exc:
            raise ApiError(502, f"公开网页采集未完成：{exc}") from exc
        return _json_result(result)

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/evidence", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        try:
            if body.get("provider") == "web" or body.get("source_id"):
                _require_feature("web_collection_enabled")
                result = workflow.add_web_evidence(batch, user, body)
            else:
                result = workflow.add_manual_evidence(batch, user, body)
        except (ValueError, web_extract.WebExtractError) as exc:
            raise ApiError(400, str(exc)) from exc
        return _json_result(result)

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/evidence/remove", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        try:
            updated = batch_store.remove_evidence(batch, body.get("evidence_id", ""), user)
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        return _json_result({"ok": True, "batch": updated})

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/verify", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        try:
            result = workflow.verify_evidence(batch, user, body.get("evidence_id", ""), body)
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        return _json_result(result)

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/analyze", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        mode = body.get("mode") or batch.get("mode") or "web"
        if mode == "agent" and not _features().get("user_api_enabled", True):
            platform = settings_store.platform_api_config()
            if not platform:
                raise ApiError(403, "Agent 模式需要可用 API，但管理员已关闭用户 API 且平台 API 未启用")
        try:
            result = workflow.analyze_batch(batch, user, mode, body.get("api_source"))
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        return _json_result(result)

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/content", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        content_patch = body.get("content") if isinstance(body.get("content"), dict) else body
        try:
            result = workflow.update_content(batch, user, content_patch,
                                             body.get("mode") or batch.get("mode") or "web",
                                             body.get("api_source"))
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        return _json_result(result)

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/compliance", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        content = body.get("content") if isinstance(body.get("content"), dict) else batch.get("content", {})
        try:
            result = workflow.update_content(batch, user, {
                key: content.get(key, batch.get("content", {}).get(key, ""))
                for key in ("detail_page", "oral_script", "social_post")
            }, body.get("mode") or batch.get("mode") or "web", body.get("api_source"))
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        return _json_result(result)

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/override", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        _require_user(identity)
        _require_feature("manual_override_enabled")
        try:
            result = workflow.set_override(batch, user, body.get("reason", ""))
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        return _json_result(result)

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/export", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        _require_feature("export_enabled")
        try:
            result = workflow.export_batch(batch, user, body.get("format", "md"))
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        return _json_result(result)

    match = _match(r"/api/batches/(BAT-[A-Z0-9-]{8,40})/feedback", path)
    if match:
        batch = _owner_batch(identity, match.group(1), mutation=True)
        feedback = {
            "channel_code": str(body.get("channel_code", ""))[:40],
            "sold_kg": body.get("sold_kg"),
            "revenue_yuan": body.get("revenue_yuan"),
            "returns_kg": body.get("returns_kg"),
            "profit_yuan": body.get("profit_yuan"),
            "notes": str(body.get("notes", ""))[:1000],
            "recorded_at": _now(),
        }
        updated = batch_store.update_pipeline(batch, {
            "feedback": feedback, "status": "feedback",
            "status_detail": "已回填真实销售反馈，可用于修正下一批建议。",
        }, user, "回填销售结果")
        return _json_result({"ok": True, "batch": updated,
                             "notice": "销售反馈已保存；本批历史测算不会被改写，下一批将保留该记录供人工复盘。"})

    if path == "/api/admin/users":
        raise ApiError(405, "请指定要管理的用户")
    match = _match(r"/api/admin/users/(usr_[a-f0-9]+)", path)
    if match:
        admin = _require_admin(identity)
        try:
            user_row = account_store.update_user(match.group(1), body, admin["id"])
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        audit_store.log("admin.user_update", admin, "user", user_row["id"], {"fields": sorted(body)})
        return _json_result({"ok": True, "user": user_row})

    match = _match(r"/api/admin/users/(usr_[a-f0-9]+)/reset-password", path)
    if match:
        admin = _require_admin(identity)
        try:
            account_store.reset_password(match.group(1), body.get("new_password", ""))
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        audit_store.log("admin.password_reset", admin, "user", match.group(1))
        return _json_result({"ok": True, "notice": "密码已重置，用户下次登录后须修改密码。"})

    if path == "/api/admin/settings":
        admin = _require_admin(identity)
        changed = []
        try:
            if body.get("action") == "test_api":
                config = api_client.resolve_config("platform", allow_disabled_platform=True)
                result = api_client.test_connection(config)
                if not result.get("ok"):
                    raise ApiError(502, result.get("message", "连接失败"))
                return _json_result({"ok": True, "test": result, "settings": settings_store.admin_settings()})
            if "features" in body:
                settings_store.update_features(body["features"])
                changed.append("features")
            if "platform_api" in body:
                settings_store.save_platform_api(body["platform_api"])
                changed.append("platform_api")
            if "data_sources" in body:
                settings_store.update_data_sources(body["data_sources"])
                changed.append("data_sources")
        except ValueError as exc:
            raise ApiError(400, str(exc)) from exc
        if not changed:
            raise ApiError(400, "没有可保存的设置")
        audit_store.log("admin.settings_update", admin, "settings", "platform", {"sections": changed})
        return _json_result({"ok": True, "settings": settings_store.admin_settings(), "changed": changed})

    raise ApiError(404, "接口不存在")


def get(environ, start_response):
    path = unquote(environ.get("PATH_INFO", "/") or "/")
    identity, new_cookie = _identity(environ, create_guest=(path in ("/", "/index.html", "/api/auth/me")))
    token = set_access(identity["kind"], identity["storage_id"], identity.get("user")) if identity else set_access("guest", "0" * 48, None)
    try:
        result = _get(environ, path, identity)
    finally:
        reset_access(token)
    status, raw, headers = result
    if new_cookie and not any(k.lower() == "set-cookie" for k, _ in headers):
        headers.append(("Set-Cookie", new_cookie))
    return _finish(environ, start_response, status, raw, headers)


def post(environ, start_response):
    path = unquote(environ.get("PATH_INFO", "/") or "/")
    auth_path = path in ("/api/auth/register", "/api/auth/login", "/api/auth/logout", "/api/auth/password")
    identity, new_cookie = _identity(environ, create_guest=not auth_path)
    token = set_access(identity["kind"], identity["storage_id"], identity.get("user")) if identity else set_access("guest", "0" * 48, None)
    try:
        result = _post(environ, path, identity)
    finally:
        reset_access(token)
    status, raw, headers = result
    if new_cookie and not any(k.lower() == "set-cookie" for k, _ in headers):
        headers.append(("Set-Cookie", new_cookie))
    return _finish(environ, start_response, status, raw, headers)


def _finish(environ, start_response, status: int, raw: bytes, headers: list[tuple[str, str]]):
    reason = HTTPStatus(status).phrase if status in HTTPStatus._value2member_map_ else "Response"
    base = [
        ("X-Content-Type-Options", "nosniff"),
        ("X-Frame-Options", "DENY"),
        ("Referrer-Policy", "same-origin"),
        ("Permissions-Policy", "camera=(self), microphone=(), geolocation=()"),
        ("Cross-Origin-Opener-Policy", "same-origin"),
        ("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"),
    ]
    seen = {k.lower() for k, _ in headers}
    headers = headers + [(k, v) for k, v in base if k.lower() not in seen]
    start_response(f"{status} {reason}", headers)
    if environ.get("REQUEST_METHOD", "GET").upper() == "HEAD":
        return [b""]
    return [raw]


def application(environ, start_response):
    path = unquote(environ.get("PATH_INFO", "/") or "/")
    method = environ.get("REQUEST_METHOD", "GET").upper()
    _cleanup_if_due()
    if method == "OPTIONS":
        headers = [
            ("Allow", "GET, HEAD, POST, OPTIONS"),
            ("Access-Control-Allow-Methods", "GET, HEAD, POST, OPTIONS"),
            ("Access-Control-Allow-Headers", "Content-Type, X-Requested-With"),
            ("Content-Length", "0"),
        ]
        start_response("204 No Content", headers)
        return [b""]
    try:
        identity, _ = _identity(environ, create_guest=False)
        _limit(environ, identity)
        if method in ("GET", "HEAD"):
            return get(environ, start_response)
        if method == "POST":
            return post(environ, start_response)
        return _finish(environ, start_response, 405, json.dumps({"ok": False, "error": "请求方法不支持"}, ensure_ascii=False).encode("utf-8"), [
            ("Content-Type", "application/json; charset=utf-8"), ("Allow", "GET, HEAD, POST, OPTIONS")
        ])
    except ApiError as exc:
        return _finish(environ, start_response, exc.status, json.dumps({"ok": False, "error": exc.message}, ensure_ascii=False).encode("utf-8"), [
            ("Content-Type", "application/json; charset=utf-8"), ("Cache-Control", "no-store")
        ])
    except (ValueError, KeyError, TypeError) as exc:
        return _finish(environ, start_response, 400, json.dumps({"ok": False, "error": str(exc) or "请求参数不正确"}, ensure_ascii=False).encode("utf-8"), [
            ("Content-Type", "application/json; charset=utf-8"), ("Cache-Control", "no-store")
        ])
    except Exception as exc:
        traceback.print_exc()
        message = "服务器处理失败，请稍后重试"
        if os.environ.get("APP_DEBUG") == "1":
            message += "：" + str(exc)
        return _finish(environ, start_response, 500, json.dumps({"ok": False, "error": message}, ensure_ascii=False).encode("utf-8"), [
            ("Content-Type", "application/json; charset=utf-8"), ("Cache-Control", "no-store")
        ])


_LAST_GUEST_CLEANUP = 0.0


def _cleanup_if_due() -> None:
    global _LAST_GUEST_CLEANUP
    now_ts = time.time()
    if now_ts - _LAST_GUEST_CLEANUP > 300:
        _LAST_GUEST_CLEANUP = now_ts
        cleanup_guests()


if __name__ == "__main__":
    from wsgiref.simple_server import make_server
    port = int(os.environ.get("PORT", "8000"))
    account_store.ensure_admin()
    print(f"言之有据已启动：http://127.0.0.1:{port}")
    make_server("0.0.0.0", port, application).serve_forever()

