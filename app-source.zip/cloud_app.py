"""WSGI entry point for a single-process, multithreaded free web service."""
import hashlib
import hmac
import json
import mimetypes
import os
from pathlib import Path
import re
import secrets
import threading
import time
from collections import OrderedDict, deque
from http import HTTPStatus
from http.cookies import SimpleCookie
from urllib.parse import unquote, urlsplit

import app
from core import ledger, llm, prompts, web_extract
from core.cloud_context import VISITOR

SECRET = (os.environ.get('SESSION_SECRET') or secrets.token_hex(32)).encode()
API_LOCK = threading.RLock()
RATE_LOCK = threading.Lock()
RATE = OrderedDict()
MAX_BODY = 1024 * 1024
COOKIE = 'yzyj_visitor'

def signature(sid):
    return hmac.new(SECRET, sid.encode(), hashlib.sha256).hexdigest()

def visitor(environ):
    try:
        cookies = SimpleCookie(environ.get('HTTP_COOKIE', ''))
        sid, mac = cookies[COOKIE].value.split('.', 1)
        if re.fullmatch('[a-f0-9]{48}', sid) and hmac.compare_digest(signature(sid), mac):
            return sid, False
    except (KeyError, ValueError):
        pass
    return secrets.token_hex(24), True

def limit(sid):
    with RATE_LOCK:
        now = time.monotonic()
        queue = RATE.setdefault(sid, deque())
        RATE.move_to_end(sid)
        while queue and queue[0] < now - 60:
            queue.popleft()
        if len(queue) >= 60:
            raise app.ApiError(429, '操作较频繁，请稍等一分钟再试')
        queue.append(now)
        while len(RATE) > 3000:
            RATE.popitem(last=False)

def get(path, query):
    if path.startswith('/api/ledger/'):
        rec = ledger.get(path.rsplit('/',1)[-1])
        if not rec:
            raise app.ApiError(404, '当前访客没有这条运行记录')
        return {'ok':True,'record':rec}
    if path.startswith('/api/product/'):
        return {'ok':True, 'product':app.load_product(path.rsplit('/',1)[-1])}
    if path.startswith('/api/prompts/'):
        pid = path.rsplit('/',1)[-1]
        if pid not in prompts.PROMPT_REGISTRY:
            raise app.ApiError(404, '未知提示词')
        detail = prompts.history(pid)
        detail['versions'] = [v | {'prompt_text':next(x['prompt'] for x in prompts.PROMPT_REGISTRY[pid]['versions'] if x['version'] == v['version'])} for v in detail['versions']]
        return {'ok':True, 'prompt':detail}
    fn = app.ROUTES_GET.get(path)
    if fn:
        return fn(query)
    raise app.ApiError(404, '未知接口')

def post(path, body):
    fn = app.ROUTES_POST.get(path)
    if not fn:
        raise app.ApiError(404, '未知接口')
    if path == '/api/generate' and len(ledger._load()) >= 200:
        raise app.ApiError(429, '当前访客已达到 200 条记录上限，请先导出重要结果')
    if 'record_id' in body and (not isinstance(body['record_id'], str) or not ledger.get(body['record_id'])):
        raise app.ApiError(404, '当前访客没有这条运行记录')
    return fn(body)

def application(environ, start_response):
    path = unquote(environ.get('PATH_INFO', '/'))
    method = environ.get('REQUEST_METHOD', 'GET')
    status = 200
    cookie_header = None
    token = None
    headers = [('Cache-Control','no-store'), ('X-Content-Type-Options','nosniff'),
               ('X-Frame-Options','DENY'), ('Referrer-Policy','same-origin'),
               ('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")]
    content_type = 'application/json; charset=utf-8'
    try:
        if method not in ('GET', 'POST', 'HEAD'):
            raise app.ApiError(405, '不支持此方法')
        if path == '/api/health':
            payload = {'ok':True, 'service':'言之有据', 'deployment':'cloud', 'version':'2026-10-29-api1'}
        elif path.startswith('/api/'):
            sid, fresh = visitor(environ)
            token = VISITOR.set(sid)
            if fresh:
                secure = '; Secure' if environ.get('wsgi.url_scheme') == 'https' or environ.get('HTTP_X_FORWARDED_PROTO') == 'https' else ''
                cookie_header = f'{COOKIE}={sid}.{signature(sid)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000{secure}'
            limit(sid)
            if method in ('GET', 'HEAD'):
                with API_LOCK:
                    payload = get(path, environ.get('QUERY_STRING', ''))
            else:
                if environ.get('HTTP_X_REQUESTED_WITH') != 'YanZhiYouJu':
                    raise app.ApiError(403, '请从本应用页面提交操作')
                origin = environ.get('HTTP_ORIGIN')
                if origin and urlsplit(origin).netloc != environ.get('HTTP_HOST'):
                    raise app.ApiError(403, '不允许跨站提交操作')
                try:
                    length = int(environ.get('CONTENT_LENGTH') or '0')
                except ValueError:
                    raise app.ApiError(400, '请求长度无效')
                if length < 0 or length > MAX_BODY:
                    raise app.ApiError(413, '请求内容过大')
                try:
                    body = json.loads(environ['wsgi.input'].read(length) or b'{}')
                except (ValueError, UnicodeError):
                    raise app.ApiError(400, '请求不是有效 JSON')
                if not isinstance(body, dict):
                    raise app.ApiError(400, '请求内容必须是 JSON 对象')
                with API_LOCK:
                    payload = post(path, body)
        else:
            if method == 'POST':
                raise app.ApiError(405, '不支持此方法')
            rel = 'index.html' if path == '/' else path.lstrip('/')
            target = (app.WEB_DIR / rel).resolve()
            if not target.is_relative_to(app.WEB_DIR.resolve()) or not target.is_file():
                raise app.ApiError(404, '页面不存在')
            content_type = (mimetypes.guess_type(target.name)[0] or 'application/octet-stream')
            if target.suffix in ('.js','.html','.css'):
                content_type += '; charset=utf-8'
            payload = target.read_bytes()
        data = payload if isinstance(payload, bytes) else json.dumps(payload, ensure_ascii=False).encode('utf-8')
    except app.ApiError as exc:
        status = exc.status
        data = json.dumps({'ok':False,'error':exc.message},ensure_ascii=False).encode('utf-8')
    except (ValueError, TypeError, web_extract.WebExtractError) as exc:
        status = 400
        data = json.dumps({'ok':False,'error':str(exc)},ensure_ascii=False).encode('utf-8')
    except Exception:
        status = 500
        data = json.dumps({'ok':False,'error':'服务暂时未能处理，请稍后重试。'},ensure_ascii=False).encode('utf-8')
    finally:
        if token is not None:
            VISITOR.reset(token)
    headers += [('Content-Type',content_type), ('Content-Length',str(len(data)))]
    if cookie_header:
        headers.append(('Set-Cookie', cookie_header))
    start_response(f'{status} {HTTPStatus(status).phrase}', headers)
    return [b'' if method == 'HEAD' else data]

if __name__ == '__main__':
    from wsgiref.simple_server import make_server
    with make_server('127.0.0.1', int(os.environ.get('PORT','8098')), application) as server:
        print('本地云端版检查地址：http://127.0.0.1:' + str(server.server_port), flush=True)
        server.serve_forever()
