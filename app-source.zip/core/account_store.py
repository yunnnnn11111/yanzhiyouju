"""账号、角色与密码存储。仅依赖 Python 标准库。"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import threading
from datetime import datetime, timezone
from pathlib import Path

from core.cloud_context import DATA_ROOT

USERS_FILE = DATA_ROOT / "users.json"
LOCK = threading.RLock()
USERNAME_RE = re.compile(r"^[A-Za-z0-9_\-\u4e00-\u9fff]{3,24}$")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _read() -> dict:
    if not USERS_FILE.exists():
        return {"users": [], "created_at": now()}
    try:
        data = json.loads(USERS_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict) and isinstance(data.get("users"), list):
            return data
    except (OSError, ValueError):
        pass
    return {"users": [], "created_at": now()}


def _write(data: dict) -> None:
    USERS_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = USERS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(USERS_FILE)


def _hash_password(password: str, salt: str | None = None) -> str:
    if not isinstance(password, str) or not 8 <= len(password) <= 128:
        raise ValueError("密码长度须为 8–128 个字符")
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        raise ValueError("密码至少包含一个字母和一个数字")
    salt = salt or secrets.token_hex(16)
    rounds = 260_000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("ascii"), rounds)
    return f"pbkdf2_sha256${rounds}${salt}${digest.hex()}"


def _verify_password(password: str, stored: str) -> bool:
    try:
        algo, rounds, salt, expected = stored.split("$", 3)
        if algo != "pbkdf2_sha256":
            return False
        got = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("ascii"), int(rounds)).hex()
        return hmac.compare_digest(got, expected)
    except (ValueError, TypeError):
        return False


def storage_id(user_id: str) -> str:
    return hashlib.sha256(("yzyj-storage:" + user_id).encode("utf-8")).hexdigest()[:48]


def public_user(user: dict) -> dict:
    return {
        "id": user["id"],
        "username": user["username"],
        "role": user["role"],
        "active": bool(user.get("active", True)),
        "created_at": user.get("created_at", ""),
        "last_login_at": user.get("last_login_at", ""),
        "must_change_password": bool(user.get("must_change_password", False)),
    }


def ensure_admin() -> dict:
    username = (os.environ.get("ADMIN_USERNAME") or "admin").strip()
    password = os.environ.get("ADMIN_PASSWORD")
    production = bool(os.environ.get("RENDER")) or os.environ.get("APP_ENV") == "production"
    if production and not password:
        return {}
    password = password or "Yanzhi@2026"
    with LOCK:
        data = _read()
        existing = next((u for u in data["users"] if u.get("username", "").lower() == username.lower()), None)
        if existing:
            if existing.get("role") != "admin":
                raise ValueError("管理员用户名已由普通账号占用，请更换 ADMIN_USERNAME")
            return public_user(existing)
        user = {
            "id": "usr_" + secrets.token_hex(10),
            "username": username,
            "password_hash": _hash_password(password),
            "role": "admin",
            "active": True,
            "created_at": now(),
            "last_login_at": "",
            "must_change_password": True,
        }
        data["users"].append(user)
        _write(data)
        return public_user(user)


def get_user(user_id: str) -> dict | None:
    with LOCK:
        for user in _read()["users"]:
            if user.get("id") == user_id:
                return dict(user)
    return None


def get_user_by_name(username: str) -> dict | None:
    needle = (username or "").strip().lower()
    with LOCK:
        for user in _read()["users"]:
            if user.get("username", "").lower() == needle:
                return dict(user)
    return None


def register(username: str, password: str, allow_registration: bool = True) -> dict:
    if not allow_registration:
        raise ValueError("平台当前已关闭自助注册")
    username = (username or "").strip()
    if username.lower() in {"admin", (os.environ.get("ADMIN_USERNAME") or "admin").strip().lower()}:
        raise ValueError("该用户名保留用于平台管理员")
    if not USERNAME_RE.fullmatch(username):
        raise ValueError("用户名须为 3–24 位中文、字母、数字、下划线或短横线")
    with LOCK:
        data = _read()
        if any(u.get("username", "").lower() == username.lower() for u in data["users"]):
            raise ValueError("该用户名已存在")
        user = {
            "id": "usr_" + secrets.token_hex(10),
            "username": username,
            "password_hash": _hash_password(password),
            "role": "user",
            "active": True,
            "created_at": now(),
            "last_login_at": now(),
            "must_change_password": False,
        }
        data["users"].append(user)
        _write(data)
        return public_user(user)


def authenticate(username: str, password: str) -> dict:
    user = get_user_by_name(username)
    if not user or not _verify_password(password, user.get("password_hash", "")):
        raise ValueError("用户名或密码错误")
    if not user.get("active", True):
        raise ValueError("该账号已被管理员停用")
    with LOCK:
        data = _read()
        for item in data["users"]:
            if item.get("id") == user["id"]:
                item["last_login_at"] = now()
                _write(data)
                user = public_user(item)
                break
    return user


def change_password(user_id: str, old_password: str, new_password: str, admin_reset: bool = False) -> None:
    with LOCK:
        data = _read()
        for user in data["users"]:
            if user.get("id") != user_id:
                continue
            if not admin_reset and not _verify_password(old_password, user.get("password_hash", "")):
                raise ValueError("当前密码不正确")
            if _verify_password(new_password, user.get("password_hash", "")):
                raise ValueError("新密码不能与旧密码相同")
            user["password_hash"] = _hash_password(new_password)
            user["session_version"] = int(user.get("session_version", 0)) + 1
            user["must_change_password"] = bool(admin_reset)
            user["password_changed_at"] = now()
            _write(data)
            return
    raise ValueError("用户不存在")


def list_users() -> list[dict]:
    with LOCK:
        return [public_user(u) for u in _read()["users"]]


def update_user(user_id: str, patch: dict, acting_admin_id: str) -> dict:
    allowed = {"active", "role", "must_change_password"}
    if set(patch) - allowed:
        raise ValueError("存在不支持的账号修改项")
    if user_id == acting_admin_id and patch.get("role") == "user":
        raise ValueError("不能取消当前登录管理员的权限")
    with LOCK:
        data = _read()
        target = next((u for u in data["users"] if u.get("id") == user_id), None)
        if not target:
            raise ValueError("用户不存在")
        if "active" in patch:
            if not isinstance(patch["active"], bool):
                raise ValueError("账号状态格式无效")
            if user_id == acting_admin_id and not patch["active"]:
                raise ValueError("不能停用当前登录管理员")
            target["active"] = patch["active"]
        if "role" in patch:
            if patch["role"] not in ("user", "admin"):
                raise ValueError("角色无效")
            target["role"] = patch["role"]
        if "must_change_password" in patch:
            if not isinstance(patch["must_change_password"], bool):
                raise ValueError("密码状态格式无效")
            target["must_change_password"] = patch["must_change_password"]
        target["updated_at"] = now()
        _write(data)
        return public_user(target)


def reset_password(user_id: str, new_password: str) -> None:
    change_password(user_id, "", new_password, admin_reset=True)


ensure_admin()
