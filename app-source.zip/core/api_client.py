"""兼容 Chat Completions 的模型客户端与用户级密钥存储。"""
from __future__ import annotations

import json
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError

from core import settings_store
from core.cloud_context import current_access, visitor_path
from core.public_http import public_json_post
from core.secure_store import decrypt_secret, encrypt_secret, mask_secret

LOCK = threading.RLock()
DEFAULT_BASE = settings_store.DEFAULT_BASE
DEFAULT_MODEL = settings_store.DEFAULT_MODEL
SOURCE_LABELS = {"platform": "平台 API", "own": "我的 API"}


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _own_path() -> Path:
    return visitor_path() / "api_config.json"


def _read_own() -> dict:
    path = _own_path()
    out = {"base_url": DEFAULT_BASE, "model": DEFAULT_MODEL, "api_key_enc": "", "updated_at": "", "last_test": {}}
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                out.update({k: data[k] for k in out if k in data})
        except (OSError, ValueError):
            pass
    return out


def _write_own(data: dict) -> None:
    path = _own_path()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def validate_base(value: str) -> str:
    return settings_store.validate_base(value)


def validate_model(value: str) -> str:
    return settings_store.validate_model(value)


def public_config() -> dict:
    """返回浏览器可见配置，任何情况下都不返回明文密钥。"""
    ctx = current_access()
    own = _read_own()
    own_key = decrypt_secret(own.get("api_key_enc", ""))
    platform = settings_store.public_settings()
    return {
        "default_source": "platform" if platform["platform_api"]["configured"] and platform["platform_api"]["enabled"] else "own",
        "platform": platform["platform_api"],
        "own": {
            "configured": bool(own_key),
            "base_url": own.get("base_url", DEFAULT_BASE),
            "model": own.get("model", DEFAULT_MODEL),
            "key_masked": mask_secret(own_key),
            "updated_at": own.get("updated_at", ""),
            "last_test": own.get("last_test", {}),
        },
        "user_api_enabled": bool(platform["features"].get("user_api_enabled", True)),
        "guest": ctx.get("kind") == "guest",
        "notice": "密钥仅保存到当前账号的加密配置中；游客配置随游客临时目录清理。浏览器只接收掩码。",
    }


def save_config(patch: dict) -> dict:
    allowed = {"source", "base_url", "model", "api_key", "clear_key"}
    if not isinstance(patch, dict) or set(patch) - allowed:
        raise ValueError("存在不支持的 API 设置项")
    settings = settings_store.public_settings()
    if not settings["features"].get("user_api_enabled", True):
        raise ValueError("管理员已关闭用户自有 API 配置")
    with LOCK:
        data = _read_own()
        old_key = decrypt_secret(data.get("api_key_enc", ""))
        old_base = data.get("base_url", DEFAULT_BASE)
        if "base_url" in patch:
            data["base_url"] = validate_base(patch["base_url"])
        if "model" in patch:
            data["model"] = validate_model(patch["model"])
        key = patch.get("api_key", "")
        if not isinstance(key, str) or len(key) > 4096 or any(ord(c) < 33 or ord(c) > 126 for c in key):
            raise ValueError("API Key 格式不正确，请勿包含空格或换行")
        if patch.get("clear_key") is True:
            if key:
                raise ValueError("清除密钥时请勿同时填写新密钥")
            data["api_key_enc"] = ""
        elif key:
            data["api_key_enc"] = encrypt_secret(key)
        if data.get("base_url") != old_base and not key and not patch.get("clear_key"):
            if old_key:
                raise ValueError("更换 API 地址时，请重新填写对应的 API Key")
        if patch.get("source") not in (None, "platform", "own"):
            raise ValueError("API 来源只能选择平台 API 或我的 API")
        if patch.get("source") == "own" and not decrypt_secret(data.get("api_key_enc", "")):
            raise ValueError("请先为“我的 API”填写有效密钥")
        data["updated_at"] = now()
        data["last_test"] = {}
        _write_own(data)
    return public_config()


def resolve_config(source: str | None = None, allow_disabled_platform: bool = False) -> dict:
    requested = source or "auto"
    if requested not in ("auto", "platform", "own"):
        raise ValueError("API 来源无效")
    settings = settings_store.get_settings()
    features = settings.get("features", {})
    if requested in ("auto", "platform"):
        platform = settings_store.platform_api_config(include_disabled=allow_disabled_platform)
        if platform:
            return platform
        if requested == "platform" and not allow_disabled_platform:
            if not features.get("platform_api_enabled"):
                raise ValueError("管理员尚未启用平台 API")
            raise ValueError("平台 API 尚未配置服务密钥")
    if requested == "own" and not features.get("user_api_enabled", True):
        raise ValueError("管理员已关闭用户 API")
    if requested == "platform":
        raise ValueError("平台 API 尚未配置服务密钥")
    own = _read_own()
    key = decrypt_secret(own.get("api_key_enc", ""))
    if not key:
        raise ValueError("当前账号尚未配置自有 API，请在 API 设置中填写")
    return {"source": "own", "base_url": own.get("base_url", DEFAULT_BASE),
            "model": own.get("model", DEFAULT_MODEL), "api_key": key}


def _endpoint(base_url: str) -> str:
    base = base_url.rstrip("/")
    if base.endswith("/v1"):
        return base + "/chat/completions"
    return base + "/v1/chat/completions"


def chat(config: dict, system: str, user: str, temperature: float = 0.2,
         max_tokens: int = 2200, timeout: int = 50) -> dict:
    if not isinstance(system, str) or not isinstance(user, str):
        raise ValueError("模型消息格式无效")
    payload = {
        "model": config["model"],
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        "temperature": float(temperature),
        "max_tokens": int(max_tokens),
        "stream": False,
    }
    started = datetime.now(timezone.utc)
    try:
        raw = public_json_post(_endpoint(config["base_url"]), payload, config["api_key"], timeout=timeout)
    except HTTPError as exc:
        message = "模型服务返回 HTTP %s" % exc.code
        if exc.code == 401:
            message = "API Key 无效或已失效"
        elif exc.code == 429:
            message = "模型服务限流，请稍后重试"
        raise ValueError(message) from exc
    except (URLError, TimeoutError, OSError) as exc:
        raise ValueError("模型服务连接失败：" + str(exc)[:180]) from exc
    choices = raw.get("choices") if isinstance(raw, dict) else None
    if not isinstance(choices, list) or not choices:
        raise ValueError("模型服务未返回可用内容")
    message = choices[0].get("message") if isinstance(choices[0], dict) else None
    content = message.get("content") if isinstance(message, dict) else ""
    if not isinstance(content, str) or not content.strip():
        raise ValueError("模型服务返回内容为空")
    return {
        "content": content.strip(),
        "model": raw.get("model") or config["model"],
        "usage": raw.get("usage") or {},
        "elapsed": round((datetime.now(timezone.utc) - started).total_seconds(), 2),
        "source": config.get("source", "own"),
    }


def parse_json(content: str):
    if not isinstance(content, str):
        return None
    text = content.strip()
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.I | re.S)
    if fenced:
        text = fenced.group(1).strip()
    try:
        return json.loads(text)
    except ValueError:
        start, end = text.find("{"), text.rfind("}")
        if start >= 0 and end > start:
            try:
                return json.loads(text[start:end + 1])
            except ValueError:
                return None
    return None


def test_connection(config: dict) -> dict:
    try:
        result = chat(config, "你是接口连通性检查助手。", "只回复：连接成功", temperature=0, max_tokens=20, timeout=30)
        output = {"ok": True, "message": "连接成功", "model": result["model"], "elapsed": result["elapsed"]}
    except ValueError as exc:
        output = {"ok": False, "message": str(exc)}
    if config.get("source") == "platform":
        settings_store.set_api_test(output)
    else:
        with LOCK:
            data = _read_own()
            data["last_test"] = {"status": "passed" if output["ok"] else "failed",
                                 "message": output["message"], "at": now()}
            _write_own(data)
    return output


