"""追加式审计日志：每次输入、采集、核验、生成、修改和导出均留痕。"""
from __future__ import annotations

import hashlib
import json
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

from core.cloud_context import DATA_ROOT

AUDIT_FILE = DATA_ROOT / "audit.jsonl"
LOCK = threading.RLock()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _last_hash() -> str:
    if not AUDIT_FILE.exists():
        return "0" * 64
    last = ""
    try:
        with AUDIT_FILE.open("r", encoding="utf-8") as fh:
            for line in fh:
                if line.strip():
                    last = line
    except OSError:
        return "0" * 64
    try:
        return json.loads(last).get("hash", "0" * 64)
    except ValueError:
        return "0" * 64


def log(action: str, actor: dict | None, resource_type: str = "", resource_id: str = "",
        detail: dict | None = None, request_id: str = "") -> dict:
    actor = actor or {}
    item = {
        "id": "AUD-" + uuid.uuid4().hex[:16],
        "at": _now(),
        "action": str(action)[:100],
        "actor_id": actor.get("id", "guest"),
        "actor_username": actor.get("username", "游客"),
        "actor_role": actor.get("role", "guest"),
        "resource_type": str(resource_type)[:60],
        "resource_id": str(resource_id)[:100],
        "detail": detail or {},
        "request_id": request_id,
        "prev_hash": "",
        "hash": "",
    }
    with LOCK:
        item["prev_hash"] = _last_hash()
        raw = json.dumps(item, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        item["hash"] = hashlib.sha256(raw).hexdigest()
        AUDIT_FILE.parent.mkdir(parents=True, exist_ok=True)
        with AUDIT_FILE.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n")
    return item


def list_entries(limit: int = 200, actor_id: str = "", resource_type: str = "", resource_id: str = "") -> list[dict]:
    if not AUDIT_FILE.exists():
        return []
    rows = []
    try:
        with AUDIT_FILE.open("r", encoding="utf-8") as fh:
            for line in fh:
                try:
                    item = json.loads(line)
                except ValueError:
                    continue
                if actor_id and item.get("actor_id") != actor_id:
                    continue
                if resource_type and item.get("resource_type") != resource_type:
                    continue
                if resource_id and item.get("resource_id") != resource_id:
                    continue
                rows.append(item)
    except OSError:
        return []
    return list(reversed(rows[-max(1, min(limit, 1000)):]))


def verify_chain() -> dict:
    previous = "0" * 64
    total = 0
    broken = []
    try:
        with AUDIT_FILE.open("r", encoding="utf-8") as fh:
            for line_no, line in enumerate(fh, 1):
                if not line.strip():
                    continue
                try:
                    item = json.loads(line)
                except ValueError:
                    broken.append({"line": line_no, "reason": "不是有效 JSON"})
                    continue
                total += 1
                stored = item.pop("hash", "")
                item["hash"] = ""
                if item.get("prev_hash") != previous:
                    broken.append({"line": line_no, "reason": "前序哈希不连续"})
                raw = json.dumps(item, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
                expected = hashlib.sha256(raw).hexdigest()
                if stored != expected:
                    broken.append({"line": line_no, "reason": "内容哈希不匹配"})
                previous = stored
    except OSError as exc:
        return {"ok": False, "total": total, "broken": [{"line": 0, "reason": str(exc)}]}
    return {"ok": not broken, "total": total, "broken": broken[:20], "last_hash": previous}
