"""批次级产品档案、证据、报告和附件的文件存储。"""
from __future__ import annotations

import base64
import copy
import hashlib
import json
import math
import mimetypes
import re
import secrets
import threading
import uuid
from datetime import date, datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

from core import audit_store
from core.cloud_context import DATA_ROOT, visitor_path
from core.evidence import EVIDENCE_TYPES

LOCK = threading.RLock()
BATCH_RE = re.compile(r"^BAT-[A-Z0-9-]{8,40}$")
MAX_PHOTOS = 4
MAX_ATTACHMENT_BYTES = 4 * 1024 * 1024
SOURCE_LEVELS = ["政府/主管部门", "标准/行业机构", "检测/认证机构", "平台公开数据", "企业/合作社自述", "其他公开来源"]
STATUSES = {"pending", "verified", "rejected", "expired", "conflict"}


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _clean(value, limit: int = 500, label: str = "内容", required: bool = False) -> str:
    if value is None:
        value = ""
    if not isinstance(value, str) or len(value) > limit:
        raise ValueError(f"{label}须为不超过 {limit} 字的文本")
    value = value.strip()
    if required and not value:
        raise ValueError(f"请填写{label}")
    return value


def _number(value, label: str, minimum: float = 0, maximum: float = 100_000_000, nullable: bool = True):
    if value in (None, "", "null"):
        if nullable:
            return None
        raise ValueError(f"请填写{label}")
    if isinstance(value, bool):
        raise ValueError(f"{label}格式不正确")
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label}须为数字") from exc
    if not math.isfinite(number) or number < minimum or number > maximum:
        raise ValueError(f"{label}须在 {minimum:g}–{maximum:g} 之间")
    return round(number, 2)


def _date_text(value, label: str) -> str:
    value = _clean(value, 20, label)
    if not value:
        return ""
    try:
        date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"{label}须为 YYYY-MM-DD 格式") from exc
    return value


def _batch_dir() -> Path:
    path = visitor_path() / "batches"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _media_dir(batch_id: str) -> Path:
    if not BATCH_RE.fullmatch(batch_id or ""):
        raise ValueError("批次编号格式无效")
    path = visitor_path() / "media" / batch_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def _snapshot_dir(batch_id: str) -> Path:
    if not BATCH_RE.fullmatch(batch_id or ""):
        raise ValueError("批次编号格式无效")
    path = visitor_path() / "snapshots" / batch_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def _path(batch_id: str) -> Path:
    if not BATCH_RE.fullmatch(batch_id or ""):
        raise ValueError("批次编号格式无效")
    return _batch_dir() / f"{batch_id}.json"


def _write(batch: dict) -> dict:
    path = _path(batch["id"])
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(batch, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)
    return batch


def _read_path(path: Path) -> dict | None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not data.get("id"):
            return None
        for row in data.get("evidence", []):
            if row.get("status") == "verified" and row.get("expires_at"):
                try:
                    expired = date.fromisoformat(row["expires_at"]) < date.today()
                except (TypeError, ValueError):
                    expired = True
                if expired:
                    row.update({"status": "expired", "provided": False})
                    data["status"] = "paused"
                    data.setdefault("compliance", {}).update({"level": "high", "blocked": True, "level_text": "证据已过期，请重新核验并分析"})
        return data
    except (OSError, ValueError):
        return None


def _file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _save_data_url(batch_id: str, data_url: str, kind: str) -> dict:
    if not isinstance(data_url, str) or not data_url.startswith("data:"):
        raise ValueError(f"{kind}文件格式无效")
    match = re.match(r"data:([^;,]+);base64,(.+)$", data_url, re.S)
    if not match:
        raise ValueError(f"{kind}文件格式无效")
    mime, encoded = match.groups()
    allowed = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}
    if kind == "材料附件":
        allowed.update({"application/pdf": ".pdf"})
    if mime not in allowed:
        raise ValueError(f"{kind}仅支持 JPG、PNG、WebP" + (" 或 PDF" if kind == "材料附件" else ""))
    try:
        raw = base64.b64decode(encoded, validate=True)
    except (ValueError, TypeError) as exc:
        raise ValueError(f"{kind}文件内容损坏") from exc
    if not raw or len(raw) > MAX_ATTACHMENT_BYTES:
        raise ValueError(f"{kind}大小须不超过 4 MB")
    token = secrets.token_hex(10)
    name = token + allowed[mime]
    target = _media_dir(batch_id) / name
    target.write_bytes(raw)
    return {"filename": name, "original_name": "", "mime": mime, "size": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(), "url": f"/api/batches/{batch_id}/media/{name}"}


def save_photo(batch_id: str, data_url: str, caption: str = "") -> dict:
    item = _save_data_url(batch_id, data_url, "照片")
    item["caption"] = _clean(caption, 80, "照片说明")
    item["id"] = "IMG-" + secrets.token_hex(8)
    item["uploaded_at"] = now()
    return item


def save_attachment(batch_id: str, data_url: str, original_name: str = "") -> dict:
    item = _save_data_url(batch_id, data_url, "材料附件")
    item["original_name"] = _clean(original_name, 160, "附件名")
    item["id"] = "ATT-" + secrets.token_hex(8)
    item["uploaded_at"] = now()
    return item


def save_snapshot(batch_id: str, evidence_id: str, text: str) -> dict:
    raw = text.encode("utf-8")
    if len(raw) > 1024 * 1024:
        raw = raw[:1024 * 1024]
    name = re.sub(r"[^A-Za-z0-9_-]", "", evidence_id)[:40] + ".txt"
    target = _snapshot_dir(batch_id) / name
    target.write_bytes(raw)
    return {"filename": name, "sha256": hashlib.sha256(raw).hexdigest(), "size": len(raw),
            "captured_at": now(), "url": f"/api/batches/{batch_id}/media/{name}"}


def _normalize_product(payload: dict, existing: dict | None = None) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("产品档案格式无效")
    old = existing or {}
    merged = dict(old)
    merged.update(payload)
    out = {
        "name": _clean(merged.get("name"), 80, "产品名", True),
        "origin_address": _clean(merged.get("origin_address"), 240, "来源地址", True),
        "organization": _clean(merged.get("organization"), 120, "公司或单位", True),
        "batch_weight_kg": _number(merged.get("batch_weight_kg"), "本批重量", 0.01, 10_000_000, False),
        "variety": _clean(merged.get("variety"), 60, "品种"),
        "grade": _clean(merged.get("grade"), 60, "等级"),
        "spec": _clean(merged.get("spec"), 160, "规格"),
        "harvest_date": _date_text(merged.get("harvest_date"), "采摘日期"),
        "package_date": _date_text(merged.get("package_date"), "包装日期"),
        "unit_price_yuan_per_kg": _number(merged.get("unit_price_yuan_per_kg"), "期望售价", 0, 100_000),
        "unit_cost_yuan_per_kg": _number(merged.get("unit_cost_yuan_per_kg"), "综合成本", 0, 100_000),
        "transport": _clean(merged.get("transport"), 500, "运输工具"),
        "storage": _clean(merged.get("storage"), 500, "储存条件"),
        "transport_capacity_kg": _number(merged.get("transport_capacity_kg"), "单次运输能力", 0, 10_000_000),
        "daily_capacity_kg": _number(merged.get("daily_capacity_kg"), "日发货能力", 0, 10_000_000),
        "target_market": _clean(merged.get("target_market"), 300, "目标市场"),
        "notes": _clean(merged.get("notes"), 1000, "补充说明"),
    }
    return out


def _base_evidence(product: dict) -> list[dict]:
    stamp = now()
    origin = f"{product['name']}；来源地址：{product['origin_address']}；提交单位：{product['organization']}；本批重量：{product['batch_weight_kg']} kg。"
    rows = [{
        "id": "EVD-" + secrets.token_hex(8), "type": "BATCH_RECORD",
        "label": EVIDENCE_TYPES["BATCH_RECORD"]["label"], "source_level": "企业/合作社自述",
        "source_name": product["organization"], "source_url": "", "detail": origin,
        "excerpt": origin, "published_at": "", "fetched_at": stamp, "expires_at": "",
        "status": "verified", "provided": True, "matches_batch": True,
        "verification_note": "由提交人在创建批次时确认；属于基础自述，不等同于第三方证明。",
        "verified_by": "提交人", "verified_at": stamp, "snapshot": {}, "attachment": {},
        "origin": "batch_form", "bound_claims": [], "created_at": stamp,
    }]
    if product.get("transport") or product.get("storage"):
        detail = f"运输：{product.get('transport') or '未填写'}；储存：{product.get('storage') or '未填写'}；单次运输能力：{product.get('transport_capacity_kg') or '未填写'} kg；日发货能力：{product.get('daily_capacity_kg') or '未填写'} kg。"
        rows.append({
            "id": "EVD-" + secrets.token_hex(8), "type": "TRANSPORT_STORAGE",
            "label": EVIDENCE_TYPES["TRANSPORT_STORAGE"]["label"], "source_level": "企业/合作社自述",
            "source_name": product["organization"], "source_url": "", "detail": detail,
            "excerpt": detail, "published_at": "", "fetched_at": stamp, "expires_at": "",
            "status": "verified", "provided": True, "matches_batch": True,
            "verification_note": "由提交人填写，属于能力自述；实际履约前应核对车辆、仓容或合同。",
            "verified_by": "提交人", "verified_at": stamp, "snapshot": {}, "attachment": {},
            "origin": "batch_form", "bound_claims": [], "created_at": stamp,
        })
    return rows


def create(payload: dict, user: dict) -> dict:
    with LOCK:
        product_input = payload.get("product") if isinstance(payload.get("product"), dict) else payload
        product = _normalize_product(product_input)
        batch_id = "BAT-" + datetime.now().strftime("%Y%m%d") + "-" + secrets.token_hex(4).upper()
        photos = []
        for raw in (payload.get("photos") or [])[:MAX_PHOTOS]:
            if isinstance(raw, dict):
                photos.append(save_photo(batch_id, raw.get("data", ""), raw.get("caption", "")))
            elif isinstance(raw, str):
                photos.append(save_photo(batch_id, raw))
        stamp = now()
        batch = {
            "id": batch_id,
            "batch_code": f"YZYJ-{datetime.now().strftime('%y%m%d')}-{secrets.token_hex(2).upper()}",
            "owner_id": user["id"], "owner_username": user["username"],
            "created_at": stamp, "updated_at": stamp,
            "status": "draft", "mode": payload.get("mode", "web"),
            "product": product, "photos": photos, "evidence": _base_evidence(product),
            "sources": [], "followups": [], "claims": [], "gate": {},
            "content": {}, "compliance": {}, "plans": [], "channel_costs": [],
            "selected_plan_id": "", "feedback": {}, "agent": {},
            "timeline": [{"at": stamp, "action": "创建批次", "detail": "已保存产品档案和基础自述。"}],
        }
        for row in batch["evidence"]:
            row["snapshot"] = save_snapshot(batch_id, row["id"], row["detail"])
        _write(batch)
    audit_store.log("batch.create", user, "batch", batch_id,
                    {"product": product["name"], "weight_kg": product["batch_weight_kg"], "mode": batch["mode"]})
    return batch


def get(batch_id: str, user: dict | None = None, allow_admin: bool = True) -> dict | None:
    path = _path(batch_id)
    batch = _read_path(path) if path.exists() else None
    if not batch and user and allow_admin and user.get("role") == "admin":
        root = DATA_ROOT / "accounts"
        if root.exists():
            for candidate in root.glob(f"*/batches/{batch_id}.json"):
                batch = _read_path(candidate)
                if batch:
                    break
    if not batch:
        return None
    if user and batch.get("owner_id") != user.get("id") and not (allow_admin and user.get("role") == "admin"):
        return None
    return batch


def update(batch: dict, patch: dict, user: dict, action: str = "更新批次") -> dict:
    with LOCK:
        batch = copy.deepcopy(batch)
        if isinstance(patch.get("product"), dict):
            batch["product"] = _normalize_product(patch["product"], batch.get("product"))
            rows = [e for e in batch.get("evidence", []) if e.get("origin") != "batch_form"]
            for row in rows:
                if row.get("status") == "verified":
                    row.update({"status": "pending", "provided": False, "matches_batch": False, "verification_note": "档案已修改，须重新核对批次匹配关系"})
            base_rows = _base_evidence(batch["product"])
            for row in base_rows:
                row["snapshot"] = save_snapshot(batch["id"], row["id"], row["detail"])
            batch["evidence"] = base_rows + rows
            batch["status"] = "paused"
        if "mode" in patch and patch["mode"] not in ("web", "agent"):
            raise ValueError("分析模式无效")
        for key in ("mode", "selected_plan_id", "feedback"):
            if key in patch:
                batch[key] = patch[key]
        batch["updated_at"] = now()
        batch.setdefault("timeline", []).append({"at": now(), "action": action, "detail": "用户修改并保存。"})
        _write(batch)
    audit_store.log("batch.update", user, "batch", batch["id"], {"action": action, "fields": sorted(patch)})
    return batch


def list_mine(user: dict, limit: int = 100) -> list[dict]:
    rows = []
    for path in _batch_dir().glob("BAT-*.json"):
        batch = _read_path(path)
        if batch and batch.get("owner_id") == user.get("id"):
            rows.append(_summary(batch))
    rows.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
    return rows[:limit]


def list_all(limit: int = 500) -> list[dict]:
    rows = []
    root = DATA_ROOT / "accounts"
    if root.exists():
        for path in root.glob("*/batches/BAT-*.json"):
            batch = _read_path(path)
            if batch:
                rows.append(_summary(batch))
    rows.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
    return rows[:limit]


def _summary(batch: dict) -> dict:
    gates = batch.get("gate") or {}
    compliance = batch.get("compliance") or {}
    product = batch.get("product") or {}
    return {
        "id": batch.get("id"), "batch_code": batch.get("batch_code"),
        "owner_id": batch.get("owner_id"), "owner_username": batch.get("owner_username"),
        "product_name": product.get("name"), "origin": product.get("origin_address"),
        "organization": product.get("organization"), "weight_kg": product.get("batch_weight_kg"),
        "created_at": batch.get("created_at"), "updated_at": batch.get("updated_at"),
        "status": batch.get("status"), "mode": batch.get("mode"),
        "evidence_total": len(batch.get("evidence") or []),
        "evidence_verified": sum(1 for e in (batch.get("evidence") or []) if e.get("status") == "verified"),
        "claims_passed": gates.get("passed", 0), "claims_blocked": gates.get("blocked", 0),
        "compliance_level": compliance.get("level", ""),
        "best_plan": next((p.get("channel_name") for p in (batch.get("plans") or []) if p.get("is_best")), ""),
    }


def get_for_owner(batch_id: str, user: dict) -> dict:
    batch = get(batch_id, user)
    if not batch:
        raise ValueError("批次不存在或无权访问")
    return batch


def append_evidence(batch: dict, evidence: dict, user: dict) -> dict:
    with LOCK:
        batch = copy.deepcopy(batch)
        rows = batch.setdefault("evidence", [])
        if len(rows) >= 80:
            raise ValueError("单个批次证据数量已达上限")
        rows.append(evidence)
        batch["updated_at"] = now()
        batch.setdefault("timeline", []).append({"at": now(), "action": "添加证据", "detail": evidence.get("label", "")})
        _write(batch)
    audit_store.log("evidence.add", user, "batch", batch["id"],
                    {"evidence_id": evidence.get("id"), "type": evidence.get("type"), "status": evidence.get("status")})
    return batch


def add_manual_evidence(batch: dict, payload: dict, user: dict) -> dict:
    kind = payload.get("type")
    if kind not in EVIDENCE_TYPES:
        raise ValueError("请选择有效的证据类型")
    attachment = {}
    detail = _clean(payload.get("detail"), 4000, "材料内容", True)
    evidence_id = "EVD-" + secrets.token_hex(8)
    if payload.get("attachment"):
        attachment = save_attachment(batch["id"], payload["attachment"], payload.get("attachment_name", ""))
    snapshot = {} if attachment else save_snapshot(batch["id"], evidence_id, detail)
    stamp = now()
    evidence = {
        "id": evidence_id, "type": kind, "label": EVIDENCE_TYPES[kind]["label"],
        "source_level": payload.get("source_level") if payload.get("source_level") in SOURCE_LEVELS else "企业/合作社自述",
        "source_name": _clean(payload.get("source_name"), 180, "出具单位或来源名称"),
        "source_url": _clean(payload.get("source_url"), 2048, "来源链接"),
        "detail": detail,
        "excerpt": detail[:2500],
        "published_at": _clean(payload.get("published_at"), 40, "发布日期"),
        "fetched_at": stamp, "expires_at": _date_text(payload.get("expires_at"), "有效期"),
        "status": "pending", "provided": False, "matches_batch": bool(payload.get("matches_batch", False)),
        "verification_note": "待核验材料主体、批次和有效期。",
        "verified_by": "", "verified_at": "", "snapshot": snapshot, "attachment": attachment,
        "origin": "manual", "bound_claims": [], "created_at": stamp,
    }
    if evidence["source_url"]:
        parsed = urlsplit(evidence["source_url"])
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            raise ValueError("来源链接须为完整的 HTTP/HTTPS 地址")
    return append_evidence(batch, evidence, user)


def verify_evidence(batch: dict, evidence_id: str, payload: dict, user: dict) -> dict:
    decision = payload.get("decision")
    if decision not in ("verified", "rejected", "conflict", "pending"):
        raise ValueError("核验结论无效")
    reason = _clean(payload.get("reason"), 1000, "核验说明")
    if decision in ("rejected", "conflict") and len(reason) < 4:
        raise ValueError("拒绝或标记冲突时请填写不少于 4 个字的理由")
    with LOCK:
        batch = copy.deepcopy(batch)
        row = next((e for e in batch.get("evidence", []) if e.get("id") == evidence_id), None)
        if not row:
            raise ValueError("证据不存在")
        stamp = now()
        row["status"] = decision
        row["provided"] = decision == "verified"
        row["matches_batch"] = decision == "verified"
        row["verified_by"] = user.get("username", "") if decision != "pending" else ""
        row["verified_at"] = stamp if decision != "pending" else ""
        row["verification_note"] = reason or ("已确认材料与本批次相符" if decision == "verified" else "待补充核验")
        if decision == "verified" and row.get("expires_at"):
            try:
                if date.fromisoformat(row["expires_at"]) < date.today():
                    row["status"] = "expired"
                    row["provided"] = False
                    row["verification_note"] = (reason + "；" if reason else "") + "材料已过期。"
            except ValueError:
                pass
        batch["updated_at"] = stamp
        batch.setdefault("timeline", []).append({
            "at": stamp, "action": "证据核验", "detail": f"{row.get('label')}：{row.get('status')}；{row.get('verification_note', '')}"
        })
        _write(batch)
    audit_store.log("evidence.verify", user, "batch", batch["id"],
                    {"evidence_id": evidence_id, "decision": decision, "reason": reason})
    return batch


def remove_evidence(batch: dict, evidence_id: str, user: dict) -> dict:
    with LOCK:
        batch = copy.deepcopy(batch)
        rows = batch.get("evidence", [])
        target = next((e for e in rows if e.get("id") == evidence_id), None)
        if not target:
            raise ValueError("证据不存在")
        if target.get("type") in ("BATCH_RECORD", "TRANSPORT_STORAGE") and target.get("origin") == "batch_form":
            raise ValueError("批次基础自述不能删除，可通过修改档案更新")
        batch["evidence"] = [e for e in rows if e.get("id") != evidence_id]
        batch["updated_at"] = now()
        batch.setdefault("timeline", []).append({"at": now(), "action": "删除证据", "detail": target.get("label", "")})
        _write(batch)
    audit_store.log("evidence.remove", user, "batch", batch["id"], {"evidence_id": evidence_id})
    return batch


def add_photo(batch: dict, data_url: str, caption: str, user: dict) -> dict:
    if len(batch.get("photos", [])) >= MAX_PHOTOS:
        raise ValueError("每个批次最多上传 4 张产品照片")
    photo = save_photo(batch["id"], data_url, caption)
    with LOCK:
        batch = copy.deepcopy(batch)
        batch.setdefault("photos", []).append(photo)
        batch["updated_at"] = now()
        _write(batch)
    audit_store.log("photo.add", user, "batch", batch["id"], {"photo_id": photo["id"], "sha256": photo["sha256"]})
    return batch


def get_media(batch: dict, filename: str) -> tuple[Path, str] | None:
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}(?:\.[A-Za-z0-9]{2,5})?", filename or ""):
        return None
    from core.cloud_context import current_access, account_path
    from core.account_store import storage_id
    ctx = current_access()
    if ctx.get("kind") == "guest" or ctx.get("user_id") == batch.get("owner_id"):
        base = visitor_path()
    elif ctx.get("role") == "admin":
        base = account_path(storage_id(batch.get("owner_id", "")))
    else:
        return None
    root = base / "media" / batch["id"]
    path = (root / filename).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file():
        root = base / "snapshots" / batch["id"]
        path = (root / filename).resolve()
        if not path.is_relative_to(root.resolve()) or not path.is_file():
            return None
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    if path.suffix == ".txt":
        mime = "text/plain; charset=utf-8"
    return path, mime


def update_pipeline(batch: dict, patch: dict, user: dict, action: str) -> dict:
    with LOCK:
        batch = copy.deepcopy(batch)
        batch.update(patch)
        batch["updated_at"] = now()
        batch.setdefault("timeline", []).append({"at": now(), "action": action, "detail": patch.get("status_detail", "")})
        batch.pop("status_detail", None)
        _write(batch)
    audit_store.log(action, user, "batch", batch["id"], {"status": batch.get("status"), "mode": batch.get("mode")})
    return batch


def stats_for_user(user: dict) -> dict:
    rows = list_mine(user, 500)
    return {
        "batches": len(rows),
        "ready": sum(1 for r in rows if r.get("status") in ("analyzed", "reviewed", "exported")),
        "blocked": sum(1 for r in rows if r.get("claims_blocked", 0) > 0),
        "best_channels": len([r for r in rows if r.get("best_plan")]),
    }

