"""可解释的渠道测算与“1 最优 + 2 次优”方案选择。

所有金额均为基于用户录入价格、成本和渠道参数的情景测算，不表示销量承诺。
"""
from __future__ import annotations

import math
from datetime import datetime, timezone
from core import evidence as gate_mod


CHANNELS = [
    {
        "code": "wholesale", "name": "批发市场 / 产地经纪人",
        "buyer": "批发商、产地经纪人、档口采购",
        "communication": "以批次规格、分级、装车能力和稳定供货为核心，电话与报价单为主。",
        "price_factor": 0.56, "commission": 0.0, "packaging": 0.12,
        "logistics": 0.16, "loss": 0.02, "labor": 0.16, "complexity": 1,
        "min_weight": 100, "evidence": ["BATCH_RECORD", "GRADE_STANDARD"],
        "requirements": ["能按规格分级", "可集中装车", "能提供批次数量与出货时间"],
        "steps": ["确认当日批发市场同规格价格", "发送批次规格与实物照片", "抽样验货并锁定装车量", "签署或留存交易凭据", "回填实际成交与损耗"],
    },
    {
        "code": "group", "name": "社区团购 / 团长分销",
        "buyer": "社区团长、单位社群、周边居民",
        "communication": "短图文、小区试吃、拼团接龙和次日自提，强调规格、净重与到货时间。",
        "price_factor": 0.82, "commission": 0.04, "packaging": 0.55,
        "logistics": 0.45, "loss": 0.04, "labor": 0.52, "complexity": 3,
        "min_weight": 20, "evidence": ["BATCH_RECORD", "ORIGIN_PROOF", "PRICE_REF"],
        "requirements": ["可小批量分装", "能承诺发货与售后", "有稳定自提点或配送路线"],
        "steps": ["选择 5 公里内 2–3 个试销点", "用真实批次素材发起小规模拼团", "按订单分装并二次称重", "履约后收集退货与反馈", "核算实际利润再扩大"],
    },
    {
        "code": "supermarket", "name": "商超 / 生鲜门店",
        "buyer": "连锁商超、社区生鲜店、水果专营店",
        "communication": "以稳定规格、供货周期、检测材料和陈列卖点为主，先小批试销。",
        "price_factor": 0.76, "commission": 0.08, "packaging": 0.65,
        "logistics": 0.58, "loss": 0.05, "labor": 0.48, "complexity": 4,
        "min_weight": 200, "evidence": ["BATCH_RECORD", "TEST_REPORT", "GRADE_STANDARD"],
        "requirements": ["规格稳定", "可开票或提供合规主体资料", "能按门店节奏持续供货"],
        "steps": ["筛选匹配客群的 3 家门店", "准备样品、报价与检测材料", "确认账期、损耗承担和退换规则", "小批试销 7–14 天", "按动销与毛利复盘"],
    },
    {
        "code": "enterprise", "name": "企业采购 / 工会福利",
        "buyer": "企业行政、工会、员工福利服务商",
        "communication": "突出产地、批次、规格一致性和交付计划，使用礼盒样稿与采购说明。",
        "price_factor": 0.92, "commission": 0.02, "packaging": 0.95,
        "logistics": 0.62, "loss": 0.03, "labor": 0.72, "complexity": 4,
        "min_weight": 50, "evidence": ["BATCH_RECORD", "ORIGIN_PROOF", "TEST_REPORT"],
        "requirements": ["可定制包装", "能按期分批交付", "具备对公结算与售后能力"],
        "steps": ["确认预算、交付日期与收货点", "提供样品和真实批次材料", "锁定包装、净重与验收标准", "按合同节点交付", "回填验收、退货和回款"],
    },
    {
        "code": "ecommerce", "name": "电商店铺 / 平台商品页",
        "buyer": "全国消费者、礼盒买家和家庭用户",
        "communication": "商品详情页、短视频、直播切片与搜索关键词，强调可核验信息而非绝对化宣传。",
        "price_factor": 1.0, "commission": 0.06, "packaging": 1.05,
        "logistics": 1.15, "loss": 0.05, "labor": 0.95, "complexity": 5,
        "min_weight": 30, "evidence": ["BATCH_RECORD", "ORIGIN_PROOF", "PRICE_REF", "TEST_REPORT"],
        "requirements": ["具备电商履约能力", "包装可承受快递", "有售后和退货处理方案"],
        "steps": ["核对同类商品同规格价格", "完成详情页和售后规则", "上架小批量 SKU 试销", "记录曝光、成交、退货与投诉", "根据真实数据调整售价和素材"],
    },
    {
        "code": "coop", "name": "供销社 / 农产品集采平台",
        "buyer": "县域供销体系、集采平台、帮扶采购单位",
        "communication": "以主体真实、批次可追溯、供应稳定和带农信息为核心，提交规范供货材料。",
        "price_factor": 0.68, "commission": 0.01, "packaging": 0.32,
        "logistics": 0.36, "loss": 0.025, "labor": 0.28, "complexity": 2,
        "min_weight": 50, "evidence": ["BATCH_RECORD", "ORIGIN_PROOF", "TRANSPORT_STORAGE"],
        "requirements": ["主体资料完整", "可提供批次来源证明", "能按集采要求交付"],
        "steps": ["确认平台准入清单", "提交主体、批次和供货材料", "按标准报价并确认交付窗口", "集中分拣发货", "留存结算与验收结果"],
    },
    {
        "code": "shortvideo", "name": "短视频 / 社群内容传播",
        "buyer": "内容平台用户、本地社群和私域客户",
        "communication": "真实果园、分拣包装、试吃和批次证据短视频；口播不使用功效承诺和绝对化用语。",
        "price_factor": 1.05, "commission": 0.1, "packaging": 1.1,
        "logistics": 1.2, "loss": 0.08, "labor": 1.35, "complexity": 6,
        "min_weight": 15, "evidence": ["BATCH_RECORD", "ORIGIN_PROOF", "PROCESS_RECORD", "PRICE_REF"],
        "requirements": ["可持续产出真实素材", "具备私信或店铺承接能力", "能处理内容与售后投诉"],
        "steps": ["确定一个真实卖点和一个目标人群", "拍摄产地、分拣、称重与试吃", "发布 3–5 条小样本内容", "按咨询、成交和退货记录复盘", "只放大已核验的表达"],
    },
]


def _n(value, default=0.0) -> float:
    try:
        return float(value) if value not in (None, "") else float(default)
    except (TypeError, ValueError):
        return float(default)


def _round(value: float) -> float:
    return round(float(value), 2)


def _evidence_state(batch: dict) -> tuple[set[str], float, list[str]]:
    provided = gate_mod.build_state(batch.get("evidence", []))["provided"]
    total = len(batch.get("evidence", []))
    verified = sum(1 for e in batch.get("evidence", []) if gate_mod.usable(e) and e.get("type") in provided)
    completeness = min(1.0, verified / max(3, total)) if total else 0.0
    missing = sorted({t for e in batch.get("evidence", []) if not e.get("provided") for t in [e.get("type")] if t})
    return provided, completeness, missing


def _capability(batch: dict) -> dict:
    p = batch.get("product", {})
    weight = max(0.0, _n(p.get("batch_weight_kg")))
    transport_capacity = _n(p.get("transport_capacity_kg"), weight)
    daily = _n(p.get("daily_capacity_kg"), weight)
    transport = (p.get("transport") or "").strip()
    storage = (p.get("storage") or "").strip()
    return {
        "weight": weight,
        "transport_capacity": transport_capacity,
        "daily_capacity": daily,
        "has_transport": bool(transport),
        "has_storage": bool(storage),
        "is_cold_chain": any(word in transport + storage for word in ("冷链", "冷藏", "冷库", "保鲜")),
    }


def _price_and_cost(batch: dict) -> tuple[float, float, str]:
    p = batch.get("product", {})
    price = max(0.0, _n(p.get("unit_price_yuan_per_kg")))
    cost = max(0.0, _n(p.get("unit_cost_yuan_per_kg")))
    if price <= 0:
        import re
        verified_types = gate_mod.build_state(batch.get("evidence", []))["provided"]
        candidates = set()
        for evidence in batch.get("evidence", []):
            if "PRICE_REF" not in verified_types or evidence.get("type") != "PRICE_REF" or not gate_mod.usable(evidence):
                continue
            detail = evidence.get("detail", "")
            # Do not guess box/jin units or select an endpoint of a price range.
            if re.search(r"\d+(?:\.\d+)?\s*[-—–~～至]\s*\d+(?:\.\d+)?\s*元", detail):
                continue
            values = re.findall(r"(?<![\d.\-])([0-9]+(?:\.[0-9]{1,2})?)\s*元\s*(?:[/／]\s*(?:kg\b|公斤|千克)|每\s*(?:公斤|千克))", detail, re.I)
            candidates.update(float(v) for v in values if 0 < float(v) < 100000)
        if len(candidates) == 1:
            price = candidates.pop()
    basis = "用户录入" if _n(p.get("unit_price_yuan_per_kg")) > 0 else ("已核验价格证据（明确元/kg）" if price > 0 else "缺少明确的每公斤售价")
    return price, cost, basis


def _plan(batch: dict, template: dict, price: float, cost: float, cap: dict,
          evidence: set[str], completeness: float) -> dict:
    weight = cap["weight"]
    loss = template["loss"]
    saleable = weight * (1 - loss)
    revenue = saleable * price * template["price_factor"]
    product_cost = weight * cost
    packaging = weight * template["packaging"]
    logistics = weight * template["logistics"]
    commission = revenue * template["commission"]
    labor = weight * template["labor"]
    contingency = max(12.0, (product_cost + packaging + logistics + labor) * 0.02)
    total_cost = product_cost + packaging + logistics + commission + labor + contingency
    profit = revenue - total_cost
    profit_per_kg = profit / weight if weight else 0
    missing_types = [t for t in template["evidence"] if t not in evidence]
    capability_penalty = 0.0
    risk_notes = []
    if not cap["has_transport"]:
        capability_penalty += 8
        risk_notes.append("未填写运输工具，履约成本可能被低估。")
    if template["code"] in ("ecommerce", "shortvideo", "group", "supermarket") and not cap["has_storage"]:
        capability_penalty += 4
        risk_notes.append("未填写储存条件，生鲜损耗风险需要复核。")
    if weight > cap["daily_capacity"] > 0:
        capability_penalty += 5
        risk_notes.append("本批重量超过日发货能力，需要分批履约。")
    if weight > cap["transport_capacity"] > 0:
        capability_penalty += 3
        risk_notes.append("本批需要多趟运输。")
    if weight < template["min_weight"]:
        capability_penalty += 10
        risk_notes.append(f"本批重量低于该渠道建议起量 {template['min_weight']:g} kg，匹配度较低。")
    if missing_types:
        risk_notes.append("关键证据尚未全部核验：" + "、".join(missing_types) + "。")
    if price <= 0:
        risk_notes.append("缺少可核验售价，金额仅为成本框架，不能作为报价依据。")
    supported = weight >= template["min_weight"] and price > 0
    score = (profit_per_kg * (1.0 if supported else 0.2)
             + completeness * 22 + (7 - template["complexity"]) * 2
             - capability_penalty - len(missing_types) * 2.5)
    low = profit - abs(profit) * 0.22 - max(0, weight - cap["daily_capacity"]) * 0.05
    high = profit + abs(profit) * 0.13
    assumptions = [
        "渠道折价、损耗、运费和佣金为演示模型假设，不是实时市场数据；正式报价前需逐项核实。",
        f"预计 100% 可售，扣除 {loss:.0%} 损耗后按 {saleable:.1f} kg 计。",
        f"售价按用户期望价的 {template['price_factor']:.0%} 情景折算；未含税费和资金占用。",
        "禁止将其理解为销量、成交或利润承诺；必须以实际询价、合同和销售回填为准。",
    ]
    if price <= 0:
        assumptions.insert(0, "售价缺失，先完成价格补证或录入期望售价。")
    return {
        "id": "PLAN-" + template["code"].upper(), "channel_code": template["code"],
        "channel_name": template["name"], "buyer": template["buyer"],
        "communication": template["communication"], "requirements": template["requirements"],
        "execution_steps": template["steps"], "evidence_required": template["evidence"],
        "evidence_missing": missing_types, "risk_notes": risk_notes,
        "assumptions": assumptions, "supported": supported,
        "capability_match": max(0, 100 - capability_penalty * 5),
        "score": _round(score),
        "costs": {
            "product": _round(product_cost), "packaging": _round(packaging),
            "logistics": _round(logistics), "commission": _round(commission),
            "labor": _round(labor), "contingency": _round(contingency),
            "total": _round(total_cost),
        },
        "economics": {
            "unit_price": _round(price * template["price_factor"]),
            "saleable_kg": _round(saleable), "revenue": _round(revenue),
            "profit": _round(profit), "profit_per_kg": _round(profit_per_kg),
            "margin": _round((profit / revenue * 100) if revenue else 0),
            "profit_low": _round(low), "profit_high": _round(high),
        },
        "draft_assets_unreviewed": {
            "detail_page": f"{batch['product']['name']}｜{batch['product']['organization']}｜本批 {weight:g} kg。以已核验事实和实际规格为准。",
            "oral_script": f"这是{batch['product']['name']}，本批来自{batch['product']['organization']}。规格、产地证据和价格以下方商品页为准。",
            "social_post": f"{batch['product']['name']}本批到货，{weight:g} kg。真实批次、证据可查，按实际规格销售。",
        },
    }


def analyze(batch: dict) -> dict:
    price, cost, basis = _price_and_cost(batch)
    cap = _capability(batch)
    evidence, completeness, missing = _evidence_state(batch)
    plans = [_plan(batch, t, price, cost, cap, evidence, completeness) for t in CHANNELS]
    plans.sort(key=lambda p: (p["score"], p["economics"]["profit"]), reverse=True)
    for index, plan in enumerate(plans):
        plan["rank"] = index + 1
        plan["is_best"] = index == 0
        plan["is_alternative"] = index in (1, 2)
    return {
        "version": "channel-model-v1",
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "price_basis": basis, "expected_price": _round(price), "unit_cost": _round(cost),
        "capability": cap, "evidence_completeness": _round(completeness),
        "missing_evidence": missing,
        "all_plans": plans,
        "recommended_plans": plans[:3],
        "selection_note": "先计算全部 7 条渠道，再按净利润、证据完整度、能力匹配、执行复杂度和证据缺口综合排序；结果仅是可执行性建议。",
        "disclaimer": "平台不承诺销量、成交、最高利润或法律绝对合规。请询价、核验证据并回填真实销售结果。",
    }
