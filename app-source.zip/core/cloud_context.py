"""Request-scoped storage context.

登录用户的数据存放在 accounts/<storage_id>；游客只使用 guests/<storage_id>
临时目录，并在 cloud_app 中按 TTL 清理，不把游客输入当作长期历史记录。
"""
from __future__ import annotations

import os
import re
import shutil
import time
from contextvars import ContextVar
from pathlib import Path

VISITOR = ContextVar("visitor", default=None)
ACCESS = ContextVar("access", default=None)
DATA_ROOT = Path(os.environ.get("APP_DATA_DIR", Path(__file__).resolve().parents[1] / "runtime_data"))
GUEST_TTL_SECONDS = 2 * 60 * 60


def account_path(storage_id: str) -> Path:
    if not re.fullmatch(r"[a-f0-9]{48}", storage_id or ""):
        raise RuntimeError("Invalid account storage id")
    path = DATA_ROOT / "accounts" / storage_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def guest_path(storage_id: str) -> Path:
    if not re.fullmatch(r"[a-f0-9]{48}", storage_id or ""):
        raise RuntimeError("Invalid guest storage id")
    path = DATA_ROOT / "guests" / storage_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def visitor_path() -> Path:
    ctx = ACCESS.get() or {}
    sid = ctx.get("storage_id") or VISITOR.get()
    if not sid or not re.fullmatch(r"[a-f0-9]{48}", sid):
        raise RuntimeError("No authenticated storage context")
    if ctx.get("kind") == "guest" or not ctx:
        return guest_path(sid)
    return account_path(sid)


def set_access(kind: str, storage_id: str, user: dict | None = None):
    value = {"kind": kind, "storage_id": storage_id}
    if user:
        value.update({"user_id": user.get("id"), "username": user.get("username"), "role": user.get("role")})
    return ACCESS.set(value)


def reset_access(token) -> None:
    ACCESS.reset(token)


def current_access() -> dict:
    return dict(ACCESS.get() or {})


def cleanup_guests() -> int:
    root = DATA_ROOT / "guests"
    if not root.exists():
        return 0
    cutoff = time.time() - GUEST_TTL_SECONDS
    removed = 0
    for child in root.iterdir():
        try:
            if child.is_dir() and child.stat().st_mtime < cutoff:
                shutil.rmtree(child)
                removed += 1
        except OSError:
            continue
    return removed
