"""Request-scoped visitor storage; never share one visitor's ledger with another."""
from contextvars import ContextVar
from pathlib import Path
import os
import re

VISITOR = ContextVar('visitor', default=None)
DATA_ROOT = Path(os.environ.get('APP_DATA_DIR', Path(__file__).resolve().parents[1] / 'runtime_data'))

def visitor_path():
    visitor = VISITOR.get()
    if not visitor or not re.fullmatch(r'[a-f0-9]{48}', visitor):
        raise RuntimeError('No authenticated visitor context')
    path = DATA_ROOT / visitor
    path.mkdir(parents=True, exist_ok=True)
    return path
