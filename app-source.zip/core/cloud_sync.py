"""把 runtime_data 同步到 GitHub 仓库，充当持久存储。

Render 免费实例的磁盘是临时的：重启、重新部署、休眠唤醒都会清空。
这里把整个数据目录打成 tar.gz，通过 GitHub Contents API 提交到指定仓库，
进程启动时再拉回来，于是"注册的账号 / 批次数据"在实例重启后仍然存在。

只在配置了 SYNC_TOKEN 与 SYNC_REPO 时生效；否则完全空转，不改变原有行为。
"""
from __future__ import annotations

import base64
import io
import json
import os
import tarfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

DEFAULT_PATH = "store/yzyj-data.tar.gz"
API = "https://api.github.com/repos/{repo}/contents/{path}"
LOCK = threading.RLock()
STATE = {"booted": False, "dirty": False, "error": "", "last_push": 0.0, "rev": ""}


def _token() -> str:
    return (os.environ.get("SYNC_TOKEN") or os.environ.get("GH_PAT") or "").strip()


def _repo() -> str:
    return (os.environ.get("SYNC_REPO") or "").strip().strip("/")


def _remote_path() -> str:
    return (os.environ.get("SYNC_PATH") or DEFAULT_PATH).strip().lstrip("/")


def _branch() -> str:
    return (os.environ.get("SYNC_BRANCH") or "main").strip()


def _interval() -> int:
    try:
        return max(5, int(os.environ.get("SYNC_INTERVAL") or "25"))
    except ValueError:
        return 25


def configured() -> bool:
    return bool(_token() and _repo())


def _data_root() -> Path:
    from core.cloud_context import DATA_ROOT

    return Path(DATA_ROOT)


def _request(url: str, method: str = "GET", payload: dict | None = None, timeout: int = 30):
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", "Bearer " + _token())
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("X-GitHub-Api-Version", "2022-11-28")
    req.add_header("User-Agent", "yzyj-cloud-sync")
    if data is not None:
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8") or "{}")


def _fetch_remote() -> tuple[bytes | None, str]:
    """返回 (tar.gz 字节, blob sha)；不存在时返回 (None, "")。"""
    url = API.format(repo=_repo(), path=_remote_path()) + "?ref=" + _branch()
    try:
        meta = _request(url)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return None, ""
        raise
    if isinstance(meta, list):
        meta = meta[0] if meta else {}
    sha = meta.get("sha", "")
    encoded = (meta.get("content") or "").replace("\n", "")
    if encoded:
        return base64.b64decode(encoded), sha
    download = meta.get("download_url")
    if download:
        with urllib.request.urlopen(download, timeout=60) as resp:
            return resp.read(), sha
    return None, sha


def _pack(root: Path) -> bytes:
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
        for path in sorted(root.rglob("*")):
            rel = path.relative_to(root)
            if rel.parts and rel.parts[0] == "guests":
                continue
            if path.is_file():
                archive.add(str(path), arcname=str(rel))
    return buffer.getvalue()


def _unpack(raw: bytes, root: Path, primary: bool) -> int:
    """primary=True 时直接覆盖；否则仅补缺，避免覆盖正在写的数据。"""
    count = 0
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
        for member in archive.getmembers():
            if not member.isfile():
                continue
            name = member.name.replace("\\", "/")
            if name.startswith("/") or ".." in name.split("/"):
                continue
            target = root / name
            if not primary and target.exists() and target.stat().st_size > 0:
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            extracted = archive.extractfile(member)
            if extracted is None:
                continue
            target.write_bytes(extracted.read())
            count += 1
    return count


def restore() -> dict:
    """启动时把远端的快照铺回数据目录。"""
    if not configured():
        return {"ok": False, "reason": "未配置 SYNC_TOKEN / SYNC_REPO"}
    root = _data_root()
    root.mkdir(parents=True, exist_ok=True)
    try:
        raw, sha = _fetch_remote()
        if not raw:
            STATE["rev"] = sha
            return {"ok": True, "restored": 0, "reason": "远端还没有快照"}
        count = _unpack(raw, root, primary=True)
        STATE["rev"] = sha
        return {"ok": True, "restored": count}
    except Exception as exc:  # noqa: BLE001 - 同步失败不能影响站点启动
        STATE["error"] = f"restore failed: {exc}"
        return {"ok": False, "reason": STATE["error"]}


def push() -> dict:
    """把当前数据目录提交到仓库（同一个路径，覆盖式提交）。"""
    if not configured():
        return {"ok": False, "reason": "未配置"}
    root = _data_root()
    if not root.exists():
        return {"ok": False, "reason": "数据目录不存在"}
    with LOCK:
        try:
            raw = _pack(root)
            encoded = base64.b64encode(raw).decode("ascii")
            payload = {
                "message": "sync: runtime data snapshot",
                "content": encoded,
                "branch": _branch(),
            }
            if STATE.get("rev"):
                payload["sha"] = STATE["rev"]
            else:
                _, sha = _fetch_remote()
                if sha:
                    payload["sha"] = sha
                    STATE["rev"] = sha
            result = _request(API.format(repo=_repo(), path=_remote_path()), "PUT", payload, timeout=60)
            content = result.get("content") or {}
            STATE["rev"] = content.get("sha", STATE.get("rev", ""))
            STATE["last_push"] = time.time()
            STATE["dirty"] = False
            STATE["error"] = ""
            return {"ok": True, "bytes": len(raw)}
        except Exception as exc:  # noqa: BLE001
            STATE["error"] = f"push failed: {exc}"
            STATE["dirty"] = True
            return {"ok": False, "reason": STATE["error"]}


def mark_dirty() -> None:
    if configured():
        STATE["dirty"] = True


def _loop() -> None:
    while True:
        time.sleep(_interval())
        if STATE.get("dirty"):
            push()


def boot() -> dict:
    """第一次请求前调用：拉取远端快照并启动后台同步线程。"""
    if STATE["booted"]:
        return {"ok": True, "skipped": True}
    STATE["booted"] = True
    if not configured():
        return {"ok": False, "reason": "未配置"}
    outcome = restore()
    thread = threading.Thread(target=_loop, name="cloud-sync", daemon=True)
    thread.start()
    return outcome


def status() -> dict:
    return {
        "configured": configured(),
        "repo": _repo(),
        "path": _remote_path(),
        "branch": _branch(),
        "dirty": bool(STATE.get("dirty")),
        "last_push": STATE.get("last_push", 0.0),
        "error": STATE.get("error", ""),
    }
