"""双通道合规审查 —— 通道 A：本地确定性规则引擎。

之所以要有这一通道，是因为大模型做合规审查有三个绕不开的问题：
  1) 同一段文字两次审查结果可能不同（不可复现）；
  2) 命中后说不清依据是哪条法规（不可溯源）；
  3) 会漏掉它没见过的低概率表述（不可穷尽兜底）。

所以产品把审查拆成两层：确定性规则打底（本文件），大模型做长尾补充（core/llm.py）。
规则命中一定带法规出处，且结果可复现——这一点在政务类发布单位是硬要求。
"""

from __future__ import annotations

import json
import re
from pathlib import Path

RULES_PATH = Path(__file__).resolve().parent.parent / "data" / "rules" / "compliance_rules.json"

# 证据类型 -> 规则：若对应证据已提供，则该规则从『违规』降级为『已具备依据，须在文案中标注』
EVIDENCE_DOWNGRADE = {
    "R03": "GRADE_STANDARD",
    "R04": "TEST_REPORT",
    "R05": "GI_CERT",
    "R06": "GREEN_CERT",
}

SEVERITY_WEIGHT = {"blocker": 40, "high": 22, "medium": 10, "low": 4, "notice": 0}

# 引证标识：出现这些内容说明作者已经标注了出处
CITATION_RE = re.compile(r"(GB/?T\s?\d|NY/?T\s?\d|SC/T|第\s?\d+(\.\d+)?\s?条|报告编号|证书编号|检测机构|—\s?\d{4})")

# 全文级出处声明：一段文案里出现一次「以上…均出自/引自…」即可视为整段已标注出处
GLOBAL_CITE_RE = re.compile(r"(以上|下列|下述|本文|全文|全文数据)[^。；\n]{0,14}(出自|引自|来源|参照|依据|均按|均见)")


def load_rules() -> dict:
    return json.loads(RULES_PATH.read_text(encoding="utf-8"))


def _has_citation(text: str, start: int, end: int, window: int = 80) -> bool:
    seg = text[max(0, start - window): min(len(text), end + window)]
    if CITATION_RE.search(seg):
        return True
    # 全文级出处声明：「以上/下列…均出自 GB/T 18965-2008」也算已注明出处
    if CITATION_RE.search(text) and GLOBAL_CITE_RE.search(text):
        return True
    return False


def review(text: str, evidence: list[dict] | None = None) -> dict:
    """对一段文案执行通道 A 审查。"""
    rules = load_rules()
    provided = {e["type"] for e in (evidence or []) if e.get("provided")}
    hits: list[dict] = []
    citations_ok: list[dict] = []

    for rule in rules["rules"]:
        # 1) 关键词命中
        for term in rule.get("terms", []):
            for m in re.finditer(re.escape(term), text):
                hits.append(_build_hit(rule, term, m.start(), m.end(), text, provided, citations_ok))

        # 2) 正则命中（用于「数字未标出处」这类模式）
        for pattern in rule.get("regex", []):
            for m in re.finditer(pattern, text):
                matched = m.group(0).strip()
                if _has_citation(text, m.start(), m.end()):
                    citations_ok.append(
                        {
                            "rule_id": rule["id"],
                            "rule_name": rule["name"],
                            "matched": matched,
                            "note": "该数字附近已标注标准条款或报告出处，按规则第四条视为合规引证。",
                        }
                    )
                    continue
                hits.append(_build_hit(rule, matched, m.start(), m.end(), text, provided, citations_ok))

    # 去重（同一规则同一位置）
    seen = set()
    uniq = []
    for h in hits:
        key = (h["rule_id"], h["position"])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(h)
    uniq.sort(key=lambda h: (-SEVERITY_WEIGHT.get(h["severity"], 0), h["position"]))

    counts = {"blocker": 0, "high": 0, "medium": 0, "notice": 0}
    for h in uniq:
        counts[h["severity"]] = counts.get(h["severity"], 0) + 1

    penalty = sum(SEVERITY_WEIGHT.get(h["severity"], 0) for h in uniq)
    score = max(0, 100 - penalty)
    if counts["blocker"]:
        level = "blocker"
        level_text = "不可发布：存在一票否决级风险"
    elif counts["high"]:
        level = "high"
        level_text = "高风险：须整改后方可发布"
    elif counts["medium"]:
        level = "medium"
        level_text = "需调整：存在可优化风险项"
    else:
        level = "pass"
        level_text = ("通过：未发现规则命中" if not counts.get("notice")
                      else f"通过，但有 {counts['notice']} 条提示项需在成稿时确认")

    return {
        "channel": "A / 本地规则引擎",
        "ruleset_version": rules["version"],
        "ruleset_sources": rules["sources"],
        "hits": uniq,
        "citations_ok": citations_ok,
        "counts": counts,
        "score": score,
        "level": level,
        "level_text": level_text,
        "rules_total": len(rules["rules"]),
    }


def _build_hit(rule, matched, start, end, text, provided, citations_ok) -> dict:
    severity = rule["severity"]
    evidence_note = ""

    downgrade_type = EVIDENCE_DOWNGRADE.get(rule["id"])
    if downgrade_type:
        if downgrade_type in provided:
            severity = "notice"
            evidence_note = "该产品档案中已提供对应证据，表述可保留，但必须在文案中标注依据（证书编号 / 报告编号 / 标准条款）。"
        else:
            evidence_note = "产品档案中未提供对应证据，不可直接使用该表述。"

    # 「引证未标出处」如果已经带出处，前面已归入 citations_ok，不会到这里

    snippet = text[max(0, start - 14): min(len(text), end + 14)]

    return {
        "rule_id": rule["id"],
        "rule_name": rule["name"],
        "category": rule["category"],
        "severity": severity,
        "matched": matched,
        "position": start,
        "snippet": snippet,
        "basis": rule["basis"],
        "context_note": rule.get("context_note", ""),
        "advice": rule["advice"],
        "evidence_note": evidence_note,
    }


def rules_public() -> dict:
    """给前端展示用：规则清单（不含内部实现细节）。"""
    data = load_rules()
    return {
        "version": data["version"],
        "sources": data["sources"],
        "rules": [
            {
                "id": r["id"],
                "name": r["name"],
                "severity": r["severity"],
                "category": r["category"],
                "basis": r["basis"],
                "terms": r.get("terms", []),
                "context_note": r.get("context_note", ""),
                "advice": r["advice"],
            }
            for r in data["rules"]
        ],
    }
