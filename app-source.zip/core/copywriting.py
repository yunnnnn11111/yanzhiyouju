"""把批次事实写成能读、能传播的人话。

约束：只使用批次档案字段与已通过证据门禁的主张；不新增任何数字、认证、等级、
功效或绝对化表述。字段缺失时整句省略，不用占位符。
"""

from __future__ import annotations

import re

MONTH_DAY = re.compile(r"^(\d{4})-(\d{2})-(\d{2})")

SHORT_LABELS = {
    "BATCH_RECORD": "批次档案",
    "TRANSPORT_STORAGE": "运输仓储记录",
    "ORIGIN_PROOF": "产地记录",
    "GI_CERT": "地理标志证明",
    "GRADE_STANDARD": "等级依据",
    "TEST_REPORT": "检测报告",
    "PRICE_REF": "价格依据",
    "PROCESS_RECORD": "工艺记录",
    "GREEN_CERT": "认证证书",
    "SALES_DATA": "销售数据",
    "USER_FEEDBACK": "用户反馈",
}


def _month_day(value: str) -> str:
    m = MONTH_DAY.match(str(value or "").strip())
    if not m:
        return ""
    return f"{int(m.group(2))} 月 {int(m.group(3))} 日"


def _place(address: str) -> str:
    text = str(address or "").strip()
    if not text:
        return ""
    parts = [x for x in re.split(r"[省市县区]", text) if x]
    return parts[-1] if parts else text


def _weight(kg) -> str:
    try:
        num = float(kg)
    except (TypeError, ValueError):
        return ""
    if not num:
        return ""
    return f"{num:g} 公斤"


def _look(product: dict) -> str:
    bits = []
    for key in ("variety", "grade", "spec"):
        value = str(product.get(key) or "").strip()
        if value and value not in bits:
            bits.append(value)
    return "，".join(bits)


def _cold(product: dict) -> list[str]:
    lines = []
    transport = str(product.get("transport") or "").strip()
    storage = str(product.get("storage") or "").strip()
    if transport:
        lines.append(f"运输：{transport}")
    if storage:
        lines.append(f"仓储：{storage}")
    return lines


def _labels(passed: list[dict], evidence_types: dict) -> str:
    names = []
    for claim in passed:
        for key in claim.get("required_evidence", []) or []:
            label = SHORT_LABELS.get(key) or (evidence_types.get(key) or {}).get("label") or key
            if label not in names:
                names.append(label)
    return "、".join(names)


def _deal(plan: dict) -> str:
    bits = []
    buyer = str(plan.get("buyer") or "").strip()
    if buyer:
        bits.append(f"对接{buyer}")
    steps = plan.get("execution_steps") or []
    if steps:
        bits.append(str(steps[0]))
    return "，".join(bits) or "先确认规格和发货时间"


def build(batch: dict, passed: list[dict], plan: dict, evidence_types: dict) -> dict:
    product = batch.get("product", {}) or {}
    name = str(product.get("name") or "本批产品").strip()
    org = str(product.get("organization") or "").strip()
    place = _place(product.get("origin_address"))
    look = _look(product)
    weight = _weight(product.get("batch_weight_kg"))
    picked = _month_day(product.get("harvest_date"))
    packed = _month_day(product.get("package_date"))
    cold = _cold(product)
    labels = _labels(passed, evidence_types)
    deal = _deal(plan)
    channel = str(plan.get("channel_name") or "").strip()

    place_note = place and place not in name
    when = f"{picked}采摘" if picked else (f"{packed}装箱" if packed else "")

    cover = name + (f"｜{place}" if place_note else "")
    detail_parts = [f"{cover}，{when}的这一批" if when else cover]
    line = f"这是{org}交来的{name}" if org else f"这是{name}"
    if weight:
        line += f"，整批 {weight}"
    detail_parts.append(line + "。")
    if look:
        detail_parts.append(f"果子本身：{look}。")
    if cold:
        detail_parts.append("怎么运、怎么存：" + "；".join(x.split("：", 1)[-1] for x in cold) + "。")
    if labels:
        detail_parts.append(f"能查的：{labels}，都在这一批的档案里，点开就能看到。")
    detail_parts.append("查不到的我们不写：没有检测报告的农残、没有依据的甜度和功效，一句都不编。")
    tail = f"想拿货：{deal}。"
    if channel:
        tail += f"走{channel}这条线，价格随行，发货前按当天行情确认。"
    else:
        tail += "价格随行，发货前按当天行情确认。"
    detail_parts.append(tail)

    sentences = []
    lead = name + (f"，{place}的" if place_note else "")
    if picked:
        lead += f"，{picked}采的"
    sentences.append(lead + "。")
    look_short = "，".join([x for x in (str(product.get("variety") or "").strip(), str(product.get("grade") or "").strip()) if x])
    mid = [x for x in (look_short, f"整批 {weight}" if weight else "") if x]
    if mid:
        sentences.append("，".join(mid) + "。")
    if cold:
        sentences.append("；".join(x.split("：", 1)[-1] for x in cold) + "。")
    sentences.append("要多少？先看货，价按当天行情报。")
    if labels:
        sentences.append(f"{labels}都能查。")
    oral = "".join(sentences)

    social_lines = [f"🍎 {cover}" + (f"｜{look}" if look else "") + (f"｜{when}的" if when else "")]
    if weight:
        social_lines.append(f"整批 {weight}，可拆单商量")
    if cold:
        social_lines.append("；".join(x.split("：", 1)[-1] for x in cold))
    if labels:
        social_lines.append(f"能查的：{labels}")
    social_lines.append("不敢保证的一句不写，要货私信我")
    social = "\n".join(social_lines)

    return {
        "detail_page": "\n\n".join(detail_parts),
        "oral_script": oral,
        "social_post": social,
        "source": "local",
        "model": "本地人话模板 r50",
    }
