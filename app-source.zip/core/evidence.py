"""证据门禁（Evidence Gate）——本产品最核心的确定性环节。

设计原则：
- 大模型只负责『提出主张 + 声明需要什么证据』，不参与『是否通过』的判定。
- 门禁是完全确定性的：主张声明的 required_evidence 集合，必须是用户已提供证据集合的子集。
- 门槛不放宽：缺证据就锁死该主张，并给出补证建议。人可以连续两次确认强行采纳，
  但会被写入台账并标记为『人工豁免』——责任落到人，而不是模型。
"""

from __future__ import annotations

EVIDENCE_TYPES: dict[str, dict] = {
    "GI_CERT": {
        "label": "地理标志授权 / 保护范围证明",
        "how_to": "地理标志产品公告、保护范围文件，或授权使用证明。烟台苹果可引用 GB/T 18965-2008 第 4 章保护范围。",
    },
    "TEST_REPORT": {
        "label": "第三方检测报告",
        "how_to": "具备 CMA/CNAS 资质的检测机构出具。鲜苹果按 GB/T 10651 检验可溶性固形物、硬度，按 NY/T 1075 检验农残。",
    },
    "ORIGIN_PROOF": {
        "label": "产地与种植记录",
        "how_to": "地块位置、种植管理记录、采摘时间与现场照片，能证明产自宣称的产地。",
    },
    "PROCESS_RECORD": {
        "label": "种植 / 加工 / 采收工艺记录",
        "how_to": "套袋、去袋、摘叶转果、反光膜等作业的时间记录与照片，或对应的标准条款。",
    },
    "GRADE_STANDARD": {
        "label": "等级判定依据",
        "how_to": "按 GB/T 18965-2008 表 1 记录果径、着色面比例等指标的检验结果。",
    },
    "GREEN_CERT": {
        "label": "绿色食品 / 有机 / 无公害认证",
        "how_to": "认证证书原件，绿色食品须能与证书编号一并使用。",
    },
    "PRICE_REF": {
        "label": "同类产品价格对比依据",
        "how_to": "同规格竞品公开售价截图，须带时间戳与链接。",
    },
    "SALES_DATA": {
        "label": "销量 / 复购数据",
        "how_to": "平台后台截图或可公开核验的销量页面。",
    },
    "USER_FEEDBACK": {
        "label": "真实用户反馈",
        "how_to": "可溯源的评价、回访记录或授权使用的反馈截图。",
    },
}


def build_state(evidence: list[dict]) -> dict:
    """把产品档案里的证据清单转成门禁可用的状态表。"""
    provided = {e["type"] for e in evidence if e.get("provided")}
    missing = {e["type"] for e in evidence if not e.get("provided")}
    return {
        "provided": provided,
        "missing": missing,
        "by_type": {e["type"]: e for e in evidence},
    }


def check_claim(claim: dict, state: dict) -> dict:
    """对单条主张执行门禁，返回带判定结果的主张。"""
    required = claim.get("required_evidence") or []
    required = [r for r in required if r in EVIDENCE_TYPES]

    if not required:
        return claim | {
            "gate": "BLOCK",
            "gate_reason": "该主张未声明任何证据类型，无法验证，按规则不予放行。",
            "missing_evidence": [],
            "missing_detail": [],
        }

    lacking = [r for r in required if r not in state["provided"]]
    if lacking:
        return claim | {
            "gate": "BLOCK",
            "gate_reason": "缺少 %d 类必备证据，该主张暂不可使用。" % len(lacking),
            "missing_evidence": lacking,
            "missing_detail": [
                {
                    "type": r,
                    "label": EVIDENCE_TYPES[r]["label"],
                    "how_to": EVIDENCE_TYPES[r]["how_to"],
                }
                for r in lacking
            ],
        }

    return claim | {
        "gate": "PASS",
        "gate_reason": "证据齐备：%s" % "、".join(EVIDENCE_TYPES[r]["label"] for r in required),
        "missing_evidence": [],
        "missing_detail": [],
    }


def run_gate(claims: list[dict], evidence: list[dict]) -> dict:
    state = build_state(evidence)
    checked = [check_claim(c, state) for c in claims]
    passed = [c for c in checked if c["gate"] == "PASS"]
    blocked = [c for c in checked if c["gate"] == "BLOCK"]

    # 证据缺口汇总：按缺失类型统计有多少条主张被卡住
    gap: dict[str, dict] = {}
    for c in blocked:
        for m in c["missing_detail"]:
            item = gap.setdefault(
                m["type"],
                {"type": m["type"], "label": m["label"], "how_to": m["how_to"], "blocked_claims": 0},
            )
            item["blocked_claims"] += 1

    return {
        "claims": checked,
        "summary": {
            "total": len(checked),
            "passed": len(passed),
            "blocked": len(blocked),
            "pass_rate": round(len(passed) / len(checked) * 100) if checked else 0,
        },
        "evidence_gaps": sorted(gap.values(), key=lambda x: -x["blocked_claims"]),
        "provided_count": len(state["provided"]),
        "evidence_total": len(EVIDENCE_TYPES),
    }
