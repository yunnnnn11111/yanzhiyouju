"""Editable visitor evidence; search results remain unconfirmed leads."""
import copy
import json
import re
import uuid
from datetime import datetime, timezone
from urllib.parse import urlsplit
from core.cloud_context import visitor_path
from core.evidence import EVIDENCE_TYPES
from core import web_search, web_extract

KEYWORDS = {
 'GI_CERT':['地理标志','保护范围','GB/T 18965'],
 'ORIGIN_PROOF':['产地','种植基地','果园','采摘'],
 'PROCESS_RECORD':['套袋','加工','种植技术','工艺','采收'],
 'TEST_REPORT':['检测报告','农残','糖度','检验报告','检验检测'],
 'GRADE_STANDARD':['等级','分级','特级','果径','标准'],
 'GREEN_CERT':['绿色食品','有机认证','证书','认证'],
 'PRICE_REF':['价格','售价','报价','元/','元／','多少钱'],
 'USER_FEEDBACK':['评价','用户反馈','回访','买家','口碑'],
 'SALES_DATA':['销量','复购','销售额','成交','订单'],
}

def now(): return datetime.now(timezone.utc).isoformat()
def _load():
    p=visitor_path()/'evidence_workspace.json'
    return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
def _write(data):
    p=visitor_path()/'evidence_workspace.json'
    tmp=p.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(p)

def text(value, limit, label):
    if not isinstance(value,str) or len(value)>limit: raise ValueError(f'{label}须为不超过 {limit} 字的文本')
    return value.strip()

def public_link(value):
    value=text(value,2048,'来源链接')
    if not value: return ''
    try:
        p=urlsplit(value)
        if p.scheme not in ('https','http') or not p.hostname or p.username or p.password or p.port not in (None,80,443): raise ValueError()
    except ValueError: raise ValueError('来源链接须为不含账号密码的 HTTP/HTTPS 地址')
    if any(ord(c)<32 for c in value): raise ValueError('来源链接包含无效字符')
    return value

def product_with_evidence(product):
    out=copy.deepcopy(product)
    saved=_load().get(product['id'],{})
    rows={e['type']:e for e in saved.get('evidence',[])}
    for i,e in enumerate(out.get('evidence',[])):
        if e['type'] in rows: out['evidence'][i]={**e,**rows[e['type']]}
    out['evidence_updated_at']=saved.get('updated_at','')
    return out

def normalize(product, rows):
    if not isinstance(rows,list) or len(rows)>len(EVIDENCE_TYPES): raise ValueError('证据清单格式无效')
    defaults={e['type']:e for e in product['evidence']}
    out=[]; seen=set()
    for row in rows:
        if not isinstance(row,dict) or row.get('type') not in defaults or row['type'] in seen: raise ValueError('证据类型无效或重复')
        kind=row['type']; seen.add(kind); original=defaults[kind]
        detail=text(row.get('detail',''),4000,'材料内容')
        source=text(row.get('source',''),500,'材料来源')
        url=public_link(row.get('url',''))
        confirmed=row.get('confirmed',False); provided=row.get('provided',False)
        if not isinstance(confirmed,bool) or not isinstance(provided,bool): raise ValueError('确认状态须为布尔值')
        unchanged=all(row.get(k,'')==original.get(k,'') for k in ('detail','source','url'))
        previous=unchanged and original.get('provided',False)
        if (provided or confirmed) and not previous and not (confirmed and len(detail)>=6 and (url or source not in ('','—'))):
            raise ValueError(f'{original["label"]}：请填写材料内容、来源，并确认与本产品或批次相符')
        item={'type':kind,'label':original['label'],'detail':detail,'source':source,'url':url,
              'confirmed':bool(confirmed or previous),'provided':provided,'verified':False,
              'verification':'用户确认' if confirmed or previous else '待人工核验',
              'updated_at':now(),'origin':text(row.get('origin','manual'),30,'来源方式')}
        for k in ('matched_at','fetched_at','source_title','candidate_id'):
            item[k]=text(row.get(k,''),500,k)
        out.append(item)
    return out

def save(product,rows):
    normalized=normalize(product,rows)
    data=_load(); entry=data.setdefault(product['id'],{})
    old={e['type']:e for e in entry.get('evidence',[])}
    old.update({e['type']:e for e in normalized})
    entry.update(evidence=list(old.values()),updated_at=now())
    _write(data)
    return product_with_evidence(product)

def search(product,query,kind=''):
    if kind and kind not in EVIDENCE_TYPES: raise ValueError('未知证据类型')
    query=text(query,200,'搜索关键词')
    if not query: query=web_search.build_query(product, ' '.join(KEYWORDS[kind][:2]) if kind else '')
    engine,results,errors=web_search.search(query,limit=8)
    candidates=[]; timestamp=now()
    product_name=web_search.build_query(product)
    for result in results:
        hay=re.sub(r'\s+','',result.title+' '+result.snippet)
        matches=[k for k,words in KEYWORDS.items() if any(word.lower() in hay.lower() for word in words)]
        item={**result.as_dict(),'id':uuid.uuid4().hex,'matched_types':matches,'searched_at':timestamp,
              'product_match':bool(product_name and product_name.lower() in hay.lower()),'verified':False,
              'match_note':'关键词匹配，仅供核验；不代表本产品获证、检测合格或具有相应销量。'}
        candidates.append(item)
    candidates.sort(key=lambda c:(bool(kind and kind in c['matched_types']),c['product_match'],len(c['matched_types'])),reverse=True)
    data=_load(); entry=data.setdefault(product['id'],{})
    entry['candidates']=(entry.get('candidates',[])+candidates)[-50:]
    _write(data)
    return {'ok':True,'query':query,'engine':engine,'results':candidates,'searched_at':timestamp,
            'errors':['部分搜索来源未返回结果'] if errors else []}

def extract(product,candidate_id='',url='',kind=''):
    if kind not in EVIDENCE_TYPES: raise ValueError('请选择证据类型')
    candidate=None
    if candidate_id:
        candidate=next((c for c in _load().get(product['id'],{}).get('candidates',[]) if c['id']==candidate_id),None)
        if not candidate: raise ValueError('候选来源已失效，请重新搜索')
        url=candidate['url']
    url=public_link(url)
    if not url: raise ValueError('请填写来源网页链接')
    page=web_extract.fetch(url,timeout=10)
    if len(page.text.strip())<40: raise ValueError('网页正文不足，请手动填写材料或换一个公开来源')
    words=KEYWORDS[kind]; segments=re.split(r'(?<=[。！？；])|\n',page.text)
    relevant=[s.strip() for s in segments if any(w.lower() in s.lower() for w in words)]
    excerpt='\n'.join(relevant)[:2800] if relevant else page.text[:1600]
    return {'ok':True,'draft':{'type':kind,'detail':excerpt,'source':page.title[:500],'url':page.url,
              'source_title':page.title[:500],'fetched_at':page.fetched_at,'matched_at':now(),
              'candidate_id':candidate_id,'origin':'web','confirmed':False,'provided':False,'verified':False},
            'matched':bool(relevant),'notice':'已读取网页并填入草稿。请核对主体、批次、有效期及原件，再确认作为证据。'}
