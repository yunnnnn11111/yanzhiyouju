"""台账（Ledger）：所有运行、人工干预、导出的可审计留痕。

为什么用一个本地 JSON 而不是数据库：
- 评审现场零安装即可跑；
- 台账要能被评委直接打开看，JSON 最透明；
- 数据量是「一天几十条」的量级，不存在性能问题。

每条记录都保留输入快照与提示词版本，保证事后可复现「当时为什么不许发」。
"""

from __future__ import annotations

import json
import threading
import uuid
from core.cloud_context import visitor_path
import time
from datetime import datetime
from pathlib import Path

def ledger_path():
    return visitor_path() / "ledger.json"
_lock = threading.Lock()


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _load() -> list[dict]:
    if not ledger_path().exists():
        return []
    try:
        return json.loads(ledger_path().read_text(encoding="utf-8"))
    except Exception:
        return []


def _save(records: list[dict]) -> None:
    ledger_path().parent.mkdir(parents=True, exist_ok=True)
    tmp = ledger_path().with_suffix(".tmp")
    tmp.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(ledger_path())


def new_id() -> str:
    return "RUN-" + datetime.now().strftime("%Y%m%d") + "-" + uuid.uuid4().hex[:12]


def create(product: dict, mode: str, prompt_versions: dict) -> dict:
    record = {
        "id": new_id(),
        "created_at": _now(),
        "updated_at": _now(),
        "product_id": product["id"],
        "product_name": product["name"],
        "mode": mode,
        "status": "草稿",
        "prompt_versions": prompt_versions,
        "input_snapshot": {
            "price": product.get("price"),
            "region": product.get("region"),
            "evidence": [
                {"type": e["type"], "label": e["label"], "provided": bool(e.get("provided")),
                 "source": e.get("source", "")}
                for e in product.get("evidence", [])
            ],
        },
        "stages": [],
        "claims": [],
        "gate_summary": {},
        "adopted_claim_ids": [],
        "content": None,
        "compliance": None,
        "decisions": [],
        "final_content": None,
        "llm_notes": [],
    }
    with _lock:
        records = _load()
        records.append(record)
        _save(records)
    return record


def get(record_id: str) -> dict | None:
    for r in _load():
        if r["id"] == record_id:
            return r
    return None


def update(record_id: str, patch: dict) -> dict | None:
    with _lock:
        records = _load()
        for r in records:
            if r["id"] == record_id:
                r |= patch
                r["updated_at"] = _now()
                _save(records)
                return r
    return None


def add_stage(record_id: str, stage: str, detail: dict) -> None:
    with _lock:
        records = _load()
        for r in records:
            if r["id"] == record_id:
                r["stages"].append({"stage": stage, "at": _now(), "detail": detail})
                r["updated_at"] = _now()
                _save(records)
                return


def add_decision(record_id: str, action: str, actor: str, target: str,
                 reason: str, before=None, after=None) -> dict | None:
    decision = {
        "seq": 0,
        "at": _now(),
        "action": action,
        "actor": actor or "运营",
        "target": target,
        "reason": reason or "",
        "before": before,
        "after": after,
    }
    with _lock:
        records = _load()
        for r in records:
            if r["id"] == record_id:
                decision["seq"] = len(r["decisions"]) + 1
                r["decisions"].append(decision)
                r["updated_at"] = _now()
                _save(records)
                return decision
    return None


def list_summaries(limit: int = 50) -> list[dict]:
    records = sorted(_load(), key=lambda r: r["created_at"], reverse=True)[:limit]
    return [
        {
            "id": r["id"],
            "created_at": r["created_at"],
            "product_name": r["product_name"],
            "mode": r["mode"],
            "status": r["status"],
            "claim_gen_version": r["prompt_versions"].get("claim_gen"),
            "gate_summary": r["gate_summary"],
            "compliance_level": (r.get("compliance") or {}).get("A", {}).get("level"),
            "decisions": len(r["decisions"]),
        }
        for r in records
    ]


def stats() -> dict:
    records = _load()
    total = len(records)
    overrides = sum(
        1 for r in records for d in r["decisions"] if d["action"] in ("gate_override", "compliance_override")
    )
    edits = sum(1 for r in records for d in r["decisions"] if d["action"] == "content_edit")
    released = sum(1 for r in records if r["status"] == "已归档")
    blocked_claims = sum((r.get("gate_summary") or {}).get("blocked", 0) for r in records)
    passed_claims = sum((r.get("gate_summary") or {}).get("passed", 0) for r in records)
    return {
        "runs": total,
        "released": released,
        "passed_claims": passed_claims,
        "blocked_claims": blocked_claims,
        "block_rate": round(blocked_claims / (passed_claims + blocked_claims) * 100) if (passed_claims + blocked_claims) else 0,
        "overrides": overrides,
        "edits": edits,
        "decision_count": sum(len(r["decisions"]) for r in records),
    }


def delete(record_id: str) -> bool:
    with _lock:
        records = _load()
        remain = [r for r in records if r["id"] != record_id]
        if len(remain) == len(records):
            return False
        _save(remain)
        return True
