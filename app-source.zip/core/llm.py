"""DeepSeek 客户端与本地联网模式配置，只依赖标准库。"""

from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from pathlib import Path

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.local.json"
DEFAULT_BASE = "https://api.deepseek.com"
DEFAULT_MODEL = "deepseek-chat"
DEFAULT_WEB_URL = "https://www.guifanku.com/1100d208cca1622e5e2012e93361e869.html"


# ---------------------------------------------------------------- 配置

def load_config() -> dict:
    from core.cloud_context import visitor_path
    cfg = {"api_key": "", "base_url": DEFAULT_BASE, "model": DEFAULT_MODEL, "web_url": DEFAULT_WEB_URL}
    path = visitor_path() / "config.json"
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        cfg["web_url"] = data.get("web_url") or DEFAULT_WEB_URL
    return cfg


def save_config(patch: dict) -> dict:
    from core.cloud_context import visitor_path
    from core.public_http import validate_url
    if set(patch) - {"web_url"}:
        raise ValueError("云端版只接受公开网页地址，不保存或调用 API Key")
    url = patch.get("web_url") or DEFAULT_WEB_URL
    validate_url(url)
    path = visitor_path() / "config.json"
    path.write_text(json.dumps({"web_url": url}, ensure_ascii=False), encoding="utf-8")
    return public_config()


def public_config() -> dict:
    return {"configured": False, "mode": "web", "cloud": True,
            "web_url": load_config()["web_url"], "model": "本地网页提取",
            "storage_notice": "访客记录独立保存；免费服务器重启可能清空，请及时导出结果。"}


# ---------------------------------------------------------------- 调用

def chat(system: str, user: str, temperature: float = 0.3, json_mode: bool = True,
         timeout: int = 90) -> dict:
    cfg = load_config()
    if not cfg["api_key"]:
        return {"ok": False, "demo": False, "web": True, "error": "未配置 API Key，使用联网网页提取模式"}

    payload = {
        "model": cfg["model"],
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": temperature,
        "stream": False,
    }
    if json_mode:
        payload["response_format"] = {"type": "json_object"}

    req = urllib.request.Request(
        cfg["base_url"].rstrip("/") + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + cfg["api_key"],
        },
        method="POST",
    )

    started = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "ignore")[:400]
        return {"ok": False, "demo": False, "error": f"HTTP {e.code}: {detail}"}
    except Exception as e:  # 网络异常一律降级，不中断流程
        return {"ok": False, "demo": False, "error": f"{type(e).__name__}: {e}"}

    elapsed = round(time.time() - started, 2)
    content = body["choices"][0]["message"]["content"]
    usage = body.get("usage", {})
    return {
        "ok": True,
        "demo": False,
        "content": content,
        "elapsed": elapsed,
        "usage": usage,
        "model": body.get("model", cfg["model"]),
    }


def parse_json_content(content: str) -> dict | None:
    """模型偶尔会包一层 ```json，做一次容错解析。"""
    text = content.strip()
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.lstrip().startswith("json"):
            text = text.lstrip()[4:]
    text = text.strip().strip("`").strip()
    try:
        return json.loads(text)
    except Exception:
        start, end = text.find("{"), text.rfind("}")
        if start >= 0 and end > start:
            try:
                return json.loads(text[start:end + 1])
            except Exception:
                return None
    return None


# ---------------------------------------------------------------- 演示模式固定输出

DEMO_CLAIMS = {
    "claims": [
        {
            "claim": "产自烟台苹果地理标志保护范围内",
            "why": "对送礼人群来说，「地理标志产品保护」是可核验的产地背书，比「很甜」更有说服力。",
            "required_evidence": ["GI_CERT", "ORIGIN_PROOF"],
            "evidence_hint": "地理标志保护范围文件 + 合作社地块与种植记录",
            "risk": "low",
        },
        {
            "claim": "年均日照 2419–2630 小时，昼夜温差利于糖分积累",
            "why": "用产区气候数据解释「为什么这边苹果甜」，把口感变成可解释的事实。",
            "required_evidence": ["ORIGIN_PROOF"],
            "evidence_hint": "GB/T 18965-2008 第 5.1 条自然环境条款 + 产地证明",
            "risk": "low",
        },
        {
            "claim": "套袋、摘叶转果、铺反光膜，一颗苹果在树上完成增色",
            "why": "工艺细节是最难被同行复制、也最容易拍成短视频的内容。",
            "required_evidence": ["PROCESS_RECORD"],
            "evidence_hint": "作业时间记录与果园现场照片",
            "risk": "low",
        },
        {
            "claim": "可溶性固形物含量高于同类普通红富士",
            "why": "糖度是消费者最能理解的品质指标，直接对应「值不值这个价」。",
            "required_evidence": ["TEST_REPORT"],
            "evidence_hint": "CMA/CNAS 资质机构按 GB/T 10651 出具的可溶性固形物检测报告",
            "risk": "high",
        },
        {
            "claim": "按 GB/T 18965-2008 表 1 达到特级果标准",
            "why": "等级是礼盒溢价的核心依据，能直接支撑售价。",
            "required_evidence": ["GRADE_STANDARD", "TEST_REPORT"],
            "evidence_hint": "果径与着色面检验记录（依据 GB/T 18965-2008 表 1）",
            "risk": "medium",
        },
        {
            "claim": "零农药残留，可放心给孩子吃",
            "why": "家庭用户最关心安全问题，是转化率最高的切入点。",
            "required_evidence": ["TEST_REPORT"],
            "evidence_hint": "按 NY/T 1075 出具的农残检测报告（须全部项目合格）",
            "risk": "high",
        },
        {
            "claim": "同规格礼盒比市面均价高 10–30 元，溢价来自产地与工艺",
            "why": "把价格差解释清楚，才能让用户接受溢价，而不是直接比价。",
            "required_evidence": ["PRICE_REF", "GI_CERT", "PROCESS_RECORD"],
            "evidence_hint": "同规格竞品价格截图（带时间戳）+ 产地与工艺证据",
            "risk": "medium",
        },
    ]
}

# 演示模式下按提示词版本返回不同输出：这不是为了好看，而是为了能真实复现
# 「v1 会写出什么、v3 又写出了什么」这一迭代动机，供评审现场演示。
DEMO_CLAIMS_V1 = {
    "claims": [
        {"claim": "烟台栖霞红富士，全国最甜的苹果之一，吃过就回不去了"},
        {"claim": "富含维生素与膳食纤维，润肺止咳，增强免疫力，老人小孩都能吃"},
        {"claim": "采用有机种植，零农药残留，绝对安全"},
        {"claim": "史上最低价，79 元 12 枚，全网最低，买一送一"},
        {"claim": "国家级农业产业化重点龙头企业直供，品质顶级，送礼首选"},
        {"claim": "糖度高达 18 度，比普通苹果甜一倍"},
    ]
}

DEMO_CLAIMS_V2 = {
    "claims": [
        {"claim": "产自烟台栖霞的地理标志保护范围", "why": "产地是可核验的背书，比「很甜」更有说服力。"},
        {"claim": "年均日照 2419–2630 小时，昼夜温差大", "why": "用气候数据解释甜味的来源。"},
        {"claim": "套袋、摘叶转果、铺反光膜，全程精细管理", "why": "工艺细节最能拍成短视频内容。"},
        {"claim": "可溶性固形物含量高于同类普通红富士", "why": "糖度是消费者最容易理解的品质指标。"},
        {"claim": "按国家标准达到特级果", "why": "等级是礼盒溢价的核心依据。"},
        {"claim": "零农药残留，可放心给孩子吃", "why": "家庭用户最关心安全。"},
    ]
}

DEMO_REVIEW_FINDINGS = [
    {
        "quote": "年均气温 12.0–13.4℃",
        "category": "引证时效",
        "severity": "medium",
        "why": "该气候数据出自 GB/T 18965-2008，标准发布至今已十余年。若产区近年气候条件已变化，直接转引旧标准数据可能构成不实陈述。",
        "suggestion": "改为「据 GB/T 18965-2008 记载，产区年均气温 12.0–13.4℃」，或补充最近三年的当地气象部门数据。",
    },
    {
        "quote": "降水集中在 6–8 月果实膨大期",
        "category": "转述失真",
        "severity": "low",
        "why": "这一句是对标准条款的口语化转述，不是原文。改写标准条款本身有被认定『曲解依据』的风险。",
        "suggestion": "逐字核对标准原文后引用，或直接改为「依据 GB/T 18965-2008 对产区气候条件的描述」。",
    },
    {
        "quote": "12 枚礼盒装",
        "category": "规格标注不全",
        "severity": "medium",
        "why": "只标枚数不标净重与单果重区间，消费者收货后容易以『个头不符』发起投诉，属于隐性虚假风险。",
        "suggestion": "补全为「12 枚礼盒装，净重约 3.3kg，单果 250–300g」。",
    },
    {
        "quote": "切开后口感最棒",
        "category": "语境暗示",
        "severity": "high",
        "why": "这一句本身只是绝对化用语，但它与后文「润肺止咳、增强免疫力」连读时，会让消费者把『口感好』与『有保健作用』建立因果联想，风险等级高于单独看这句话。",
        "suggestion": "删除功效部分后，本句可保留为「果肉脆、汁液多、酸甜适度」，不必再加主观评价。",
    },
]

DEMO_CONTENT = {
    "detail_page": """一、产自地理标志保护范围
本批苹果产自山东省烟台市栖霞市，位于 GB/T 18965-2008《地理标志产品 烟台苹果》第 4 章规定的保护范围之内。

二、2419–2630 小时的日照，是甜味的来源
产区年均日照 2419–2630 小时，年均气温 12.0–13.4℃，降水集中在 6–8 月果实膨大期（GB/T 18965-2008 第 5.1 条）。果肉脆、汁液多、酸甜适度。

三、每颗苹果在树上完成增色
套袋栽培，采收前 20–30 天去袋，摘叶转果、树下铺反光膜，让背阴面均匀上色（GB/T 18965-2008 第 5.2.2 条）。

12 枚礼盒装，净重约 3.3kg，79 元 / 箱。""",
    "oral_script": """这是我们栖霞的红富士，产自烟台苹果的地理标志保护范围里。
你们可能不知道，这边一年日照 2419 到 2630 个小时，苹果就是在这样的太阳底下长出来的，果肉脆、汁水多、酸甜刚好。
更讲究的是上色——先去袋，再摘叶转果，最后在树底下铺一层反光膜，让背阴的那一面也上色。
12 枚一箱，净重三斤三两，送人和自己吃都合适，点下方链接看看。""",
    "social_post": """栖霞红富士到了。产自烟台苹果地理标志保护范围，年均日照 2419–2630 小时。
套袋、去袋、摘叶转果、铺反光膜，一颗苹果在树上完成增色。
12 枚礼盒装 3.3kg，79 元/箱，今天下单明天发。""",
}
