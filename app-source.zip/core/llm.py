"""Visitor-scoped API settings; secrets stay only in bounded process memory."""
from __future__ import annotations
import json
import re
import threading
import time
from collections import OrderedDict
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from core.cloud_context import VISITOR, visitor_path
from core.public_http import validate_url, public_json_post

DEFAULT_BASE = "https://api.deepseek.com"
DEFAULT_MODEL = "deepseek-flash"
DEFAULT_WEB_URL = "https://www.guifanku.com/1100d208cca1622e5e2012e93361e869.html"
KEY_TTL = 7200
KEY_LIMIT = 1000
_KEYS = OrderedDict()
_KEY_LOCK = threading.RLock()

def _entry():
    sid = VISITOR.get()
    visitor_path()
    with _KEY_LOCK:
        now = time.monotonic()
        for old in [k for k,v in _KEYS.items() if now-v['saved_at'] >= KEY_TTL]:
            _KEYS.pop(old, None)
        return dict(_KEYS.get(sid, {}))

def validate_base(value):
    if not isinstance(value, str):
        raise ValueError('API 地址必须为 HTTPS 地址')
    value = value.strip().rstrip('/')
    parts = urlsplit(value)
    if parts.scheme != 'https' or parts.query or parts.fragment or parts.username or parts.password:
        raise ValueError('API 地址只支持无账号、参数和片段的公开 HTTPS 地址')
    if parts.port not in (None,443):
        raise ValueError('API 地址只支持 HTTPS 443 端口')
    if parts.path.endswith('/chat/completions'):
        raise ValueError('请填写 Base URL，不要包含 /chat/completions')
    validate_url(value)
    return value

def load_config():
    cfg = {'mode':'web','api_key':'','base_url':DEFAULT_BASE,'model':DEFAULT_MODEL,'web_url':DEFAULT_WEB_URL}
    path = visitor_path() / 'config.json'
    if path.exists():
        data = json.loads(path.read_text(encoding='utf-8'))
        for key in ('mode','base_url','model','web_url'):
            if data.get(key): cfg[key] = data[key]
    entry = _entry()
    if entry.get('base_url') == cfg['base_url']:
        cfg['api_key'] = entry.get('key','')
        cfg['verified'] = entry.get('verified_model') == cfg['model']
    return cfg

def public_config():
    cfg = load_config()
    return {'configured':cfg['mode']=='api' and bool(cfg['api_key']), 'has_key':bool(cfg['api_key']),
            'mode':cfg['mode'], 'cloud':True, 'api_enabled':True, 'base_url':cfg['base_url'],
            'web_url':cfg['web_url'], 'model':cfg['model'], 'verified':bool(cfg.get('verified')),
            'key_storage':'当前访客专用；密钥只存服务器内存，2小时后或服务重启后失效，不写入文件或台账。',
            'storage_notice':'访客记录独立保存；免费服务器重启可能清空，请及时导出结果。'}

def save_config(patch):
    if set(patch) - {'mode','web_url','base_url','model','api_key','clear_key'}:
        raise ValueError('存在不支持的设置项')
    cfg = load_config()
    mode = patch.get('mode', cfg['mode'])
    if mode not in ('web','api'): raise ValueError('请选择网页提取或 API 模式')
    web_url = patch.get('web_url',cfg['web_url']) or DEFAULT_WEB_URL
    if not isinstance(web_url,str): raise ValueError('网页地址格式不正确')
    web_url = web_url.strip()
    if web_url != cfg['web_url']: validate_url(web_url)
    base = patch.get('base_url',cfg['base_url'])
    if 'base_url' in patch: base = validate_base(base)
    model = patch.get('model',cfg['model'])
    if not isinstance(model,str) or not re.fullmatch(r'[A-Za-z0-9_./:-]{1,128}',model):
        raise ValueError('模型名称格式不正确')
    key = patch.get('api_key','')
    if not isinstance(key,str) or len(key)>4096 or any(ord(c)<33 or ord(c)>126 for c in key):
        raise ValueError('API Key 格式不正确，请粘贴完整密钥，勿包含空格或换行')
    clear = patch.get('clear_key',False)
    if not isinstance(clear,bool): raise ValueError('清除密钥设置格式不正确')
    if clear and key: raise ValueError('清除密钥时请勿同时填写新密钥')
    if base != cfg['base_url'] and not key and not clear:
        raise ValueError('更换 API 服务地址时，请重新填写该服务的密钥')
    available = key or (cfg['api_key'] if base == cfg['base_url'] else '')
    if clear: available=''; mode='web'
    if mode=='api' and not available:
        raise ValueError('API 模式需要密钥；密钥已过期时请重新填写，或选择网页提取模式')
    data = {'mode':mode,'web_url':web_url,'base_url':base,'model':model}
    path = visitor_path() / 'config.json'
    path.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
    with _KEY_LOCK:
        sid=VISITOR.get()
        if clear: _KEYS.pop(sid,None)
        elif key:
            _KEYS[sid]={'key':key,'base_url':base,'saved_at':time.monotonic(),'verified_model':None}
            _KEYS.move_to_end(sid)
            while len(_KEYS)>KEY_LIMIT:_KEYS.popitem(last=False)
    return public_config()

def chat(system, user, temperature=0.3, json_mode=True, timeout=45, max_tokens=4096):
    cfg=load_config()
    if cfg['mode']!='api' or not cfg['api_key']:
        return {'ok':False,'demo':False,'error':'API 未启用或密钥已失效，请在 API 与数据源设置中重新配置。'}
    payload={'model':cfg['model'],'messages':[{'role':'system','content':system},{'role':'user','content':user}],
             'temperature':temperature,'stream':False,'max_tokens':max_tokens}
    if json_mode:payload['response_format']={'type':'json_object'}
    if urlsplit(cfg['base_url']).hostname=='api.deepseek.com':
        payload['thinking']={'type':'disabled'}
    started=time.monotonic()
    try:
        body=public_json_post(cfg['base_url']+'/chat/completions',payload,cfg['api_key'],timeout=timeout)
        message=body['choices'][0]['message']['content']
        if not isinstance(message,str) or not message.strip():raise ValueError('empty')
        return {'ok':True,'demo':False,'content':message,'elapsed':round(time.monotonic()-started,2),
                'usage':body.get('usage',{}),'model':body.get('model',cfg['model'])}
    except HTTPError as exc:
        messages={400:'API 参数或模型不受支持，请核对模型名称及 JSON 输出支持。',
                  401:'API Key 无效或已失效，请重新填写。',402:'API 账户余额不足，请在服务商平台检查。',
                  403:'API 访问被拒绝，请检查密钥权限和服务可用范围。',
                  404:'API 地址或模型不存在，请核对 Base URL 与模型名称。',
                  429:'API 请求限流或配额不足，请稍后再试。'}
        error=messages.get(exc.code, 'API 服务暂时不可用，请稍后重试。')
        return {'ok':False,'demo':False,'error':f'HTTP {exc.code}：{error}'}
    except (URLError, TimeoutError, OSError):
        return {'ok':False,'demo':False,'error':'API 连接失败或超时，请检查 HTTPS 地址与服务状态后重试。'}
    except (ValueError,KeyError,IndexError,TypeError):
        return {'ok':False,'demo':False,'error':'API 返回格式不兼容或内容为空，请使用支持 Chat Completions 的模型。'}

def test_connection():
    with _KEY_LOCK:
        entry = _KEYS.get(VISITOR.get())
        if entry:
            entry['verified_model'] = None
    res=chat('Return only a JSON object.','Return JSON exactly: {"connected":true}',temperature=0,json_mode=True,max_tokens=64,timeout=20)
    if not res['ok']:return res
    parsed=parse_json_content(res['content'])
    if not isinstance(parsed,dict) or parsed.get('connected') is not True:
        return {'ok':False,'error':'API 已响应，但 JSON 测试未通过，请检查模型兼容性。'}
    cfg=load_config()
    with _KEY_LOCK:
        entry=_KEYS.get(VISITOR.get())
        if entry and entry['key']==cfg['api_key']:entry['verified_model']=cfg['model']
    return {'ok':True,'message':'API 连接测试通过','model':res.get('model'),'elapsed':res.get('elapsed'),'config':public_config()}

def parse_json_content(content: str) -> dict | None:
    """模型偶尔会包一层 ```json，做一次容错解析。"""
    text = content.strip()
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.lstrip().startswith("json"):
            text = text.lstrip()[4:]
    text = text.strip().strip("`").strip()
    try:
        return json.loads(text)
    except Exception:
        start, end = text.find("{"), text.rfind("}")
        if start >= 0 and end > start:
            try:
                return json.loads(text[start:end + 1])
            except Exception:
                return None
    return None


# ---------------------------------------------------------------- 演示模式固定输出

DEMO_CLAIMS = {
    "claims": [
        {
            "claim": "产自烟台苹果地理标志保护范围内",
            "why": "对送礼人群来说，「地理标志产品保护」是可核验的产地背书，比「很甜」更有说服力。",
            "required_evidence": ["GI_CERT", "ORIGIN_PROOF"],
            "evidence_hint": "地理标志保护范围文件 + 合作社地块与种植记录",
            "risk": "low",
        },
        {
            "claim": "年均日照 2419–2630 小时，昼夜温差利于糖分积累",
            "why": "用产区气候数据解释「为什么这边苹果甜」，把口感变成可解释的事实。",
            "required_evidence": ["ORIGIN_PROOF"],
            "evidence_hint": "GB/T 18965-2008 第 5.1 条自然环境条款 + 产地证明",
            "risk": "low",
        },
        {
            "claim": "套袋、摘叶转果、铺反光膜，一颗苹果在树上完成增色",
            "why": "工艺细节是最难被同行复制、也最容易拍成短视频的内容。",
            "required_evidence": ["PROCESS_RECORD"],
            "evidence_hint": "作业时间记录与果园现场照片",
            "risk": "low",
        },
        {
            "claim": "可溶性固形物含量高于同类普通红富士",
            "why": "糖度是消费者最能理解的品质指标，直接对应「值不值这个价」。",
            "required_evidence": ["TEST_REPORT"],
            "evidence_hint": "CMA/CNAS 资质机构按 GB/T 10651 出具的可溶性固形物检测报告",
            "risk": "high",
        },
        {
            "claim": "按 GB/T 18965-2008 表 1 达到特级果标准",
            "why": "等级是礼盒溢价的核心依据，能直接支撑售价。",
            "required_evidence": ["GRADE_STANDARD", "TEST_REPORT"],
            "evidence_hint": "果径与着色面检验记录（依据 GB/T 18965-2008 表 1）",
            "risk": "medium",
        },
        {
            "claim": "零农药残留，可放心给孩子吃",
            "why": "家庭用户最关心安全问题，是转化率最高的切入点。",
            "required_evidence": ["TEST_REPORT"],
            "evidence_hint": "按 NY/T 1075 出具的农残检测报告（须全部项目合格）",
            "risk": "high",
        },
        {
            "claim": "同规格礼盒比市面均价高 10–30 元，溢价来自产地与工艺",
            "why": "把价格差解释清楚，才能让用户接受溢价，而不是直接比价。",
            "required_evidence": ["PRICE_REF", "GI_CERT", "PROCESS_RECORD"],
            "evidence_hint": "同规格竞品价格截图（带时间戳）+ 产地与工艺证据",
            "risk": "medium",
        },
    ]
}

# 演示模式下按提示词版本返回不同输出：这不是为了好看，而是为了能真实复现
# 「v1 会写出什么、v3 又写出了什么」这一迭代动机，供评审现场演示。
DEMO_CLAIMS_V1 = {
    "claims": [
        {"claim": "烟台栖霞红富士，全国最甜的苹果之一，吃过就回不去了"},
        {"claim": "富含维生素与膳食纤维，润肺止咳，增强免疫力，老人小孩都能吃"},
        {"claim": "采用有机种植，零农药残留，绝对安全"},
        {"claim": "史上最低价，79 元 12 枚，全网最低，买一送一"},
        {"claim": "国家级农业产业化重点龙头企业直供，品质顶级，送礼首选"},
        {"claim": "糖度高达 18 度，比普通苹果甜一倍"},
    ]
}

DEMO_CLAIMS_V2 = {
    "claims": [
        {"claim": "产自烟台栖霞的地理标志保护范围", "why": "产地是可核验的背书，比「很甜」更有说服力。"},
        {"claim": "年均日照 2419–2630 小时，昼夜温差大", "why": "用气候数据解释甜味的来源。"},
        {"claim": "套袋、摘叶转果、铺反光膜，全程精细管理", "why": "工艺细节最能拍成短视频内容。"},
        {"claim": "可溶性固形物含量高于同类普通红富士", "why": "糖度是消费者最容易理解的品质指标。"},
        {"claim": "按国家标准达到特级果", "why": "等级是礼盒溢价的核心依据。"},
        {"claim": "零农药残留，可放心给孩子吃", "why": "家庭用户最关心安全。"},
    ]
}

DEMO_REVIEW_FINDINGS = [
    {
        "quote": "年均气温 12.0–13.4℃",
        "category": "引证时效",
        "severity": "medium",
        "why": "该气候数据出自 GB/T 18965-2008，标准发布至今已十余年。若产区近年气候条件已变化，直接转引旧标准数据可能构成不实陈述。",
        "suggestion": "改为「据 GB/T 18965-2008 记载，产区年均气温 12.0–13.4℃」，或补充最近三年的当地气象部门数据。",
    },
    {
        "quote": "降水集中在 6–8 月果实膨大期",
        "category": "转述失真",
        "severity": "low",
        "why": "这一句是对标准条款的口语化转述，不是原文。改写标准条款本身有被认定『曲解依据』的风险。",
        "suggestion": "逐字核对标准原文后引用，或直接改为「依据 GB/T 18965-2008 对产区气候条件的描述」。",
    },
    {
        "quote": "12 枚礼盒装",
        "category": "规格标注不全",
        "severity": "medium",
        "why": "只标枚数不标净重与单果重区间，消费者收货后容易以『个头不符』发起投诉，属于隐性虚假风险。",
        "suggestion": "补全为「12 枚礼盒装，净重约 3.3kg，单果 250–300g」。",
    },
    {
        "quote": "切开后口感最棒",
        "category": "语境暗示",
        "severity": "high",
        "why": "这一句本身只是绝对化用语，但它与后文「润肺止咳、增强免疫力」连读时，会让消费者把『口感好』与『有保健作用』建立因果联想，风险等级高于单独看这句话。",
        "suggestion": "删除功效部分后，本句可保留为「果肉脆、汁液多、酸甜适度」，不必再加主观评价。",
    },
]

DEMO_CONTENT = {
    "detail_page": """一、产自地理标志保护范围
本批苹果产自山东省烟台市栖霞市，位于 GB/T 18965-2008《地理标志产品 烟台苹果》第 4 章规定的保护范围之内。

二、2419–2630 小时的日照，是甜味的来源
产区年均日照 2419–2630 小时，年均气温 12.0–13.4℃，降水集中在 6–8 月果实膨大期（GB/T 18965-2008 第 5.1 条）。果肉脆、汁液多、酸甜适度。

三、每颗苹果在树上完成增色
套袋栽培，采收前 20–30 天去袋，摘叶转果、树下铺反光膜，让背阴面均匀上色（GB/T 18965-2008 第 5.2.2 条）。

12 枚礼盒装，净重约 3.3kg，79 元 / 箱。""",
    "oral_script": """这是我们栖霞的红富士，产自烟台苹果的地理标志保护范围里。
你们可能不知道，这边一年日照 2419 到 2630 个小时，苹果就是在这样的太阳底下长出来的，果肉脆、汁水多、酸甜刚好。
更讲究的是上色——先去袋，再摘叶转果，最后在树底下铺一层反光膜，让背阴的那一面也上色。
12 枚一箱，净重三斤三两，送人和自己吃都合适，点下方链接看看。""",
    "social_post": """栖霞红富士到了。产自烟台苹果地理标志保护范围，年均日照 2419–2630 小时。
套袋、去袋、摘叶转果、铺反光膜，一颗苹果在树上完成增色。
12 枚礼盒装 3.3kg，79 元/箱，今天下单明天发。""",
}
