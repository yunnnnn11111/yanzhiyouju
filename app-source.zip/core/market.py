"""行情与卖窗口：基于公开批发市场数据的确定性计算（无模型、可复现）。

数据文件 data/market/xinfadi_series.json 由 tmp_market_fetch.py 抓取，
来源：北京新发地农产品批发市场 价格行情（逐日 最低/最高/均价，单位 元/斤）。
本模块只做聚合与规则判断，不调用大模型；冷库成本与损耗为明示假设。
"""

from __future__ import annotations

import json
import math
import os
import threading
from pathlib import Path
from typing import Any

_DATA = Path(__file__).resolve().parents[1] / "data" / "market" / "xinfadi_series.json"
_LOCK = threading.Lock()
_CACHE: dict[str, Any] = {"mtime": None, "data": None}

# 演示用假设：冷藏成本与损耗率（界面必须显式标注为假设）
STORAGE_COST_PER_KG_DAY = 0.035      # 元/公斤/天（0–5℃ 冷库，含电费与折旧）
STORAGE_LOSS_PER_DAY = 0.0008        # 每日自然损耗率
STORAGE_MAX_DAYS = 60


def _load() -> dict:
    if not _DATA.exists():
        return {"source": {}, "records": []}
    mtime = _DATA.stat().st_mtime
    with _LOCK:
        if _CACHE["mtime"] == mtime and _CACHE["data"] is not None:
            return _CACHE["data"]
    raw = json.loads(_DATA.read_text(encoding="utf-8"))
    with _LOCK:
        _CACHE["mtime"] = mtime
        _CACHE["data"] = raw
    return raw


def _round(value: float, digits: int = 2) -> float:
    return round(float(value), digits)


def products() -> list[dict]:
    counts: dict[str, int] = {}
    dates: dict[str, set] = {}
    for row in _load().get("records", []):
        counts[row["name"]] = counts.get(row["name"], 0) + 1
        dates.setdefault(row["name"], set()).add(row["date"])
    items = []
    for name, n in counts.items():
        ds = sorted(dates[name])
        items.append({"name": name, "records": n, "days": len(ds), "first": ds[0], "last": ds[-1]})
    items.sort(key=lambda x: (-x["days"], -x["records"], x["name"]))
    return items


def series(name: str, days: int = 90) -> list[dict]:
    bucket: dict[str, dict] = {}
    for row in _load().get("records", []):
        if row["name"] != name:
            continue
        d = row["date"]
        cur = bucket.setdefault(d, {"date": d, "low": row["low"], "high": row["high"], "sum": 0.0, "n": 0, "prices": []})
        cur["low"] = min(cur["low"], row["low"])
        cur["high"] = max(cur["high"], row["high"])
        cur["sum"] += row["avg"]
        cur["n"] += 1
        if row["avg"] > 0:
            cur["prices"].append(row["avg"])
    out = []
    for d in sorted(bucket):
        b = bucket[d]
        prices = sorted(b["prices"])
        n = len(prices)
        p10 = prices[max(0, int(n * 0.1))]
        p90 = prices[min(n - 1, int(n * 0.9))]
        out.append({
            "date": d,
            "low": _round(b["low"]),
            "high": _round(b["high"]),
            "p10": _round(p10),
            "p90": _round(p90),
            "avg": _round(b["sum"] / b["n"]),
            "samples": b["n"],
        })
    return out[-days:]


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _pct(new: float, old: float) -> float | None:
    if not old:
        return None
    return _round((new - old) / old * 100, 1)


def stats(name: str) -> dict:
    s = series(name, 90)
    if not s:
        return {}
    avgs = [x["avg"] for x in s]
    today = avgs[-1]
    prev = avgs[-2] if len(avgs) > 1 else today
    week = _mean(avgs[-7:])
    week_prev = _mean(avgs[-14:-7]) if len(avgs) >= 14 else week
    month = _mean(avgs[-30:])
    month_prev = _mean(avgs[-60:-30]) if len(avgs) >= 60 else month
    vol = math.sqrt(_mean([(a - month) ** 2 for a in avgs[-30:]]))
    change_7d = _pct(week, week_prev)
    change_30d = _pct(month, month_prev)
    return {
        "product": name,
        "days": len(s),
        "first_date": s[0]["date"],
        "last_date": s[-1]["date"],
        "today": _round(today),
        "prev": _round(prev),
        "day_change_pct": _pct(today, prev),
        "week_avg": _round(week),
        "week_change_pct": change_7d,
        "month_avg": _round(month),
        "month_change_pct": change_30d,
        "min_90d": _round(min(x["low"] for x in s)),
        "max_90d": _round(max(x["high"] for x in s)),
        "volatility_pct": _round(vol / month * 100, 1) if month else None,
        "trend": "up" if (change_7d or 0) > 3 else ("down" if (change_7d or 0) < -3 else "flat"),
        "samples": sum(x["samples"] for x in s),
    }


def advice(name: str, weight_kg: float = 500, hold_days: int = 30) -> dict:
    st = stats(name)
    if not st:
        return {}
    hold_days = max(7, min(STORAGE_MAX_DAYS, int(hold_days)))
    today = st["today"]
    change_7d = st["week_change_pct"] or 0
    change_30d = st["month_change_pct"] or 0
    # 规则：近一周与近一月同向上行 → 建议持货；明显下行 → 建议出货；震荡 → 分批
    if change_7d >= 3 and change_30d >= 0:
        action, tone = "持货等窗口", "up"
        reason = f"近 7 天均价上行 {change_7d}%，近 30 天 {change_30d:+}%，趋势偏强"
    elif change_7d <= -3:
        action, tone = "尽快出货", "down"
        reason = f"近 7 天均价下行 {change_7d}%，继续持有的价格风险高于冷藏成本"
    elif abs(change_7d) < 1.5 and abs(change_30d) < 3:
        action, tone = "分批出货", "flat"
        reason = "近一周与近一月都在窄幅震荡，一次性押注窗口的收益不明显"
    else:
        action, tone = "暂缓 7 天再看", "flat"
        reason = f"近 7 天 {change_7d:+.1f}%、近 30 天 {change_30d:+.1f}%，方向不一致，建议再观察一周"

    storage_cost = _round(weight_kg * STORAGE_COST_PER_KG_DAY * hold_days, 0)
    loss_kg = _round(weight_kg * (1 - (1 - STORAGE_LOSS_PER_DAY) ** hold_days), 1)
    loss_value = _round(loss_kg * today, 0)
    now_value = _round(weight_kg * today, 0)
    # 用近 30 天均价相对今日的偏离，估计"到期价格"的两种情景
    expected = _round(today * (1 + (change_30d or 0) / 100), 2)
    hold_value = _round((weight_kg - loss_kg) * expected, 0)
    hold_net = _round(hold_value - storage_cost, 0)
    return {
        "action": action,
        "tone": tone,
        "reason": reason,
        "hold_days": hold_days,
        "weight_kg": weight_kg,
        "sell_now": {"price": today, "value": now_value},
        "hold": {
            "expected_price": expected,
            "value": hold_value,
            "storage_cost": storage_cost,
            "loss_kg": loss_kg,
            "loss_value": loss_value,
            "net": hold_net,
            "delta_vs_now": _round(hold_net - now_value, 0),
        },
        "assumptions": {
            "storage_cost_per_kg_day": STORAGE_COST_PER_KG_DAY,
            "loss_per_day": STORAGE_LOSS_PER_DAY,
            "unit": "元/斤",
            "note": "冷藏成本与损耗为演示假设，价格预期按近 30 天涨跌幅外推；金额为情景测算，不构成收益承诺。",
        },
        "source": _load().get("source", {}),
    }


def payload(name: str, weight_kg: float = 500, hold_days: int = 30, days: int = 90) -> dict:
    st = stats(name)
    if not st:
        return {}
    return {
        "ok": True,
        "stats": st,
        "series": series(name, days),
        "advice": advice(name, weight_kg, hold_days),
        "source": _load().get("source", {}),
        "products": products(),
        "notice": "价格来自公开发布的市场行情，仅代表该市场当日报价；冷藏成本与损耗为假设，金额为情景测算。",
    }
