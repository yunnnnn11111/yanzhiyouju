"""行情实时抓取（烟台市发改委 / 山东省价格监测）。

设计约束：
- 运行在免费实例上，不能每次请求都去抓政府网站，因此加内存 TTL 缓存（默认 6 小时），
  并允许通过 `refresh=True` 强制刷新（页面上有「立即抓取」按钮）。
- 抓不到时一律降级：先返回磁盘缓存，再返回随包发布的快照，绝不因外部站点不可用而报错。
- 只读取公开页面，不携带任何账号信息；单次最多抓 16 期周报，逐篇间隔 0.3s。
"""

from __future__ import annotations

import json
import re
import ssl
import time
import urllib.parse
import urllib.request
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parents[1] / "data" / "market"
UA = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Accept-Language": "zh-CN,zh;q=0.9",
}
TTL_SECONDS = 6 * 3600
YANTAI_LIST = "https://www.yantai.gov.cn/api-gateway/jpaas-publish-server/front/page/build/unit"
YANTAI_TOKEN = {
    "parseType": "bulidstatic",
    "webId": "1",
    "tplSetId": "uo2n7cvvGR8iPKdzxdBuu",
    "pageType": "column",
    "tagId": "当前栏目列表",
    "editType": "null",
    "pageId": "43963",
}
SDPRICE_BASE = "http://www.sdprice.org.cn"

_CACHE: dict[str, dict] = {}


def _ssl_ctx():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _get(url: str, timeout: int = 10) -> str:
    """政府站点证书链常不完整，优先用不校验的上下文，失败再退回系统证书。"""
    req = urllib.request.Request(url, headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_ctx()) as resp:
            raw = resp.read()
    except Exception:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
    for encoding in ("utf-8", "gb18030"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "ignore")


def _cache_get(key: str):
    hit = _CACHE.get(key)
    if not hit:
        return None
    if time.time() - hit["at"] > TTL_SECONDS:
        return None
    return hit["value"]


def _cache_put(key: str, value):
    _CACHE[key] = {"at": time.time(), "value": value}
    return value


# ---------------------------------------------------------------- 烟台苹果周价


def _yantai_articles() -> list[dict]:
    url = YANTAI_LIST + "?" + urllib.parse.urlencode(YANTAI_TOKEN)
    payload = json.loads(_get(url))
    html = ((payload.get("data") or {}).get("html")) or ""
    rows = re.findall(
        r'<a[^>]+href="([^"]+)"[^>]*title="[^"]*采价时间：([0-9]{4})年([0-9]{1,2})月([0-9]{1,2})日[^"]*"',
        html,
    )
    out = []
    for href, year, month, day in rows:
        out.append({
            "url": href if href.startswith("http") else "https://www.yantai.gov.cn" + href,
            "date": "%s-%02d-%02d" % (year, int(month), int(day)),
        })
    return out


def _clean_cells(row: str) -> list[str]:
    raw = re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, flags=re.S)
    return [re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", cell)).strip() for cell in raw]


def _yantai_article(url: str) -> tuple[list[dict], str]:
    html = _get(url)
    tables = re.findall(r"<table.*?</table>", html, flags=re.S)
    rows: list[str] = []
    for table in tables:
        found = re.findall(r"<tr[^>]*>(.*?)</tr>", table, flags=re.S)
        if len(found) > 20:
            rows = found
            break
    items: list[dict] = []
    category = ""
    for row in rows:
        cells = [c for c in _clean_cells(row) if c]
        if not cells:
            continue
        if len(cells) == 1:
            category = cells[0]
            continue
        if len(cells) < 4:
            continue
        name, grade, unit, price = cells[0], cells[1], cells[2], cells[3]
        if not re.match(r"^\d+(\.\d+)?$", price):
            continue
        change = None
        for cell in cells[4:]:
            if cell.endswith("%"):
                try:
                    change = float(cell.replace("%", ""))
                except ValueError:
                    pass
                break
        items.append({
            "category": category,
            "name": name,
            "grade": grade,
            "unit": unit,
            "price": float(price),
            "change_pct": change,
        })
    text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html))
    note = re.search(r"三、水果类。([^四]{0,160})", text)
    return items, (note.group(1).strip() if note else "")


def fetch_yantai(periods: int = 2, budget: float = 45.0) -> dict:
    """抓取烟台周报。periods 与 budget 双重上限，避免在请求里超时。"""
    started = time.time()
    articles = _yantai_articles()[:periods]
    series: list[dict] = []
    latest_items: list[dict] = []
    fruit_note = ""
    for art in articles:
        if time.time() - started > budget:
            break
        try:
            items, note = _yantai_article(art["url"])
        except Exception:
            continue
        picked = [i for i in items if i["name"] == "苹果" and "红富士" in i["grade"]]
        if not picked:
            picked = [i for i in items if i["name"] == "苹果"]
        if picked:
            series.append({
                "date": art["date"],
                "price": picked[0]["price"],
                "grade": picked[0]["grade"],
                "change_pct": picked[0]["change_pct"],
                "url": art["url"],
            })
        if not latest_items and items:
            latest_items = items
            fruit_note = note
        time.sleep(0.15)
    series.sort(key=lambda row: row["date"])
    if not series:
        raise RuntimeError("烟台页面未解析到苹果价格")
    base = _load_bundled("yantai.json").get("apple_series") or []
    merged = {row.get("date"): row for row in base if isinstance(row, dict) and row.get("date")}
    for row in series:
        merged[row["date"]] = row
    series = [merged[key] for key in sorted(merged)]
    return {
        "version": "2026.11",
        "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "mode": "live",
        "source": {
            "name": "烟台市发展和改革委员会 · 农产品价格",
            "url": "https://www.yantai.gov.cn/col/col43963/index.html",
            "note": "每周一期；全市各区（市）部分超市和农贸市场定时定向采集的零售价格平均数，不直接代表成交价。",
        },
        "apple_series": series,
        "latest": {"items": latest_items, "fruit_note": fruit_note},
    }


# ---------------------------------------------------------------- 山东省级指数


def _sd_json(path: str):
    text = _get(SDPRICE_BASE + path)
    return json.loads(text)


def fetch_shandong() -> dict:
    indices: list[dict] = []
    try:
        raw = _sd_json("/f/getindexjx")
        for row in (raw if isinstance(raw, list) else raw.get("data") or []):
            if not isinstance(row, dict):
                continue
            value = row.get("index_value") or row.get("value") or row.get("zhi")
            try:
                value = float(value)
            except (TypeError, ValueError):
                value = None
            change = row.get("change_pct") or row.get("huanbi") or row.get("rate")
            try:
                change = float(change)
            except (TypeError, ValueError):
                change = None
            name = row.get("index_name") or row.get("name") or ""
            if name:
                indices.append({"name": name, "value": value, "change_pct": change})
    except Exception:
        indices = []
    markets: list[dict] = []
    try:
        raw = _sd_json("/f/getmarket")
        for row in (raw if isinstance(raw, list) else raw.get("data") or []):
            if isinstance(row, dict) and (row.get("name") or row.get("market_name")):
                name = row.get("name") or row.get("market_name")
                markets.append({"name": name, "url": row.get("url") or ""})
    except Exception:
        markets = []
    items: list[dict] = []
    try:
        raw = _sd_json("/f/getpricedata")
        for row in (raw if isinstance(raw, list) else raw.get("data") or []):
            if not isinstance(row, dict):
                continue
            try:
                price = float(row.get("price") or row.get("avg_price"))
            except (TypeError, ValueError):
                continue
            items.append({
                "name": row.get("name") or row.get("item_name") or "",
                "price": price,
                "unit": row.get("unit") or "元/公斤",
                "change_pct": None,
            })
    except Exception:
        items = []
    if not indices and not items:
        raise RuntimeError("山东价格监测网未返回可用数据")
    return {
        "version": "2026.11",
        "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "mode": "live",
        "source": {
            "name": "山东省价格监测与价格指数发布网（山东省发展和改革委员会）",
            "url": SDPRICE_BASE,
            "note": "该站未发布苹果单品价格；苹果以烟台市发改委周报为准。",
        },
        "indices": indices,
        "markets": markets,
        "items": items,
    }


# ---------------------------------------------------------------- 对外接口


def yantai_snapshot(refresh: bool = False) -> tuple[dict, str]:
    """返回 (数据, 来源模式)；mode ∈ live / cache / bundle。"""
    cached = _cache_get("yantai")
    if cached and not refresh:
        return cached, "cache"
    try:
        data = _cache_put("yantai", fetch_yantai())
        return data, "live"
    except Exception:
        bundled = _load_bundled("yantai.json")
        if bundled:
            return bundled, "bundle"
        if cached:
            return cached, "cache"
        return {}, "none"


def shandong_snapshot(refresh: bool = False) -> tuple[dict, str]:
    cached = _cache_get("shandong")
    if cached and not refresh:
        return cached, "cache"
    try:
        data = _cache_put("shandong", fetch_shandong())
        return data, "live"
    except Exception:
        bundled = _load_bundled("sdprice.json")
        if bundled:
            return bundled, "bundle"
        if cached:
            return cached, "cache"
        return {}, "none"


def _load_bundled(name: str) -> dict:
    path = DATA_DIR / name
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if isinstance(payload, dict):
        payload.setdefault("mode", "bundle")
    return payload if isinstance(payload, dict) else {}
