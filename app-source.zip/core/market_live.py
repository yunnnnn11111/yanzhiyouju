"""行情实时抓取（烟台市发改委 / 山东省价格监测）。

设计约束：
- 运行在免费实例上，不能每次请求都去抓政府网站，因此加内存 TTL 缓存（默认 6 小时），
  并允许通过 `refresh=True` 强制刷新（页面上有「立即抓取」按钮）。
- 抓不到时一律降级：先返回磁盘缓存，再返回随包发布的快照，绝不因外部站点不可用而报错。
- 只读取公开页面，不携带任何账号信息；单次最多抓 16 期周报，逐篇间隔 0.3s。
"""

from __future__ import annotations

import json
import re
import ssl
import time
import urllib.parse
import urllib.request
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parents[1] / "data" / "market"
UA = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Accept-Language": "zh-CN,zh;q=0.9",
}
TTL_SECONDS = 6 * 3600
YANTAI_LIST = "https://www.yantai.gov.cn/api-gateway/jpaas-publish-server/front/page/build/unit"
YANTAI_TOKEN = {
    "parseType": "bulidstatic",
    "webId": "1",
    "tplSetId": "uo2n7cvvGR8iPKdzxdBuu",
    "pageType": "column",
    "tagId": "当前栏目列表",
    "editType": "null",
    "pageId": "43963",
}
SDPRICE_BASE = "http://www.sdprice.org.cn"

_CACHE: dict[str, dict] = {}


def _ssl_ctx():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _get(url: str, timeout: int = 10) -> str:
    """政府站点证书链常不完整，优先用不校验的上下文，失败再退回系统证书。"""
    req = urllib.request.Request(url, headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_ctx()) as resp:
            raw = resp.read()
    except Exception:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
    for encoding in ("utf-8", "gb18030"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "ignore")


def _cache_get(key: str):
    hit = _CACHE.get(key)
    if not hit:
        return None
    if time.time() - hit["at"] > TTL_SECONDS:
        return None
    return hit["value"]


def _cache_put(key: str, value):
    _CACHE[key] = {"at": time.time(), "value": value}
    return value


# ---------------------------------------------------------------- 烟台苹果周价


def _yantai_articles() -> list[dict]:
    url = YANTAI_LIST + "?" + urllib.parse.urlencode(YANTAI_TOKEN)
    payload = json.loads(_get(url))
    html = ((payload.get("data") or {}).get("html")) or ""
    rows = re.findall(
        r'<a[^>]+href="([^"]+)"[^>]*title="[^"]*采价时间：([0-9]{4})年([0-9]{1,2})月([0-9]{1,2})日[^"]*"',
        html,
    )
    out = []
    for href, year, month, day in rows:
        out.append({
            "url": href if href.startswith("http") else "https://www.yantai.gov.cn" + href,
            "date": "%s-%02d-%02d" % (year, int(month), int(day)),
        })
    return out


def _clean_cells(row: str) -> list[str]:
    raw = re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, flags=re.S)
    return [re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", cell)).strip() for cell in raw]


def _yantai_article(url: str) -> tuple[list[dict], str]:
    html = _get(url)
    tables = re.findall(r"<table.*?</table>", html, flags=re.S)
    rows: list[str] = []
    for table in tables:
        found = re.findall(r"<tr[^>]*>(.*?)</tr>", table, flags=re.S)
        if len(found) > 20:
            rows = found
            break
    items: list[dict] = []
    category = ""
    for row in rows:
        cells = [c for c in _clean_cells(row) if c]
        if not cells:
            continue
        if len(cells) == 1:
            category = cells[0]
            continue
        if len(cells) < 4:
            continue
        name, grade, unit, price = cells[0], cells[1], cells[2], cells[3]
        if not re.match(r"^\d+(\.\d+)?$", price):
            continue
        change = None
        for cell in cells[4:]:
            if cell.endswith("%"):
                try:
                    change = float(cell.replace("%", ""))
                except ValueError:
                    pass
                break
        items.append({
            "category": category,
            "name": name,
            "grade": grade,
            "unit": unit,
            "price": float(price),
            "change_pct": change,
        })
    text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html))
    note = re.search(r"三、水果类。([^四]{0,160})", text)
    return items, (note.group(1).strip() if note else "")


def fetch_yantai(periods: int = 2, budget: float = 45.0) -> dict:
    """抓取烟台周报。periods 与 budget 双重上限，避免在请求里超时。"""
    started = time.time()
    articles = _yantai_articles()[:periods]
    series: list[dict] = []
    latest_items: list[dict] = []
    fruit_note = ""
    for art in articles:
        if time.time() - started > budget:
            break
        try:
            items, note = _yantai_article(art["url"])
        except Exception:
            continue
        picked = [i for i in items if i["name"] == "苹果" and "红富士" in i["grade"]]
        if not picked:
            picked = [i for i in items if i["name"] == "苹果"]
        if picked:
            series.append({
                "date": art["date"],
                "price": picked[0]["price"],
                "grade": picked[0]["grade"],
                "change_pct": picked[0]["change_pct"],
                "url": art["url"],
            })
        if not latest_items and items:
            latest_items = items
            fruit_note = note
        time.sleep(0.15)
    series.sort(key=lambda row: row["date"])
    if not series:
        raise RuntimeError("烟台页面未解析到苹果价格")
    base = _load_bundled("yantai.json").get("apple_series") or []
    merged = {row.get("date"): row for row in base if isinstance(row, dict) and row.get("date")}
    for row in series:
        merged[row["date"]] = row
    series = [merged[key] for key in sorted(merged)]
    return {
        "version": "2026.11",
        "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "mode": "live",
        "source": {
            "name": "烟台市发展和改革委员会 · 农产品价格",
            "url": "https://www.yantai.gov.cn/col/col43963/index.html",
            "note": "每周一期；全市各区（市）部分超市和农贸市场定时定向采集的零售价格平均数，不直接代表成交价。",
        },
        "apple_series": series,
        "latest": {"items": latest_items, "fruit_note": fruit_note},
    }


# ---------------------------------------------------------------- 山东省级指数


def _sd_json(path: str):
    text = _get(SDPRICE_BASE + path)
    return json.loads(text)


def fetch_shandong() -> dict:
    indices: list[dict] = []
    try:
        raw = _sd_json("/f/getindexjx")
        for row in (raw if isinstance(raw, list) else raw.get("data") or []):
            if not isinstance(row, dict):
                continue
            value = row.get("index_value") or row.get("value") or row.get("zhi")
            try:
                value = float(value)
            except (TypeError, ValueError):
                value = None
            change = row.get("change_pct") or row.get("huanbi") or row.get("rate")
            try:
                change = float(change)
            except (TypeError, ValueError):
                change = None
            name = row.get("index_name") or row.get("name") or ""
            if name:
                indices.append({"name": name, "value": value, "change_pct": change})
    except Exception:
        indices = []
    markets: list[dict] = []
    try:
        raw = _sd_json("/f/getmarket")
        for row in (raw if isinstance(raw, list) else raw.get("data") or []):
            if isinstance(row, dict) and (row.get("name") or row.get("market_name")):
                name = row.get("name") or row.get("market_name")
                markets.append({"name": name, "url": row.get("url") or ""})
    except Exception:
        markets = []
    items: list[dict] = []
    try:
        raw = _sd_json("/f/getpricedata")
        for row in (raw if isinstance(raw, list) else raw.get("data") or []):
            if not isinstance(row, dict):
                continue
            try:
                price = float(row.get("price") or row.get("avg_price"))
            except (TypeError, ValueError):
                continue
            items.append({
                "name": row.get("name") or row.get("item_name") or "",
                "price": price,
                "unit": row.get("unit") or "元/公斤",
                "change_pct": None,
            })
    except Exception:
        items = []
    if not indices and not items:
        raise RuntimeError("山东价格监测网未返回可用数据")
    return {
        "version": "2026.11",
        "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "mode": "live",
        "source": {
            "name": "山东省价格监测与价格指数发布网（山东省发展和改革委员会）",
            "url": SDPRICE_BASE,
            "note": "该站未发布苹果单品价格；苹果以烟台市发改委周报为准。",
        },
        "indices": indices,
        "markets": markets,
        "items": items,
    }


# ---------------------------------------------------------------- 对外接口


def yantai_snapshot(refresh: bool = False) -> tuple[dict, str]:
    """返回 (数据, 来源模式)；mode ∈ live / cache / bundle。"""
    cached = _cache_get("yantai")
    if cached and not refresh:
        return cached, "cache"
    try:
        raw = fetch_yantai()
        from core import market as market_mod

        data = market_mod.yt_view(raw) or raw
        data.setdefault("mode", "live")
        _cache_put("yantai", data)
        return data, "live"
    except Exception:
        bundled = _load_bundled("yantai.json")
        if bundled:
            return bundled, "bundle"
        if cached:
            return cached, "cache"
        return {}, "none"


def shandong_snapshot(refresh: bool = False) -> tuple[dict, str]:
    cached = _cache_get("shandong")
    if cached and not refresh:
        return cached, "cache"
    try:
        data = _cache_put("shandong", fetch_shandong())
        return data, "live"  # noqa: TRY300
    except Exception:
        bundled = _load_bundled("sdprice.json")
        if bundled:
            return bundled, "bundle"
        if cached:
            return cached, "cache"
        return {}, "none"


def _load_bundled(name: str) -> dict:
    path = DATA_DIR / name
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if isinstance(payload, dict):
        payload.setdefault("mode", "bundle")
    return payload if isinstance(payload, dict) else {}


# ---------------------------------------------------------------------------
# 农业农村部 · 苹果单品种大数据（appledata-channel.agri.cn）
#   入口：https://ncpscxx.moa.gov.cn/#/sing?headingIndex=true&item=1 → 水果 → 苹果
#   该站点证书链不完整，必须用不校验证书的上下文。
# ---------------------------------------------------------------------------

MOA_HOST = "appledata-channel.agri.cn"
MOA_BASE = "https://" + MOA_HOST
MOA_API = MOA_BASE + "/service/homePage/"
MOA_CITY = (
    ("beijing", "北京", "queryBjPrice"),
    ("shanghai", "上海", "queryShPrice"),
    ("guangzhou", "广州", "queryGzPrice"),
)


def _moa_json(path: str, timeout: int = 15):
    """GET 官方 JSON。

    该域名在本机 DNS 偶发解析失败（同一进程内 getaddrinfo 成功、urllib 失败），
    所以先解析出 IPv4，再用 http.client 直连 IP 并带 Host 头，避免再次解析。
    """
    import http.client
    import socket

    url_path = path if path.startswith("/") else "/service/homePage/" + path
    last = None
    for attempt in range(3):
        try:
            ip = socket.gethostbyname(MOA_HOST)
            conn = http.client.HTTPSConnection(ip, 443, context=_ssl_ctx(), timeout=timeout)
            try:
                conn.request(
                    "GET",
                    url_path,
                    headers={
                        "Host": MOA_HOST,
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
                        "Accept": "application/json, text/javascript, */*; q=0.01",
                        "X-Requested-With": "XMLHttpRequest",
                        "Referer": MOA_BASE + "/ggpd/jsp/index/index.jsp",
                    },
                )
                resp = conn.getresponse()
                body = resp.read().decode("utf-8", "ignore")
            finally:
                conn.close()
            return json.loads(body)
        except Exception as exc:  # noqa: PERF203
            last = exc
            if attempt < 2:
                time.sleep(1.5 * (attempt + 1))
    raise last if last else RuntimeError("moa request failed")


def _num(value):
    try:
        num = float(value)
    except (TypeError, ValueError):
        return None
    return round(num, 2)


def _moa_city(rows) -> dict:
    series = []
    for row in rows or []:
        date = str(row.get("SJ") or "")
        if len(date) == 8 and date.isdigit():
            date = "%s-%s-%s" % (date[0:4], date[4:6], date[6:8])
        wholesale = _num(row.get("PFJ"))
        if not date or wholesale is None:
            continue
        series.append({
            "date": date,
            "wholesale": wholesale,
            "retail": _num(row.get("JSJ")),
            "supermarket": _num(row.get("CSJ")),
        })
    series.sort(key=lambda item: item["date"])
    return {"series": series, "latest": series[-1] if series else None, "count": len(series)}


def fetch_moa_apple() -> dict:
    """农业农村部苹果大数据：月度指数 + 三城批发/零售价 + 主产区田头价。"""
    index_rows = _moa_json("queryIndex")
    monthly = []
    for row in index_rows or []:
        month = str(row.get("MONTH") or "")
        if not month:
            continue
        monthly.append({
            "month": month,
            "apple": _num(row.get("APPLE")),
            "fruit": _num(row.get("FRUIT")),
            "total": _num(row.get("TOTAL")),
        })
    monthly.sort(key=lambda item: item["month"])

    cities = {}
    for key, name, path in MOA_CITY:
        try:
            cities[key] = dict(_moa_city(_moa_json(path)), name=name)
        except Exception:
            cities[key] = {"name": name, "series": [], "latest": None, "count": 0}

    original = []
    try:
        for row in _moa_json("queryOriginalPrice") or []:
            date = str(row.get("SJ") or "")
            original.append({
                "date": date,
                "xian": _num(row.get("QX")),
                "heyang": _num(row.get("HYX")),
                "luochuan": _num(row.get("LCX")),
            })
        original.sort(key=lambda item: item["date"])
    except Exception:
        original = []

    latest = monthly[-1] if monthly else {}
    return {
        "version": "2026.11",
        "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "source": {
            "name": "农业农村部 · 苹果单品种全产业链大数据",
            "url": "https://ncpscxx.moa.gov.cn/#/sing?headingIndex=true&item=1",
            "api": MOA_API,
            "note": "月度价格指数与三城批发/零售价为官方口径；批发价单位元/公斤。主产区田头价当前无返回数据。",
        },
        "indices": {
            "month": latest.get("month"),
            "apple": latest.get("apple"),
            "fruit": latest.get("fruit"),
            "total": latest.get("total"),
        },
        "monthly": monthly[-18:],
        "cities": cities,
        "original": original[-18:],
        "original_note": "主产区田头价（陕西乾县/合阳/洛川）该接口当前返回空数组；山东栖霞未在该平台单列。",
    }


def moa_snapshot(refresh: bool = False) -> tuple[dict, str]:
    cached = _cache_get("moa_apple")
    if cached and not refresh:
        return cached, "cache"
    try:
        data = _cache_put("moa_apple", fetch_moa_apple())
        return data, "live"
    except Exception:
        if cached:
            return cached, "cache"
        return {}, "none"
