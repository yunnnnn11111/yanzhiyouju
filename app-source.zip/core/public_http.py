"""Only fetch public HTTP(S); pin each connection to a validated DNS address."""
import gzip
import http.client
import ipaddress
import socket
import ssl
import zlib
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit, urljoin, quote

MAX_DECODED_BYTES = 3 * 1024 * 1024


def decode_content(data: bytes, content_encoding: str = "") -> bytes:
    """Undo gzip/deflate even when a server ignores Accept-Encoding: identity.

    Several Chinese sites answer with br/gzip despite the identity request, and
    decoding those bytes as UTF-8 produces mojibake or binary garbage. Brotli
    is not available in the standard library, so it is left untouched and the
    caller fails cleanly instead of storing garbage.
    """
    if not data:
        return data
    encoding = (content_encoding or "").lower()
    if "gzip" in encoding or data[:2] == b"\x1f\x8b":
        try:
            return gzip.decompress(data)[:MAX_DECODED_BYTES]
        except (OSError, EOFError):
            return data
    if "deflate" in encoding:
        for wbits in (zlib.MAX_WBITS, -zlib.MAX_WBITS):
            try:
                return zlib.decompress(data, wbits)[:MAX_DECODED_BYTES]
            except zlib.error:
                continue
    return data

def validate_url(url):
    if not isinstance(url, str) or not url or len(url) > 2048 or any(ord(c) < 32 for c in url):
        raise ValueError('请输入有效的公开网页地址（最长 2048 字符）')
    try:
        parts = urlsplit(url)
        host = parts.hostname
        port = parts.port or (443 if parts.scheme == 'https' else 80)
    except ValueError as exc:
        raise ValueError('网页地址格式错误') from exc
    if parts.scheme not in ('http', 'https') or not host or parts.username or parts.password:
        raise ValueError('仅支持不含账号密码的 http:// 或 https:// 公开网址')
    if port not in (80, 443):
        raise ValueError('仅支持公开网站的 80 或 443 端口')
    host = host.encode('idna').decode('ascii')
    try:
        addresses = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise ValueError('无法解析该网站地址') from exc
    if not addresses:
        raise ValueError('该网站没有可用地址')
    for family, kind, proto, canon, addr in addresses:
        ip = ipaddress.ip_address(addr[0])
        if not ip.is_global or ip.is_multicast or (isinstance(ip, ipaddress.IPv6Address) and
                (ip.ipv4_mapped or ip.sixtofour or ip.teredo)):
            raise ValueError('仅能读取互联网公开网页，不能访问本机或内网地址')
    return parts, host, port, addresses[0][4][0]

class PublicResponse:
    def __init__(self, connection, response, url):
        self.connection, self.response, self.url = connection, response, url
        self.headers, self.status = response.headers, response.status
    def read(self, size=-1):
        return self.response.read(size)
    def geturl(self):
        return self.url
    def close(self):
        self.response.close()
        self.connection.close()
    def __enter__(self):
        return self
    def __exit__(self, *args):
        self.close()

def public_urlopen(request, timeout=20):
    url = request.full_url
    for _ in range(5):
        try:
            parts, host, port, address = validate_url(url)
        except ValueError as exc:
            raise URLError(str(exc)) from exc
        connection = http.client.HTTPConnection(host, port, timeout=timeout)
        try:
            sock = socket.create_connection((address, port), timeout=timeout)
            if parts.scheme == 'https':
                try:
                    sock = ssl.create_default_context().wrap_socket(sock, server_hostname=host)
                except Exception:
                    sock.close()
                    raise
            connection.sock = sock
            target = quote(parts.path or '/', safe="/%:@!$&'()*+,;=-._~")
            if parts.query:
                target += '?' + quote(parts.query, safe="%:@!$&'()*+,;=/?-._~")
            headers = {k:v for k,v in request.header_items() if k.lower() in ('user-agent', 'accept')}
            headers['Accept-Encoding'] = 'gzip, deflate'
            headers['Connection'] = 'close'
            connection.request('GET', target, headers=headers)
            response = connection.getresponse()
            if response.status in (301, 302, 303, 307, 308):
                location = response.headers.get('Location')
                response.close()
                connection.close()
                if not location:
                    raise URLError('网页重定向缺少地址')
                url = urljoin(url, location)
                continue
            if response.status >= 400:
                error = HTTPError(url, response.status, response.reason, response.headers, None)
                response.close()
                connection.close()
                raise error
            content_type = response.headers.get('Content-Type', '').split(';', 1)[0].strip().lower()
            if content_type and content_type not in ('text/html','application/xhtml+xml','text/plain','application/json','application/rss+xml','application/xml','text/xml'):
                raise URLError('该地址不是可提取的网页，请使用商品详情页或资料页面')
            return PublicResponse(connection, response, url)
        except Exception:
            connection.close()
            raise
    raise URLError('网页重定向次数过多')


def public_json_post(url, payload, api_key, timeout=45):
    """Send credentials only to the validated HTTPS origin; never follow redirects."""
    import json
    parts, host, port, address = validate_url(url)
    if parts.scheme != 'https' or port != 443 or parts.query or parts.fragment:
        raise ValueError('API requires a public HTTPS URL without query or fragment')
    connection = http.client.HTTPConnection(host, port, timeout=timeout)
    try:
        sock = socket.create_connection((address, port), timeout=timeout)
        try:
            sock = ssl.create_default_context().wrap_socket(sock, server_hostname=host)
        except Exception:
            sock.close()
            raise
        connection.sock = sock
        target = quote(parts.path or '/', safe="/%:@!$&'()*+,;=-._~")
        connection.request('POST', target, body=json.dumps(payload).encode('utf-8'), headers={
            'Content-Type':'application/json', 'Accept':'application/json',
            'Authorization':'Bearer '+api_key, 'Connection':'close', 'Accept-Encoding':'identity'})
        response = connection.getresponse()
        if response.status != 200:
            raise HTTPError(url,response.status,'API request failed',response.headers,None)
        data=response.read(1024*1024+1)
        if len(data)>1024*1024:raise ValueError('API response too large')
        return json.loads(data.decode('utf-8'))
    finally:
        connection.close()

