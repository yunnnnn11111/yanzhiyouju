"""联网检索的本地案例库（SQLite）。

设计目的：
- 联网模式下，公开搜索引擎在部分网络环境会返回导航页、反爬页或直接不可用；
  案例库把已采集、可复核的公开网页正文留在本地，检索时先查库、再查网。
- 库中内容全部是「公开网页快照」，与实时搜索一样只是待核验线索，不是证据。
- 首次使用时从 data/retrieval_seed.json 导入随包分发的种子数据；运行时新抓取的
  页面写回同一个库，形成可复用的检索缓存。
"""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

from core.cloud_context import DATA_ROOT

DB_PATH = DATA_ROOT / "retrieval.db"
SEED_PATH = Path(__file__).resolve().parents[1] / "data" / "retrieval_seed.json"

_LOCK = threading.RLock()
_READY = False

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT NOT NULL,
    url_key TEXT NOT NULL UNIQUE,
    host TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL DEFAULT '',
    text TEXT NOT NULL DEFAULT '',
    sha256 TEXT NOT NULL DEFAULT '',
    fetched_at TEXT NOT NULL DEFAULT '',
    added_at TEXT NOT NULL DEFAULT '',
    last_seen TEXT NOT NULL DEFAULT '',
    source_level TEXT NOT NULL DEFAULT '',
    suggested_type TEXT NOT NULL DEFAULT '',
    product TEXT NOT NULL DEFAULT '',
    tags TEXT NOT NULL DEFAULT '',
    query TEXT NOT NULL DEFAULT '',
    origin TEXT NOT NULL DEFAULT 'live'
);
CREATE INDEX IF NOT EXISTS idx_documents_product ON documents(product);
CREATE INDEX IF NOT EXISTS idx_documents_host ON documents(host);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _connect() -> sqlite3.Connection:
    DATA_ROOT.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=8000")
    except sqlite3.DatabaseError:
        pass
    return conn


def _ensure() -> None:
    global _READY
    if _READY and DB_PATH.exists():
        return
    with _LOCK:
        if _READY and DB_PATH.exists():
            return
        conn = _connect()
        try:
            conn.executescript(SCHEMA)
            conn.commit()
            count = conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
            if count == 0:
                _import_seed(conn)
        finally:
            conn.close()
        _READY = True


def _import_seed(conn: sqlite3.Connection) -> int:
    if not SEED_PATH.exists():
        return 0
    try:
        payload = json.loads(SEED_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return 0
    rows = payload.get("documents") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        return 0
    stamp = _now()
    written = 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        url = str(row.get("url") or "").strip()
        text = str(row.get("text") or "").strip()
        if not url or len(text) < 200:
            continue
        key = _url_key(url)
        try:
            conn.execute(
                """INSERT OR IGNORE INTO documents
                   (url, url_key, host, title, text, sha256, fetched_at, added_at,
                    last_seen, source_level, suggested_type, product, tags, query, origin)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (url, key, str(row.get("host") or ""), str(row.get("title") or "")[:300],
                 text, str(row.get("sha256") or hashlib.sha256(text.encode("utf-8")).hexdigest()),
                 str(row.get("fetched_at") or ""), stamp, stamp,
                 str(row.get("source_level") or ""), str(row.get("suggested_type") or ""),
                 str(row.get("product") or "")[:120], str(row.get("tags") or "")[:300],
                 str(row.get("query") or "")[:200], "seed"),
            )
            written += 1
        except sqlite3.DatabaseError:
            continue
    conn.commit()
    return written


def _url_key(url: str) -> str:
    parts = urlsplit(url)
    path = (parts.path or "/").rstrip("/") or "/"
    return f"{(parts.hostname or '').lower()}{path}"[:1024]


def _terms(query: str) -> list[str]:
    raw = re.split(r"[\s,，、;；/|()（）\[\]【】<>《》\"'“”‘’]+", (query or "").strip())
    out: list[str] = []
    for item in raw:
        item = item.strip()
        if len(item) >= 2 and item not in out:
            out.append(item[:40])
    if not out and query.strip():
        out.append(query.strip()[:40])
    return out[:6]


def _snippet(text: str, terms: list[str], size: int = 420) -> str:
    hay = re.sub(r"\s+", " ", text).strip()
    if not hay:
        return ""
    positions: list[int] = []
    for term in terms:
        start = 0
        while len(positions) < 200:
            found = hay.find(term, start)
            if found < 0:
                break
            positions.append(found)
            start = found + 1
    if not positions:
        return hay[:size]
    best_start, best_score = 0, -1
    for position in positions:
        start = max(0, position - 100)
        window = hay[start:start + size]
        score = sum(window.count(term) for term in terms)
        if score > best_score:
            best_start, best_score = start, score
    return hay[best_start:best_start + size]


def _flatten(row: dict) -> dict:
    text = row.get("text") or ""
    terms = _terms(row.get("product") or "")
    return {
        "id": row.get("id"),
        "url": row.get("url"),
        "host": row.get("host"),
        "title": row.get("title"),
        "text": text,
        "snippet": _snippet(text, terms or []),
        "fetched_at": row.get("fetched_at"),
        "source_level": row.get("source_level"),
        "suggested_type": row.get("suggested_type"),
        "product": row.get("product"),
        "tags": row.get("tags"),
        "origin": row.get("origin"),
    }


def search(query: str, limit: int = 5, product: str = "") -> list[dict]:
    """Return cached public documents relevant to the query, best first."""
    terms = _terms(query)
    if not terms:
        return []
    _ensure()
    limit = max(1, min(int(limit or 5), 20))
    like = [f"%{term.replace('%', '\\%').replace('_', '\\_')}%" for term in terms]
    where = " OR ".join("(title LIKE ? ESCAPE '\\' OR text LIKE ? ESCAPE '\\' OR tags LIKE ? ESCAPE '\\')" for _ in terms)
    params: list[str] = []
    for pattern in like:
        params.extend([pattern, pattern, pattern])
    conn = _connect()
    try:
        rows = conn.execute(
            f"SELECT * FROM documents WHERE {where} ORDER BY last_seen DESC LIMIT 200",
            params,
        ).fetchall()
    except sqlite3.DatabaseError:
        rows = []
    finally:
        conn.close()

    scored = []
    product_core = re.split(r"[（(]", product or "")[0].strip()
    for raw_row in rows:
        row = dict(raw_row)
        title = row.get("title") or ""
        text = row.get("text") or ""
        score = 0
        for term in terms:
            if term in title:
                score += 8
            count = text.count(term)
            score += min(count, 6)
        if product_core:
            if product_core in (row.get("product") or ""):
                score += 12
            if product_core in title:
                score += 8
            if product_core in text:
                score += min(text.count(product_core), 4)
            if product_core not in (row.get("product") or "") and score < 5:
                # 其他品类的资料只有在正文反复提及时才作为交叉参考
                continue
        if score <= 0:
            continue
        row["_score"] = score
        scored.append(row)

    scored.sort(key=lambda r: (r["_score"], len(r.get("text") or "")), reverse=True)
    return [_flatten(row) for row in scored[:limit]]


def save_document(page, product: str = "", query: str = "",
                  source_level: str = "", suggested_type: str = "") -> bool:
    """Store a fetched public page; returns False for thin or duplicate-poor pages."""
    url = str(getattr(page, "url", "") or "").strip()
    text = str(getattr(page, "text", "") or "").strip()
    if not url or len(text) < 400:
        return False
    _ensure()
    key = _url_key(url)
    stamp = _now()
    sha = hashlib.sha256(text.encode("utf-8")).hexdigest()
    conn = _connect()
    try:
        existing = conn.execute("SELECT id, length(text) AS size FROM documents WHERE url_key = ?", (key,)).fetchone()
        if existing:
            conn.execute("UPDATE documents SET last_seen = ?, url = ? WHERE id = ?", (stamp, url, existing["id"]))
            if len(text) > (existing["size"] or 0):
                conn.execute(
                    "UPDATE documents SET text = ?, sha256 = ?, title = ?, fetched_at = ? WHERE id = ?",
                    (text[:20000], sha, str(getattr(page, "title", "") or "")[:300],
                     str(getattr(page, "fetched_at", "") or ""), existing["id"]),
                )
            conn.commit()
            return True
        conn.execute(
            """INSERT INTO documents
               (url, url_key, host, title, text, sha256, fetched_at, added_at, last_seen,
                source_level, suggested_type, product, tags, query, origin)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (url, key, (urlsplit(url).hostname or "")[:120], str(getattr(page, "title", "") or "")[:300],
             text[:20000], sha, str(getattr(page, "fetched_at", "") or ""), stamp, stamp,
             source_level, suggested_type, (product or "")[:120],
             ",".join(x for x in [product, suggested_type] if x)[:300], (query or "")[:200], "live"),
        )
        conn.commit()
        return True
    except sqlite3.DatabaseError:
        return False
    finally:
        conn.close()


def stats() -> dict:
    _ensure()
    conn = _connect()
    try:
        total = conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
        by_origin = {row[0]: row[1] for row in conn.execute("SELECT origin, COUNT(*) FROM documents GROUP BY origin")}
        by_product = [{"product": row[0] or "未标注", "count": row[1]}
                      for row in conn.execute("SELECT product, COUNT(*) FROM documents GROUP BY product ORDER BY 2 DESC LIMIT 8")]
        last = conn.execute("SELECT MAX(last_seen) FROM documents").fetchone()[0] or ""
    except sqlite3.DatabaseError:
        return {"documents": 0, "by_origin": {}, "by_product": [], "last_seen": "", "seed": SEED_PATH.exists()}
    finally:
        conn.close()
    return {"documents": total, "by_origin": by_origin, "by_product": by_product,
            "last_seen": last, "seed": SEED_PATH.exists()}
