"""API 密钥的公开级加密存储与掩码工具。

使用 PBKDF2 派生密钥、SHA-256 计数器密钥流和 HMAC-SHA256 完整性校验。
它不是硬件密钥库，但可避免把明文密钥写入磁盘或返回浏览器。
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
from pathlib import Path

from core.cloud_context import DATA_ROOT

_KEY_FILE = DATA_ROOT / ".secrets" / "local.key"
_CACHE: bytes | None = None


def _master_key() -> bytes:
    global _CACHE
    if _CACHE:
        return _CACHE
    material = (os.environ.get("APP_ENCRYPTION_KEY") or os.environ.get("SESSION_SECRET") or "").encode("utf-8")
    if len(material) < 24:
        _KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
        if _KEY_FILE.exists():
            material = _KEY_FILE.read_bytes()
        else:
            material = secrets.token_bytes(48)
            _KEY_FILE.write_bytes(material)
            try:
                _KEY_FILE.chmod(0o600)
            except OSError:
                pass
    _CACHE = hashlib.pbkdf2_hmac("sha256", material, b"yanzhiyouju-secret-store-v1", 120_000, dklen=32)
    return _CACHE


def _stream(key: bytes, nonce: bytes, length: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < length:
        out.extend(hashlib.sha256(key + nonce + counter.to_bytes(8, "big")).digest())
        counter += 1
    return bytes(out[:length])


def encrypt_secret(value: str) -> str:
    if not isinstance(value, str) or not value:
        return ""
    nonce = secrets.token_bytes(16)
    raw = value.encode("utf-8")
    key = _master_key()
    cipher = bytes(a ^ b for a, b in zip(raw, _stream(key, nonce, len(raw))))
    tag = hmac.new(key, b"v1" + nonce + cipher, hashlib.sha256).digest()
    return "v1.{}.{}.{}".format(
        base64.urlsafe_b64encode(nonce).decode().rstrip("="),
        base64.urlsafe_b64encode(cipher).decode().rstrip("="),
        base64.urlsafe_b64encode(tag).decode().rstrip("="),
    )


def decrypt_secret(token: str) -> str:
    if not token:
        return ""
    try:
        version, n, c, t = token.split(".", 3)
        if version != "v1":
            return ""
        nonce = base64.urlsafe_b64decode(n + "=" * (-len(n) % 4))
        cipher = base64.urlsafe_b64decode(c + "=" * (-len(c) % 4))
        tag = base64.urlsafe_b64decode(t + "=" * (-len(t) % 4))
        key = _master_key()
        expected = hmac.new(key, b"v1" + nonce + cipher, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, expected):
            return ""
        raw = bytes(a ^ b for a, b in zip(cipher, _stream(key, nonce, len(cipher))))
        return raw.decode("utf-8")
    except (ValueError, TypeError, UnicodeError):
        return ""


def mask_secret(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 8:
        return "•" * len(value)
    return value[:4] + "•" * min(12, max(4, len(value) - 8)) + value[-4:]


def parse_bool(value, label: str) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"{label}须为布尔值")
    return value
