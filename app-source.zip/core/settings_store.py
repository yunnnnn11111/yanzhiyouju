"""平台开关、数据源与管理员级 API 配置。"""
from __future__ import annotations

import json
import re
import threading
from datetime import datetime, timezone
from urllib.parse import urlsplit

from core.cloud_context import DATA_ROOT
from core.public_http import validate_url
from core.secure_store import encrypt_secret, decrypt_secret, mask_secret

SETTINGS_FILE = DATA_ROOT / "platform_settings.json"
LOCK = threading.RLock()
DEFAULT_MODEL = "deepseek-chat"
DEFAULT_BASE = "https://api.deepseek.com"

FEATURE_DEFAULTS = {
    "registration_enabled": True,
    "guest_analysis_enabled": True,
    "web_collection_enabled": True,
    "platform_api_enabled": False,
    "user_api_enabled": True,
    "export_enabled": True,
    "manual_override_enabled": False,
}

DEFAULT = {
    "features": FEATURE_DEFAULTS,
    "platform_api": {
        "base_url": DEFAULT_BASE,
        "model": DEFAULT_MODEL,
        "api_key_enc": "",
        "updated_at": "",
        "last_test": {},
    },
    "data_sources": {
        "search_order": ["DuckDuckGo", "必应 RSS", "必应网页", "搜狗", "360"],
        "allowed_schemes": ["https", "http"],
        "max_pages_per_collect": 3,
    },
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _read() -> dict:
    if not SETTINGS_FILE.exists():
        return json.loads(json.dumps(DEFAULT, ensure_ascii=False))
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    out = json.loads(json.dumps(DEFAULT, ensure_ascii=False))
    if isinstance(data.get("features"), dict):
        out["features"].update({k: v for k, v in data["features"].items() if k in FEATURE_DEFAULTS and isinstance(v, bool)})
    if isinstance(data.get("platform_api"), dict):
        out["platform_api"].update(data["platform_api"])
    if isinstance(data.get("data_sources"), dict):
        out["data_sources"].update(data["data_sources"])
    return out


def _write(data: dict) -> None:
    SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = SETTINGS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(SETTINGS_FILE)


def validate_base(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("API 地址必须为 HTTPS 地址")
    value = value.strip().rstrip("/")
    parts = urlsplit(value)
    if parts.scheme != "https" or parts.query or parts.fragment or parts.username or parts.password:
        raise ValueError("API 地址只支持无账号、参数和片段的公开 HTTPS 地址")
    if parts.port not in (None, 443):
        raise ValueError("API 地址只支持 HTTPS 443 端口")
    if parts.path.endswith("/chat/completions"):
        raise ValueError("请填写 Base URL，不要包含 /chat/completions")
    validate_url(value)
    return value


def validate_model(value: str) -> str:
    value = (value or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_./:-]{1,128}", value):
        raise ValueError("模型名称格式不正确")
    return value


def get_settings() -> dict:
    with LOCK:
        return _read()


def public_settings() -> dict:
    data = _read()
    api = data["platform_api"]
    return {
        "features": dict(data["features"]),
        "platform_api": {
            "enabled": bool(data["features"].get("platform_api_enabled")),
            "configured": bool(api.get("api_key_enc")),
            "base_url": api.get("base_url", DEFAULT_BASE),
            "model": api.get("model", DEFAULT_MODEL),
            "last_test": api.get("last_test", {}),
        },
        "data_sources": {
            "search_order": data["data_sources"].get("search_order", []),
            "max_pages_per_collect": data["data_sources"].get("max_pages_per_collect", 3),
        },
    }


def admin_settings() -> dict:
    data = _read()
    api = data["platform_api"]
    key = decrypt_secret(api.get("api_key_enc", ""))
    return {
        "features": dict(data["features"]),
        "platform_api": {
            "enabled": bool(data["features"].get("platform_api_enabled")),
            "configured": bool(key),
            "base_url": api.get("base_url", DEFAULT_BASE),
            "model": api.get("model", DEFAULT_MODEL),
            "key_masked": mask_secret(key),
            "updated_at": api.get("updated_at", ""),
            "last_test": api.get("last_test", {}),
        },
        "data_sources": data.get("data_sources", {}),
    }


def platform_api_config(include_disabled: bool = False) -> dict | None:
    data = _read()
    if not include_disabled and not data["features"].get("platform_api_enabled"):
        return None
    api = data["platform_api"]
    key = decrypt_secret(api.get("api_key_enc", ""))
    if not key:
        return None
    return {"source": "platform", "base_url": api.get("base_url", DEFAULT_BASE),
            "model": api.get("model", DEFAULT_MODEL), "api_key": key}


def update_features(patch: dict) -> dict:
    if not isinstance(patch, dict) or set(patch) - set(FEATURE_DEFAULTS):
        raise ValueError("存在不支持的平台开关")
    if any(not isinstance(v, bool) for v in patch.values()):
        raise ValueError("平台开关须为布尔值")
    with LOCK:
        data = _read()
        data["features"].update(patch)
        _write(data)
        return public_settings()


def save_platform_api(payload: dict) -> dict:
    allowed = {"base_url", "model", "api_key", "clear_key", "enabled"}
    if set(payload) - allowed:
        raise ValueError("存在不支持的平台 API 设置项")
    with LOCK:
        data = _read()
        api = data["platform_api"]
        old_base = api.get("base_url")
        if "base_url" in payload:
            api["base_url"] = validate_base(payload["base_url"])
        if "model" in payload:
            api["model"] = validate_model(payload["model"])
        key = payload.get("api_key", "")
        if not isinstance(key, str) or len(key) > 4096 or any(ord(c) < 33 or ord(c) > 126 for c in key):
            raise ValueError("API Key 格式不正确")
        if payload.get("clear_key") is True:
            if key:
                raise ValueError("清除密钥时请勿同时填写新密钥")
            api["api_key_enc"] = ""
        elif key:
            api["api_key_enc"] = encrypt_secret(key)
        if old_base != api.get("base_url") and api.get("api_key_enc") and not key and not payload.get("clear_key"):
            raise ValueError("更换平台 API 地址时，请重新填写对应密钥")
        if "enabled" in payload:
            if not isinstance(payload["enabled"], bool):
                raise ValueError("平台 API 开关格式不正确")
            data["features"]["platform_api_enabled"] = payload["enabled"]
        if data["features"]["platform_api_enabled"] and not api.get("api_key_enc"):
            raise ValueError("启用平台 API 前请先配置服务密钥")
        api["updated_at"] = _now()
        api["last_test"] = {}
        _write(data)
        return admin_settings()


def set_api_test(result: dict) -> None:
    with LOCK:
        data = _read()
        data["platform_api"]["last_test"] = {
            "status": "passed" if result.get("ok") else "failed",
            "message": result.get("message") or result.get("error") or "",
            "at": _now(),
        }
        _write(data)


def update_data_sources(payload: dict) -> dict:
    """管理员调整公开网页采集顺序与单次页数；不保存任何站点密钥。"""
    allowed = {"search_order", "max_pages_per_collect"}
    if not isinstance(payload, dict) or set(payload) - allowed:
        raise ValueError("存在不支持的数据源设置项")
    names = {"必应 RSS", "必应网页", "搜狗", "360", "DuckDuckGo"}
    with LOCK:
        data = _read()
        if "search_order" in payload:
            order = payload["search_order"]
            if not isinstance(order, list) or not order or len(order) > len(names):
                raise ValueError("搜索顺序须为非空数组")
            if any(not isinstance(x, str) or x not in names for x in order):
                raise ValueError("搜索顺序包含未知数据源")
            if len(set(order)) != len(order):
                raise ValueError("搜索顺序不能重复")
            data["data_sources"]["search_order"] = order
        if "max_pages_per_collect" in payload:
            value = payload["max_pages_per_collect"]
            if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 5:
                raise ValueError("单次采集页数须为 1–5 的整数")
            data["data_sources"]["max_pages_per_collect"] = value
        _write(data)
        return public_settings()
