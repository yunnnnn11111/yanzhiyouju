"""公开溯源页：让采购方扫码看这一批货的证据（方向三「凭什么信你」）。

设计原则：
- 只读。公开页不提供任何修改入口，也不展示账号、密码、内部核验备注以外的隐私字段。
- 可核验。每个证据都带状态、提供时间、文件 SHA-256；整份批次档案再取一次 SHA-256，
  读者可以把页面上的哈希与档案原文比对。
- 不夸大。过期的证据显示「已过期」，缺的显示「未提供」，不隐藏。
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path

from core import cloud_context

BATCH_RE = re.compile(r"BAT-[A-Z0-9-]{8,40}")
SHARE_LEN = 12

STATUS_TEXT = {
    "verified": "已核验",
    "pending": "待核验",
    "rejected": "未通过",
    "expired": "已过期",
    "missing": "未提供",
}

PRODUCT_FIELDS = (
    ("name", "产品"),
    ("origin_address", "产地"),
    ("organization", "生产主体"),
    ("variety", "品种"),
    ("grade", "等级"),
    ("spec", "规格"),
    ("batch_weight_kg", "本批重量"),
    ("harvest_date", "采摘日期"),
    ("package_date", "包装日期"),
    ("transport", "运输"),
    ("storage", "储存"),
)


def _secret() -> bytes:
    return (os.environ.get("SESSION_SECRET") or "yzyj-trace-local").encode("utf-8")


def share_code(batch_id: str) -> str:
    """给批次生成一个短分享码，避免 URL 被枚举。"""
    digest = hmac.new(_secret(), ("trace:" + batch_id).encode("utf-8"), hashlib.sha256).hexdigest()
    return digest[:SHARE_LEN]


def code_ok(batch_id: str, code: str | None) -> bool:
    return bool(code) and hmac.compare_digest(share_code(batch_id), code)


def find(batch_id: str) -> tuple[dict, Path] | None:
    """在所有账号目录里找到这一批（公开页不需要登录）。"""
    if not BATCH_RE.fullmatch(batch_id or ""):
        return None
    root = cloud_context.DATA_ROOT
    for base in ("accounts", "guests"):
        folder = root / base
        if not folder.exists():
            continue
        for candidate in folder.glob(f"*/batches/{batch_id}.json"):
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if isinstance(data, dict) and data.get("id") == batch_id:
                return data, candidate
    return None


def _as_list(value) -> list:
    """档案里的同名字段可能是列表、字典或缺失，公开页要能容错。"""
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        return [row for row in value.values() if isinstance(row, dict)]
    return []


def _evidence_rows(batch: dict) -> list[dict]:
    rows = []
    for row in _as_list(batch.get("evidence")):
        status = str(row.get("status") or "missing")
        rows.append(
            {
                "id": row.get("id"),
                "type": row.get("type"),
                "label": row.get("label") or row.get("name") or row.get("type"),
                "status": status,
                "status_text": STATUS_TEXT.get(status, status),
                "provided": bool(row.get("provided")),
                "verified_at": row.get("verified_at") or "",
                "expires_at": row.get("expires_at") or "",
                "sha256": row.get("sha256") or "",
                "source_level": row.get("source_level") or "",
                "detail": row.get("detail") or "",
                "verification_note": row.get("verification_note") or "",
            }
        )
    return rows


def _media_rows(batch: dict) -> list[dict]:
    rows = []
    for row in _as_list(batch.get("photos")) + _as_list(batch.get("attachments")):
        rows.append(
            {
                "name": row.get("name") or row.get("original_name") or "",
                "caption": row.get("caption") or "",
                "sha256": row.get("sha256") or "",
                "added_at": row.get("added_at") or row.get("created_at") or "",
            }
        )
    return rows


def payload(batch: dict, path: Path) -> dict:
    try:
        raw = path.read_bytes()
    except OSError:
        raw = b""
    product = batch.get("product") or {}
    gate = batch.get("gate") or {}
    claims = batch.get("claims") or []
    compliance = batch.get("compliance") or {}
    evidence = _evidence_rows(batch)
    provided = [row for row in evidence if row["provided"]]
    return {
        "ok": True,
        "batch_id": batch.get("id"),
        "created_at": batch.get("created_at") or "",
        "updated_at": batch.get("updated_at") or "",
        "status": batch.get("status") or "",
        "mode": batch.get("mode") or "",
        "product": {label: product.get(key) for key, label in PRODUCT_FIELDS if product.get(key) not in (None, "")},
        "summary": {
            "evidence_total": len(evidence),
            "evidence_provided": len(provided),
            "claims_total": len(claims),
            "claims_passed": gate.get("passed") or 0,
            "claims_blocked": gate.get("blocked") or 0,
            "compliance_level": compliance.get("level") or "",
            "compliance_blocked": bool(compliance.get("blocked")),
        },
        "evidence": evidence,
        "media": _media_rows(batch),
        "timeline": _as_list(batch.get("timeline"))[-6:],
        "integrity": {
            "archive_sha256": hashlib.sha256(raw).hexdigest() if raw else "",
            "archive_bytes": len(raw),
            "share_code": share_code(str(batch.get("id") or "")),
        },
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "notice": "本页由「言之有据」生成，仅用于核对这一批货的公开证据；不构成认证、检测结论或法律意见。",
    }
