"""公开网页抓取与本地事实提取。

该模块只使用 Python 标准库。它读取用户指定的 HTTP(S) 页面，提取标题、
正文、meta 信息、链接、表格和页面内嵌 JSON，供没有 API Key 时的本地流程使用。
网页内容只作为待核验来源，不能自动替代检测报告、证书或合作社原始记录。
"""

from __future__ import annotations

import html
import json
import re
import ssl
import time
from dataclasses import dataclass
from html.parser import HTMLParser
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request
from core.public_http import public_urlopen as urlopen


MAX_BYTES = 3 * 1024 * 1024
DEFAULT_TIMEOUT = 20
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36 "
    "YanZhiYouJu/1.0"
)


class WebExtractError(RuntimeError):
    """公开网页读取或解析失败。"""


def _clean(value: str) -> str:
    value = html.unescape(value)
    return re.sub(r"\s+", " ", value).strip()


class _Parser(HTMLParser):
    ignored = {"style", "noscript", "template", "svg"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title: list[str] = []
        self.text: list[str] = []
        self.meta: dict[str, str] = {}
        self.links: list[dict[str, str]] = []
        self.tables: list[list[list[str]]] = []
        self.json_blocks: list[Any] = []
        self._ignored = 0
        self._title = 0
        self._link: dict[str, str] | None = None
        self._table: list[list[str]] | None = None
        self._row: list[str] | None = None
        self._cell: list[str] | None = None
        self._script_type: str | None = None
        self._script: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        attrs_map = {k.lower(): v or "" for k, v in attrs}
        if tag == "script":
            self._ignored += 1
            self._script_type = attrs_map.get("type", "").lower()
            self._script = []
            return
        if tag in self.ignored:
            self._ignored += 1
            return
        if self._ignored:
            return
        if tag == "title":
            self._title += 1
        elif tag == "meta":
            key = attrs_map.get("name") or attrs_map.get("property")
            if key and attrs_map.get("content"):
                self.meta[key] = _clean(attrs_map["content"])
        elif tag == "a" and attrs_map.get("href"):
            self._link = {"url": attrs_map["href"], "text": ""}
        elif tag == "table":
            self._table = []
        elif tag == "tr" and self._table is not None:
            self._row = []
        elif tag in ("td", "th") and self._row is not None:
            self._cell = []

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag == "script":
            if self._script_type in {"application/json", "application/ld+json"}:
                raw = "".join(self._script).strip()
                if raw:
                    try:
                        self.json_blocks.append(json.loads(raw))
                    except json.JSONDecodeError:
                        pass
            self._script_type = None
            self._script = []
            self._ignored = max(0, self._ignored - 1)
            return
        if tag in self.ignored:
            self._ignored = max(0, self._ignored - 1)
            return
        if self._ignored:
            return
        if tag == "title":
            self._title = max(0, self._title - 1)
        elif tag == "a" and self._link is not None:
            self._link["text"] = _clean(self._link["text"])
            self.links.append(self._link)
            self._link = None
        elif tag in ("td", "th") and self._cell is not None and self._row is not None:
            self._row.append(_clean(" ".join(self._cell)))
            self._cell = None
        elif tag == "tr" and self._row is not None and self._table is not None:
            if any(self._row):
                self._table.append(self._row)
            self._row = None
        elif tag == "table" and self._table is not None:
            if self._table:
                self.tables.append(self._table)
            self._table = None

    def handle_data(self, data: str) -> None:
        if self._ignored:
            if self._script_type:
                self._script.append(data)
            return
        value = _clean(data)
        if not value:
            return
        if self._title:
            self.title.append(value)
        self.text.append(value)
        if self._link is not None:
            self._link["text"] = f"{self._link['text']} {value}".strip()
        if self._cell is not None:
            self._cell.append(value)


@dataclass(frozen=True)
class WebPage:
    url: str
    title: str
    text: str
    meta: dict[str, str]
    links: list[dict[str, str]]
    tables: list[list[list[str]]]
    embedded_json: list[Any]
    fetched_at: str
    status: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "url": self.url,
            "title": self.title,
            "text": self.text,
            "meta": self.meta,
            "links": self.links,
            "tables": self.tables,
            "embedded_json": self.embedded_json,
            "fetched_at": self.fetched_at,
            "status": self.status,
        }


def _decode(data: bytes, content_type: str = "") -> str:
    charset = ""
    match = re.search(r"charset=([\w-]+)", content_type, re.I)
    if match:
        charset = match.group(1)
    for encoding in [charset, "utf-8", "gb18030", "big5", "latin-1"]:
        if not encoding:
            continue
        try:
            return data.decode(encoding)
        except (LookupError, UnicodeDecodeError):
            continue
    return data.decode("utf-8", errors="replace")


def fetch(url: str, timeout: int = DEFAULT_TIMEOUT) -> WebPage:
    parsed = urlparse((url or "").strip())
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise WebExtractError("网页地址必须是完整的 http:// 或 https:// 地址")
    req = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml,application/json,text/plain,*/*;q=0.8"})
    try:
        with urlopen(req, timeout=timeout) as response:
            data = response.read(MAX_BYTES + 1)
            if len(data) > MAX_BYTES:
                raise WebExtractError("网页内容超过 3 MB，已停止读取")
            source = _decode(data, response.headers.get("Content-Type", ""))
            final_url = response.geturl()
            status = int(response.status)
    except HTTPError as exc:
        raise WebExtractError(f"网页返回 HTTP {exc.code}") from exc
    except (URLError, TimeoutError, ssl.SSLError) as exc:
        raise WebExtractError(f"网页连接失败：{exc}") from exc
    except OSError as exc:
        raise WebExtractError(f"网页读取失败：{exc}") from exc

    parser = _Parser()
    try:
        parser.feed(source)
        parser.close()
    except Exception as exc:
        raise WebExtractError(f"网页解析失败：{exc}") from exc
    return WebPage(
        url=final_url,
        title=_clean(" ".join(parser.title)),
        text="\n".join(parser.text),
        meta=parser.meta,
        links=parser.links,
        tables=parser.tables,
        embedded_json=parser.json_blocks,
        fetched_at=time.strftime("%Y-%m-%d %H:%M:%S"),
        status=status,
    )


def compact(page: WebPage, limit: int = 8000) -> str:
    """生成可写入提示词和台账的网页摘要。"""
    pieces = [f"网页标题：{page.title}"]
    for key in ("description", "og:description", "keywords"):
        if page.meta.get(key):
            pieces.append(f"{key}：{page.meta[key]}")
    pieces.append("网页正文：" + page.text[:limit])
    if page.tables:
        pieces.append("网页表格：" + json.dumps(page.tables[:5], ensure_ascii=False))
    if page.embedded_json:
        pieces.append("页面内嵌 JSON：" + json.dumps(page.embedded_json[:3], ensure_ascii=False)[:3000])
    return "\n".join(pieces)


def find_prices(page: WebPage) -> list[str]:
    candidates = page.text + " " + " ".join(page.meta.values())
    matches = re.findall(r"(?:¥|￥|人民币)?\s*\d+(?:\.\d{1,2})?\s*(?:元|块)(?:\s*/\s*(?:箱|件|盒|斤|公斤|kg))?", candidates, re.I)
    return list(dict.fromkeys(matches))[:20]


def find_references(page: WebPage) -> list[str]:
    refs = re.findall(r"(?:GB|NY|QB|DB)\s*/\s*T\s*[0-9-]+(?:[-—][0-9]+)?", page.text, re.I)
    return list(dict.fromkeys(refs))[:20]
