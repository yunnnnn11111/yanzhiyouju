"""联网检索：公开搜索引擎查词 + 结果页抓取。

与 core/web_extract.py 的分工：
- web_extract 负责「给你一个地址，把这一页读成结构化文本」；
- 本模块负责「只知道产品名，先在网上找到几个该看的页面，再交给 web_extract 读」。

设计取舍：
- 不需要任何搜索 API Key，按「必应 RSS → 必应网页 → 搜狗 → 360」逐级降级，
  前一个引擎失败或结果太少才换下一个；全部失败时把失败原因原样返回给界面。
- 检索结果只是「公开来源线索」，不是证据。是否可用由本地规则与证据门禁判定，
  这一点在提示词、界面文案和台账里都保持一致。
- 只用 Python 标准库，便携包不需要额外依赖。
"""

from __future__ import annotations

import html as html_lib
import re
import ssl
import time
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote, urljoin, urlparse
from urllib.request import Request
from contextvars import ContextVar
from core.public_http import public_urlopen as urlopen
import ipaddress

from . import web_extract

SEARCH_TIMEOUT = 5
_DEADLINE = ContextVar('search_deadline', default=None)
MAX_HTML_BYTES = 800 * 1024
MIN_PAGE_CHARS = 200

USER_AGENT = web_extract.USER_AGENT

# 搜索引擎自身的域名，出现在结果里说明是导航链接，不是内容页
_SKIP_HOSTS = {
    "bing.com", "www.bing.com", "cn.bing.com", "global.bing.com",
    "sogou.com", "www.sogou.com", "so.com", "www.so.com",
    "baidu.com", "www.baidu.com", "google.com", "www.google.com",
}

# 附件、图片、地图之类，抓下来也没有正文
_SKIP_SUFFIX = (
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".zip", ".rar", ".7z", ".exe", ".apk", ".jpg", ".jpeg", ".png", ".gif", ".mp4", ".mp3",
)

_BLOCKED_WORDS = ("登录", "注册", "下载 APP", "客户端下载")


class SearchError(RuntimeError):
    """联网检索失败。"""


# ---------------------------------------------------------------- 数据结构

@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str
    engine: str

    @property
    def host(self) -> str:
        try:
            return urlparse(self.url).netloc
        except ValueError:
            return ""

    def as_dict(self) -> dict[str, Any]:
        return {"title": self.title, "url": self.url, "snippet": self.snippet,
                "engine": self.engine, "host": self.host}


@dataclass
class Research:
    """一次联网检索的完整结果：查询词、命中的页面、失败记录。"""

    query: str
    engine: str
    queries: list[str] = field(default_factory=list)
    results: list[SearchResult] = field(default_factory=list)
    pages: list[web_extract.WebPage] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    elapsed: float = 0.0
    searched_at: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "query": self.query,
            "queries": self.queries,
            "engine": self.engine,
            "elapsed": round(self.elapsed, 2),
            "searched_at": self.searched_at,
            "results": [r.as_dict() for r in self.results],
            "pages": [{"url": p.url, "title": p.title, "fetched_at": p.fetched_at,
                       "status": p.status, "chars": len(p.text)} for p in self.pages],
            "errors": self.errors,
        }


# ---------------------------------------------------------------- 查询词

def build_query(product: dict, extra: str = "") -> str:
    """从产品档案拼一个可检索的查询词。

    只取产品称呼本身，不带价格、不带评价词。实测搜索引擎对「烟台苹果」这种短词
    最准，把产区、标准号一起塞进去反而会召回城市门户、单位换算之类的噪声页。
    """
    pr = (product or {}).get("product", {}) or {}
    name = re.sub(r"[（(].*?[）)]", "", pr.get("name") or "")
    name = re.sub(r"\s+", " ", name).strip()
    if extra:
        name = f"{name} {extra.strip()}".strip()
    return name or (pr.get("name") or "").strip()


def build_queries(product: dict) -> list[str]:
    """主查询词 + 备用查询词：主词结果太少时才继续用后面的。"""
    base = build_query(product)
    out: list[str] = []
    for candidate in (base, f"{base} 地理标志", f"{base} 产地 标准"):
        candidate = candidate.strip()
        if candidate and candidate not in out:
            out.append(candidate)
    return out


# ---------------------------------------------------------------- HTTP

def _get(url: str, timeout: int = SEARCH_TIMEOUT) -> tuple[str, str]:
    deadline = _DEADLINE.get()
    remaining = deadline - time.monotonic() if deadline else timeout
    if remaining <= 0:
        raise SearchError('检索已达时间上限，请缩短关键词后重试')
    timeout = max(0.2, min(timeout, remaining))
    req = Request(url, headers={
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
    })
    try:
        with urlopen(req, timeout=timeout) as resp:
            data = resp.read(MAX_HTML_BYTES + 1)
            if len(data) > MAX_HTML_BYTES: raise SearchError('搜索响应过大')
            ctype = resp.headers.get("Content-Type", "")
    except ssl.SSLError as exc:
        raise SearchError(f"TLS 握手失败：{exc}") from exc
    except Exception as exc:  # 网络异常一律转成本模块的异常，交由上层降级
        raise SearchError(f"{type(exc).__name__}: {exc}") from exc
    return web_extract._decode(data, ctype), ctype


def _strip_tags(value: str) -> str:
    value = re.sub(r"<[^>]+>", " ", value or "")
    value = html_lib.unescape(value)
    return re.sub(r"\s+", " ", value).strip()


def _acceptable(url: str, title: str) -> bool:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return False
    if parsed.username or parsed.password: return False
    try:
        if parsed.port not in (None,80,443): return False
    except ValueError: return False
    host = (parsed.hostname or '').lower()
    if host == 'localhost' or host.endswith(('.local','.internal')): return False
    try:
        if not ipaddress.ip_address(host).is_global: return False
    except ValueError: pass
    if host in _SKIP_HOSTS or host.endswith(".bing.com"):
        return False
    if host in ('image.so.com','pic.sogou.com','images.sogou.com'): return False
    if parsed.path.lower().endswith(_SKIP_SUFFIX):
        return False
    if not title or len(title) < 2:
        return False
    if any(word in title for word in _BLOCKED_WORDS):
        return False
    return True


def _dedupe(items: list[SearchResult], limit: int) -> list[SearchResult]:
    out: list[SearchResult] = []
    seen: set[str] = set()
    for item in items:
        key = item.url.split("#")[0].rstrip("/")
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
        if len(out) >= limit:
            break
    return out


# ---------------------------------------------------------------- 各引擎解析

def _engine_bing_rss(query: str, limit: int) -> list[SearchResult]:
    """必应 RSS：结构最稳，优先用。"""
    url = "https://cn.bing.com/search?q=" + quote(query) + "&format=rss&setlang=zh-CN&cc=CN"
    text, _ = _get(url)
    items: list[SearchResult] = []
    for block in re.findall(r"<item>(.*?)</item>", text, re.S):
        link = re.search(r"<link>(.*?)</link>", block, re.S)
        title = re.search(r"<title>(.*?)</title>", block, re.S)
        desc = re.search(r"<description>(.*?)</description>", block, re.S)
        if not link or not title:
            continue
        url_value = html_lib.unescape(link.group(1).strip())
        title_value = _strip_tags(title.group(1))
        if not _acceptable(url_value, title_value):
            continue
        items.append(SearchResult(title_value, url_value,
                                  _strip_tags(desc.group(1)) if desc else "", "bing-rss"))
    return _dedupe(items, limit)


def _split_blocks(html_text: str, marker: str) -> list[str]:
    parts = re.split(marker, html_text)
    return parts[1:] if len(parts) > 1 else []


def _engine_bing_html(query: str, limit: int) -> list[SearchResult]:
    url = "https://cn.bing.com/search?q=" + quote(query) + "&setlang=zh-CN&count=20"
    text, _ = _get(url)
    items: list[SearchResult] = []
    for block in _split_blocks(text, r'<li class="b_algo"'):
        head = re.search(r"<h2[^>]*>(.*?)</h2>", block, re.S)
        if not head:
            continue
        link = re.search(r"""<a[^>]+href=["']([^"']+)["']""", head.group(1))
        if not link:
            continue
        title = _strip_tags(head.group(1))
        href = html_lib.unescape(link.group(1))
        if href.startswith("/ck/a"):
            continue
        href = urljoin("https://cn.bing.com", href)
        snippet_m = re.search(r"<p[^>]*>(.*?)</p>", block, re.S)
        if not _acceptable(href, title):
            continue
        items.append(SearchResult(title, href, _strip_tags(snippet_m.group(1)) if snippet_m else "", "bing"))
    return _dedupe(items, limit)


def _engine_sogou(query: str, limit: int) -> list[SearchResult]:
    url = "https://www.sogou.com/web?query=" + quote(query)
    text, _ = _get(url)
    items: list[SearchResult] = []
    for block in _split_blocks(text, r'<div class="vrwrap"'):
        head = re.search(r"<h3[^>]*>(.*?)</h3>", block, re.S)
        if not head:
            continue
        link = re.search(r"""<a[^>]+href=["']([^"']+)["']""", head.group(1))
        if not link:
            continue
        title = _strip_tags(head.group(1))
        href = urljoin("https://www.sogou.com", html_lib.unescape(link.group(1)))
        snippet_m = re.search(r"<p[^>]*>(.*?)</p>", block, re.S)
        if not _acceptable(href, title):
            continue
        items.append(SearchResult(title, href, _strip_tags(snippet_m.group(1)) if snippet_m else "", "sogou"))
    return _dedupe(items, limit)


def _engine_so360(query: str, limit: int) -> list[SearchResult]:
    url = "https://www.so.com/s?q=" + quote(query)
    text, _ = _get(url)
    items: list[SearchResult] = []
    for block in _split_blocks(text, r'<li class="res-list"'):
        head = re.search(r"<h3[^>]*>(.*?)</h3>", block, re.S)
        if not head:
            continue
        link = re.search(r"""<a[^>]+href=["']([^"']+)["']""", head.group(1))
        if not link:
            continue
        title = _strip_tags(head.group(1))
        href = urljoin("https://www.so.com", html_lib.unescape(link.group(1)))
        snippet_m = re.search(r"""<p[^>]*class=["']res-desc["'][^>]*>(.*?)</p>""", block, re.S) \
            or re.search(r"<p[^>]*>(.*?)</p>", block, re.S)
        if not _acceptable(href, title):
            continue
        items.append(SearchResult(title, href, _strip_tags(snippet_m.group(1)) if snippet_m else "", "so360"))
    return _dedupe(items, limit)


ENGINES = [
    ("必应 RSS", _engine_bing_rss),
    ("必应网页", _engine_bing_html),
    ("搜狗", _engine_sogou),
    ("360 搜索", _engine_so360),
]


# ---------------------------------------------------------------- 对外接口

def _search(query: str, limit: int = 8, timeout: int = SEARCH_TIMEOUT) -> tuple[str, list[SearchResult], list[str]]:
    """按引擎顺序检索，返回 (命中引擎名, 结果列表, 失败记录)。

    前一个引擎能给出 3 条以上就停；否则继续试下一个，最后取结果最多的一次。
    """
    query = (query or "").strip()
    if not query:
        raise SearchError("检索词为空")

    best_engine, best_items = "", []
    terms=[x.strip('\"') for x in query.split() if len(x.strip('\"'))>=2]
    def relevance(item):
        hay=re.sub(r'\s+','',item.title+' '+item.snippet).lower()
        return sum(term.lower() in hay for term in terms)
    errors: list[str] = []
    for name, fn in ENGINES:
        if _DEADLINE.get() and time.monotonic() >= _DEADLINE.get(): break
        try:
            items = fn(query, limit)
            if terms:
                items=[item for item in items if relevance(item)>0]
                items.sort(key=relevance,reverse=True)
        except SearchError as exc:
            errors.append(f"{name}：{exc}")
            continue
        except Exception as exc:  # 解析异常同样降级
            errors.append(f"{name}：{type(exc).__name__}: {exc}")
            continue
        if (sum(relevance(i) for i in items),len(items)) > (sum(relevance(i) for i in best_items),len(best_items)):
            best_engine, best_items = name, items
        if len(items) >= 3 and (len(terms)<2 or relevance(items[0])==len(terms)):
            return name, items, errors
    if not best_items:
        raise SearchError("全部搜索引擎都没有返回可用结果。" + ("；".join(errors) if errors else ""))
    return best_engine, best_items, errors


def search(query: str, limit: int = 8, timeout: int = SEARCH_TIMEOUT):
    if not isinstance(query,str) or not 2 <= len(query.strip()) <= 200:
        raise SearchError('请输入 2–200 字的搜索关键词')
    token = _DEADLINE.set(time.monotonic()+18)
    try:
        return _search(query.strip(), max(1,min(int(limit),8)), timeout)
    finally:
        _DEADLINE.reset(token)


def research(queries: str | list[str], limit: int = 8, max_pages: int = 3,
             page_timeout: int = 12, budget: float = 30.0) -> Research:
    """检索 + 抓取前几个结果页正文。

    - queries：主查询词；也接受一组查询词，主词结果太少时才用后面的补；
    - max_pages：最多抓几页（默认 3，兼顾速度与信息量）；
    - budget：整次联网检索的时间上限（秒），超时不再发起新的抓取。
    """
    started = time.time()
    if isinstance(queries, str):
        queries = [queries]
    queries = [q.strip() for q in queries if q and q.strip()]
    if not queries:
        raise SearchError("检索词为空")

    errors: list[str] = []
    engine = ""
    collected: list[SearchResult] = []
    for query in queries:
        if len(collected) >= 4:
            break
        try:
            found_engine, items, errs = search(query, limit=limit)
        except SearchError as exc:
            errors.append(f"{query}：{exc}")
            continue
        if not engine:
            engine = found_engine
        errors.extend(errs)
        collected.extend(items)
    if not collected:
        raise SearchError("没有搜到任何可用结果。" + "；".join(errors[:3]))
    results = _dedupe(collected, limit)

    pages: list[web_extract.WebPage] = []
    for item in results:
        if len(pages) >= max_pages or time.time() - started > budget:
            break
        if any(p.url.split("#")[0] == item.url.split("#")[0] for p in pages):
            continue
        try:
            page = web_extract.fetch(item.url, timeout=page_timeout)
        except web_extract.WebExtractError as exc:
            errors.append(f"{item.host}：{exc}")
            continue
        except Exception as exc:
            errors.append(f"{item.host}：{type(exc).__name__}: {exc}")
            continue
        if len(page.text) < MIN_PAGE_CHARS:
            # 正文过少基本等于没读到（需要登录、动态渲染或反爬），不当作来源
            errors.append(f"{item.host}：页面正文过少（{len(page.text)} 字），疑似需要登录或动态加载")
            continue
        pages.append(page)

    return Research(
        query=queries[0],
        queries=queries,
        engine=engine,
        results=results,
        pages=pages,
        errors=errors,
        elapsed=time.time() - started,
        searched_at=time.strftime("%Y-%m-%d %H:%M:%S"),
    )


def fetch_selected(urls: list[str], max_pages: int = 4,
                   budget: float = 30.0) -> tuple[list[web_extract.WebPage], list[str]]:
    """抓取界面里用户勾选的来源地址。"""
    started = time.time()
    pages: list[web_extract.WebPage] = []
    errors: list[str] = []
    for url in urls:
        if len(pages) >= max_pages or time.time() - started > budget:
            break
        if any(p.url == url for p in pages):
            continue
        try:
            page = web_extract.fetch(url, timeout=15)
        except web_extract.WebExtractError as exc:
            errors.append(f"{url}：{exc}")
            continue
        except Exception as exc:
            errors.append(f"{url}：{type(exc).__name__}: {exc}")
            continue
        if len(page.text) < MIN_PAGE_CHARS:
            errors.append(f"{url}：页面正文过少（{len(page.text)} 字），疑似需要登录或动态加载")
            continue
        pages.append(page)
    return pages, errors
