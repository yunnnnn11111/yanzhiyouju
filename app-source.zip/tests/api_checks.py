import json, sys, time, urllib.request, urllib.error, http.cookiejar, os
BASE = os.environ["E2E_BASE_URL"]
RESULTS = []
class Client:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))
    def call(self, method, path, data=None, expected=None):
        body = None
        headers = {"X-Requested-With": "YanZhiYouJu"}
        if data is not None:
            body = json.dumps(data, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json; charset=utf-8"
        req = urllib.request.Request(BASE + path, data=body, headers=headers, method=method)
        try:
            with self.opener.open(req, timeout=60) as r:
                status = r.status; raw = r.read(); hdr = dict(r.headers)
        except urllib.error.HTTPError as e:
            status = e.code; raw = e.read(); hdr = dict(e.headers)
        try: payload = json.loads(raw.decode("utf-8")) if raw else {}
        except Exception: payload = {"_raw": raw.decode("utf-8", "replace")}
        if expected is not None and status not in ((expected,) if isinstance(expected, int) else expected):
            raise AssertionError(f"{method} {path}: expected {expected}, got {status}: {payload}")
        return status, payload, hdr
    def get(self, path, expected=200): return self.call("GET", path, expected=expected)
    def post(self, path, data, expected=200): return self.call("POST", path, data=data, expected=expected)
def check(name, cond, detail=""):
    if not cond: raise AssertionError(name + (": " + str(detail) if detail else ""))
    RESULTS.append(name)
def product(name="烟台苹果"):
    return {"name":name,"origin_address":"山东省烟台市栖霞市","organization":"栖霞市示例果业合作社","batch_weight_kg":500,"variety":"红富士","spec":"80mm 果径，一级果","unit_price_yuan_per_kg":8,"unit_cost_yuan_per_kg":3,"transport":"冷链车","storage":"0-5℃冷库，可存30天","transport_capacity_kg":1000,"daily_capacity_kg":200,"target_market":"西安、成都、企业福利采购"}
try:
    guest = Client(); guest.get("/")
    _, me, _ = guest.get("/api/auth/me"); check("游客自动建立临时会话", me["identity"]["kind"] == "guest")
    _, h, _ = guest.get("/api/health"); check("健康接口", h.get("ok") is True)
    _, created, _ = guest.post("/api/batches", {"product":product(),"mode":"web","photos":[]})
    gid = created["batch"]["id"]; check("游客创建批次", gid.startswith("BAT-"))
    _, analyzed, _ = guest.post(f"/api/batches/{gid}/analyze", {"mode":"web"})
    b = analyzed["batch"]; check("联网分析不依赖 API", b["status"] in ("analyzed","reviewed"))
    check("全部渠道测算", len(b["plans"]) == 7, len(b["plans"]))
    check("逐条主张结果完整", len(b["claims"]) == b["gate"]["summary"]["total"] and len(b["claims"]) >= 4)
    check("盈亏区间顺序正确", all(p["economics"]["profit_low"] <= p["economics"]["profit"] <= p["economics"]["profit_high"] for p in b["plans"]))
    check("1 最优 + 2 次优", len(b["recommended_plan_ids"]) == 3 and sum(1 for p in b["plans"] if p.get("is_best")) == 1)
    check("默认苹果示例缺证被门禁拦截", b["gate"]["blocked"] > 0, b["gate"])
    check("证据生命周期字段", all(k in b["evidence"][0] for k in ("fetched_at","expires_at","snapshot","status")))
    _, ev, _ = guest.post(f"/api/batches/{gid}/evidence", {"type":"ORIGIN_PROOF","source_level":"政府/主管部门","source_name":"栖霞市人民政府示例公开页","source_url":"https://www.yantai.gov.cn/","published_at":"2026-01-01","expires_at":"2027-12-31","detail":"示例材料：用于自动化验收，非真实证书。主体与批次待人工核验。","matches_batch":True})
    manual = ev["batch"]["evidence"][-1]
    eid = manual["id"]; check("手工补证保存哈希", bool(manual.get("snapshot") or manual.get("attachment")))
    _, verified, _ = guest.post(f"/api/batches/{gid}/verify", {"evidence_id":eid,"decision":"verified","reason":"已核对主体、批次和有效期（自动化测试）"})
    check("证据核验通过", next(x for x in verified["batch"]["evidence"] if x["id"]==eid)["status"] == "verified")
    _, conflict, _ = guest.post(f"/api/batches/{gid}/evidence", {"type":"PRICE_REF","source_level":"平台公开数据","source_name":"示例价格页面","source_url":"https://example.com/price","published_at":"2026-10-01","expires_at":"2027-12-31","detail":"示例价格线索，非真实采集数据。","matches_batch":True})
    cid = conflict["batch"]["evidence"][-1]["id"]
    _, conflict, _ = guest.post(f"/api/batches/{gid}/verify", {"evidence_id":cid,"decision":"conflict","reason":"来源价格与批次规格不一致"})
    check("证据冲突状态可记录", next(x for x in conflict["batch"]["evidence"] if x["id"]==cid)["status"] == "conflict")
    _, rejected, _ = guest.post(f"/api/batches/{gid}/evidence", {"type":"TEST_REPORT","source_level":"检测/认证机构","source_name":"示例检测材料","published_at":"2026-10-01","expires_at":"2027-12-31","detail":"示例检测线索，没有报告编号。","matches_batch":True})
    rid = rejected["batch"]["evidence"][-1]["id"]
    _, rejected, _ = guest.post(f"/api/batches/{gid}/verify", {"evidence_id":rid,"decision":"rejected","reason":"缺少报告编号和检测机构印章"})
    check("证据驳回状态可记录", next(x for x in rejected["batch"]["evidence"] if x["id"]==rid)["status"] == "rejected")
    _, extract, _ = guest.post(f"/api/batches/{gid}/extract", {"url":"not-a-url"}, expected=(400,502))
    check("网页提取异常有明确反馈", "失败" in extract.get("error","") or "不支持" in extract.get("error",""))

    suffix = str(int(time.time()))[-7:]
    u1 = Client(); user1name = "e2e1_" + suffix
    _, reg1, _ = u1.post("/api/auth/register", {"username":user1name,"password":"User1Pass2026"})
    uid1 = reg1["user"]["id"]; check("普通用户注册", reg1["user"]["role"] == "user")
    _, c1, _ = u1.post("/api/batches", {"product":product("烟台苹果批次A"),"mode":"web","photos":[]})
    id1 = c1["batch"]["id"]
    _, a1, _ = u1.post(f"/api/batches/{id1}/analyze", {"mode":"web"})
    check("注册用户完成全链路分析", len(a1["batch"]["plans"]) == 7)
    _, own, _ = u1.get(f"/api/batches/{id1}"); check("用户可读取自己的批次", own["batch"]["id"] == id1)
    u2 = Client(); user2name = "e2e2_" + suffix
    u2.post("/api/auth/register", {"username":user2name,"password":"User2Pass2026"})
    _, isolated, _ = u2.get(f"/api/batches/{id1}", expected=404)
    check("普通用户数据隔离", isolated.get("ok") is False)
    _, badcontent, _ = u1.post(f"/api/batches/{id1}/content", {"content":{"detail_page":"烟台苹果是全国最好的苹果，保证治愈疾病。","oral_script":"原价999元，限时最低，买一送一。","social_post":"零农药，当天采摘，现摘现发。"}})
    check("违规文案自动拦截", badcontent["compliance"]["level"] in ("blocker","high"), badcontent["compliance"]["level"])
    blocked_export, blocked_export_payload, _ = u1.post(f"/api/batches/{id1}/export", {"format":"md"}, expected=400)
    check("高风险文案阻止导出", blocked_export == 400)
    u1.post(f"/api/batches/{id1}/override", {"reason":"测试复核说明不能绕过高风险拦截"}, expected=(400,403))
    check("风险内容不能强制放行", True)
    clean = {"detail_page":"本批苹果信息由提交人登记，交易前请核对规格与发货时间。", "oral_script":"欢迎了解本批产品，价格和配送安排请向供货方确认。", "social_post":"产品信息以实际验货为准，材料可在批次档案查看。"}
    _, cleaned, _ = u1.post(f"/api/batches/{id1}/content", {"content":clean})
    check("整改后重新审查", not cleaned["compliance"]["blocked"])
    _, exp_md, _ = u1.post(f"/api/batches/{id1}/export", {"format":"md"}); check("Markdown 导出", exp_md["filename"].endswith(".md") and len(exp_md["text"]) > 100)
    _, exp_json, _ = u1.post(f"/api/batches/{id1}/export", {"format":"json"}); check("JSON 导出", exp_json["filename"].endswith(".json"))
    _, fb, _ = u1.post(f"/api/batches/{id1}/feedback", {"channel_code":"group","sold_kg":20,"revenue_yuan":220,"returns_kg":1,"profit_yuan":40,"notes":"自动化测试回填，非真实销售数据"})
    check("销售结果回填闭环", fb["batch"]["feedback"]["sold_kg"] == 20)
    _, agent_batch, _ = u1.post("/api/batches", {"product":product("Agent测试苹果"),"mode":"agent","photos":[]})
    agent_id = agent_batch["batch"]["id"]
    _, agent_fail, _ = u1.post(f"/api/batches/{agent_id}/analyze", {"mode":"agent","api_source":"own"}, expected=(400,403,502))
    check("Agent 未配置 API 明确失败", not agent_fail.get("ok", True), agent_fail)

    admin = Client(); admin.post("/api/auth/login", {"username":"admin","password":"TestAdmin2026"})
    pending, pending_payload, _ = admin.get("/api/admin/users", expected=403)
    check("管理员首次登录强制改密", pending == 403)
    _, changed, _ = admin.post("/api/auth/password", {"old_password":"TestAdmin2026","new_password":"AdminChanged2026"})
    check("管理员修改初始密码", changed["user"]["must_change_password"] is False)
    _, users, _ = admin.get("/api/admin/users"); check("管理员查看全部用户", any(u["id"] == uid1 for u in users["users"]))
    _, allb, _ = admin.get("/api/admin/batches"); check("管理员查看全部批次", any(x["id"] == id1 for x in allb["batches"]))
    _, admin_detail, _ = admin.get(f"/api/admin/batch/{id1}")
    check("管理员查看证据与审计", bool(admin_detail["batch"].get("evidence")) and bool(admin_detail.get("audit")))
    denied, denied_payload, _ = admin.post(f"/api/batches/{id1}/verify", {"evidence_id":"EVD-not-exist","decision":"verified","reason":"admin read only test"}, expected=403)
    check("管理员不能代改他人批次", denied == 403)
    _, settings, _ = admin.get("/api/admin/settings"); ds = settings["settings"]["data_sources"]
    _, saved, _ = admin.post("/api/admin/settings", {"data_sources":{"search_order":ds["search_order"],"max_pages_per_collect":ds["max_pages_per_collect"]}})
    check("管理员保存平台设置", "data_sources" in saved.get("changed", []))
    _, public_settings, _ = guest.get("/api/auth/me"); check("平台 API 密钥未暴露", "api_key" not in json.dumps(public_settings.get("platform_api",{})))
    _, audit, _ = admin.get("/api/admin/audit/verify"); check("审计哈希链完整", audit.get("ok") is True and audit.get("broken", []) == [], audit)
    u1.post(f"/api/batches/{id1}", {"product":{"batch_weight_kg":600}})
    u1.post(f"/api/batches/{id1}/export", {"format":"json"}, expected=400)
    check("档案变更阻断旧结果导出", True)
    u1.post(f"/api/batches/{id1}", {"mode":"invalid"}, expected=400)
    check("非法分析模式被拒绝", True)
    u1.post("/api/batches", {"product":dict(product(),batch_weight_kg=float("nan"))},expected=400)
    check("非有限数字被拒绝", True)
    other = Client(); other.post("/api/auth/login", {"username":user1name,"password":"User1Pass2026"})
    u1.post("/api/auth/password", {"old_password":"User1Pass2026","new_password":"ChangedUser2026"})
    other.get(f"/api/batches/{id1}",expected=(401,404))
    check("修改密码使旧会话失效", True)
    _, sparse, _ = u2.post("/api/batches", {"product":product("普通苹果")})
    u2.post(f"/api/batches/{sparse['batch']['id']}/export", {"format":"md"}, expected=400)
    check("未分析的空报告不可导出", True)
    print(json.dumps({"ok":True,"checks":len(RESULTS),"results":RESULTS}, ensure_ascii=False, indent=2))
except Exception as exc:
    print(json.dumps({"ok":False,"checks":len(RESULTS),"results":RESULTS,"error":str(exc)}, ensure_ascii=False, indent=2))
    sys.exit(1)


