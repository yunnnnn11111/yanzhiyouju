"""cloud_sync 的离线自检：打包/解包往返、状态接口、未配置时的空转。

不联网，因此可以放进回归；真正的 GitHub 往返需要 SYNC_TOKEN。
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

FAILS: list[str] = []
COUNT = 0


def check(name: str, ok: bool, detail: str = "") -> None:
    global COUNT
    COUNT += 1
    if ok:
        print(f"PASS: {name}")
    else:
        FAILS.append(f"{name} {detail}".strip())
        print(f"FAIL: {name} {detail}")


def main() -> int:
    from core import cloud_sync

    check("未配置时 configured() 为假", cloud_sync.configured() is False)
    boot = cloud_sync.boot()
    check("未配置时 boot 不抛错", isinstance(boot, dict) and boot.get("ok") is False)

    state = cloud_sync.status()
    check("status 字段齐全", set(state) == {"configured", "repo", "path", "branch", "dirty", "last_push", "error"})
    check("status 不泄露 token", "token" not in str(state).lower())

    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "src"
        (src / "accounts" / "abc").mkdir(parents=True)
        (src / "users.json").write_text('{"users": [1]}', encoding="utf-8")
        (src / "accounts" / "abc" / "batches.json").write_text('{"batches": []}', encoding="utf-8")
        (src / "guests").mkdir()
        (src / "guests" / "tmp.json").write_text("{}", encoding="utf-8")

        raw = cloud_sync._pack(src)
        check("打包产出 gzip", raw[:2] == b"\x1f\x8b")

        dst = Path(tmp) / "dst"
        dst.mkdir()
        count = cloud_sync._unpack(raw, dst, primary=True)
        check("解包文件数=2（不含 guests）", count == 2, f"got {count}")
        check("users.json 内容一致", (dst / "users.json").read_text(encoding="utf-8") == '{"users": [1]}')
        check("账号目录已恢复", (dst / "accounts" / "abc" / "batches.json").exists())
        check("guests 未同步", not (dst / "guests").exists())

        backup = Path(tmp) / "backup"
        backup.mkdir()
        (backup / "users.json").write_text('{"users": [2]}', encoding="utf-8")
        merged = cloud_sync._unpack(raw, backup, primary=False)
        check("非覆盖模式只补缺", merged == 1, f"got {merged}")
        check("非覆盖模式不覆盖已有文件", (backup / "users.json").read_text(encoding="utf-8") == '{"users": [2]}')

    print(f"\n共 {COUNT} 项检查，失败 {len(FAILS)} 项")
    if FAILS:
        print(json_dump(FAILS))
        return 1
    return 0


def json_dump(items: list[str]) -> str:
    import json

    return json.dumps(items, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    raise SystemExit(main())
