const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../web/app.js'), 'utf8');
const start = source.indexOf('async function showView(view)');
const end = source.indexOf('const SEVERITY_LABELS');
assert(start >= 0 && end > start);
const calls = [];
const state = {currentBatch: {id:'test-batch'}, batches:[], currentView:'report'};
const context = vm.createContext({
  state, isAdmin:()=>false, toast:()=>{}, $$:()=>[],
  window:{scrollTo:()=>{}},
  loadBatch:async (id, view)=>calls.push(['load',id,view]),
  renderReport:batch=>calls.push(['report',batch.id]),
  loadRules:async()=>calls.push(['rules']),
  loadCases:async()=>calls.push(['cases']),
  loadAdmin:async()=>{}
});
vm.runInContext(source.slice(start,end),context);
(async()=>{
  await vm.runInContext('showView("batch")',context);
  assert.deepEqual(calls.pop(),['load','test-batch','batch']);
  await vm.runInContext('showView("report")',context);
  assert.deepEqual(calls.pop(),['report','test-batch']);
  state.currentBatch=null; state.batches=[{id:'recent-batch'}];
  await vm.runInContext('showView("batch")',context);
  assert.deepEqual(calls.pop(),['load','recent-batch','batch']);
  state.currentBatch={id:'test-batch'};
  await vm.runInContext('showView("rules")',context);
  assert.deepEqual(calls.pop(),['rules']);
  assert.equal(state.currentView,'rules');
  await vm.runInContext('showView("cases")',context);
  assert.deepEqual(calls.pop(),['cases']);
  assert.equal(state.currentView,'cases');
  console.log('PASS: report-to-batch, batch-to-report, recent-batch, rules and cases navigation');
})().catch(error=>{ console.error(error); process.exitCode=1; });
