"""Run isolated API checks with disposable data and no external model calls."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
from wsgiref.simple_server import make_server, WSGIRequestHandler

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
class QuietHandler(WSGIRequestHandler):
    def log_message(self, *args):
        pass

def main():
    with tempfile.TemporaryDirectory(prefix="yzyj-checks-") as data:
        os.environ.update(APP_DATA_DIR=data, ADMIN_USERNAME="admin", ADMIN_PASSWORD="TestAdmin2026", APP_ENV="test", PYTHONIOENCODING="utf-8")
        os.environ.pop("RENDER", None)
        import cloud_app
        from core import evidence, channel_analysis
        from core import web_search, settings_store
        from unittest.mock import patch
        for configured, actual in (("DuckDuckGo", "DuckDuckGo 公开网页"), ("360", "360 搜索")):
            seen = []
            def fake_search(query, limit):
                seen.append(query)
                return [web_search.SearchResult("测试苹果", f"https://example.com/mock-{i}", "仅测试替身", actual) for i in range(3)]
            with patch.object(web_search, "ENGINES", [(actual, fake_search)]), patch.object(settings_store, "get_settings", return_value={"data_sources":{"search_order":[configured]}}):
                engine, items, errors = web_search._search("测试苹果")
                assert seen == ["测试苹果"] and len(items) == 3 and not errors
        print("PASS: configured search-source aliases invoke the intended engine (mocked)", flush=True)
        from core import workflow, batch_store
        from types import SimpleNamespace
        assert workflow.source_level("https://www.samr.gov.cn/page") == "政府/主管部门"
        assert workflow.source_level("https://samr.gov.cn.example.com/page") == "其他公开来源"
        assert workflow.source_level("https://example.com/page", "官方标准检测认证研究院") == "其他公开来源"
        assert workflow.source_level("https://item.jd.com/page") == "平台公开数据"
        page = SimpleNamespace(url="https://example.com/evidence",title="测试标准资料",text="仅测试替身正文"*20,fetched_at="2026-10-30T00:00:00+00:00")
        research = SimpleNamespace(pages=[page],engine="mock",queries=["测试苹果"],elapsed=0.1,errors=[])
        with patch.object(web_search, "research", return_value=research), patch.object(batch_store, "save_snapshot", return_value={"sha256":"test-only"}), patch.object(batch_store, "update_pipeline", side_effect=lambda batch, changes, user, action:dict(batch, **changes)):
            collected = workflow.collect_public({"id":"BAT-TESTONLY","product":{"name":"测试苹果"},"evidence":[]}, {}, "测试苹果")
            assert len(collected["sources"]) == 1 and collected["sources"][0]["host"] == "example.com"
            assert collected["sources"][0]["verified"] is False
        print("PASS: source-domain boundaries and successful collection pipeline (mocked)", flush=True)
        original = {"type":"ORIGIN_PROOF", "provided":True, "status":"verified", "matches_batch":True, "expires_at":"2999-01-01"}
        claim = {"claim":"测试产地", "required_evidence":["ORIGIN_PROOF"]}
        assert evidence.run_gate([claim], [original])["claims"][0]["gate"] == "PASS"
        for change in ({"expires_at":"2000-01-01"}, {"matches_batch":False}, {"status":"pending"}, {"status":"conflict"}):
            assert evidence.run_gate([claim], [dict(original, **change)])["claims"][0]["gate"] == "BLOCK"
        assert evidence.run_gate([claim], [original, dict(original,status="conflict")])["claims"][0]["gate"] == "BLOCK"
        negative = channel_analysis.analyze({"product":{"name":"测试", "organization":"测试", "batch_weight_kg":100,"unit_price_yuan_per_kg":1,"unit_cost_yuan_per_kg":50},"evidence":[]})
        assert all(p["economics"]["profit_low"] <= p["economics"]["profit"] <= p["economics"]["profit_high"] for p in negative["all_plans"])
        print("PASS: expired/conflicting/mismatched evidence and negative-profit intervals", flush=True)
        quote = dict(original, type="PRICE_REF", detail="参考价格 8元/kg")
        assert channel_analysis._price_and_cost({"product":{}, "evidence":[quote]})[0] == 8
        for detail in ("80元/箱", "5元/斤", "售价80元", "8-10元/kg", "8元/kg，9元/kg"):
            assert channel_analysis._price_and_cost({"product":{}, "evidence":[dict(quote, detail=detail)]})[0] == 0
        assert channel_analysis._price_and_cost({"product":{}, "evidence":[quote, dict(quote,status="conflict")]})[0] == 0
        print("PASS: ambiguous units, price ranges and conflicting prices require confirmation", flush=True)
        server = make_server("127.0.0.1", 0, cloud_app.application, handler_class=QuietHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        env = dict(os.environ, E2E_BASE_URL=f"http://127.0.0.1:{server.server_port}")
        try:
            return subprocess.run([sys.executable, str(ROOT / "tests" / "api_checks.py")], env=env, cwd=ROOT).returncode
        finally:
            server.shutdown()
            server.server_close()

if __name__ == "__main__":
    raise SystemExit(main())
