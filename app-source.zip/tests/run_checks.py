"""Run isolated API checks with disposable data and no external model calls."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
from wsgiref.simple_server import make_server, WSGIRequestHandler

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
class QuietHandler(WSGIRequestHandler):
    def log_message(self, *args):
        pass

def main():
    with tempfile.TemporaryDirectory(prefix="yzyj-checks-") as data:
        os.environ.update(APP_DATA_DIR=data, ADMIN_USERNAME="admin", ADMIN_PASSWORD="TestAdmin2026", APP_ENV="test", PYTHONIOENCODING="utf-8")
        os.environ.pop("RENDER", None)
        import cloud_app
        from core import evidence, channel_analysis
        original = {"type":"ORIGIN_PROOF", "provided":True, "status":"verified", "matches_batch":True, "expires_at":"2999-01-01"}
        claim = {"claim":"测试产地", "required_evidence":["ORIGIN_PROOF"]}
        assert evidence.run_gate([claim], [original])["claims"][0]["gate"] == "PASS"
        for change in ({"expires_at":"2000-01-01"}, {"matches_batch":False}, {"status":"pending"}, {"status":"conflict"}):
            assert evidence.run_gate([claim], [dict(original, **change)])["claims"][0]["gate"] == "BLOCK"
        assert evidence.run_gate([claim], [original, dict(original,status="conflict")])["claims"][0]["gate"] == "BLOCK"
        negative = channel_analysis.analyze({"product":{"name":"测试", "organization":"测试", "batch_weight_kg":100,"unit_price_yuan_per_kg":1,"unit_cost_yuan_per_kg":50},"evidence":[]})
        assert all(p["economics"]["profit_low"] <= p["economics"]["profit"] <= p["economics"]["profit_high"] for p in negative["all_plans"])
        print("PASS: expired/conflicting/mismatched evidence and negative-profit intervals", flush=True)
        quote = dict(original, type="PRICE_REF", detail="参考价格 8元/kg")
        assert channel_analysis._price_and_cost({"product":{}, "evidence":[quote]})[0] == 8
        for detail in ("80元/箱", "5元/斤", "售价80元", "8-10元/kg", "8元/kg，9元/kg"):
            assert channel_analysis._price_and_cost({"product":{}, "evidence":[dict(quote, detail=detail)]})[0] == 0
        assert channel_analysis._price_and_cost({"product":{}, "evidence":[quote, dict(quote,status="conflict")]})[0] == 0
        print("PASS: ambiguous units, price ranges and conflicting prices require confirmation", flush=True)
        server = make_server("127.0.0.1", 0, cloud_app.application, handler_class=QuietHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        env = dict(os.environ, E2E_BASE_URL=f"http://127.0.0.1:{server.server_port}")
        try:
            return subprocess.run([sys.executable, str(ROOT / "tests" / "api_checks.py")], env=env, cwd=ROOT).returncode
        finally:
            server.shutdown()
            server.server_close()

if __name__ == "__main__":
    raise SystemExit(main())
