"""公开溯源页的自检（不依赖线上实例）。

覆盖：找不到批次、分享码校验、载荷字段、隐私字段不外泄、哈希稳定。
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main() -> int:
    checks: list[tuple[str, bool, str]] = []

    with tempfile.TemporaryDirectory() as tmp:
        os.environ["APP_DATA_DIR"] = tmp
        os.environ.setdefault("SESSION_SECRET", "trace-test-secret")

        # 重新导入，确保 DATA_ROOT 指向临时目录
        for name in [m for m in sys.modules if m.startswith("core.")]:
            sys.modules.pop(name)
        from core import trace  # noqa: E402

        account = "a" * 48
        batch_dir = Path(tmp) / "accounts" / account / "batches"
        batch_dir.mkdir(parents=True, exist_ok=True)
        batch_id = "BAT-20261118-TRACE001"
        batch = {
            "id": batch_id,
            "created_at": "2026-11-18T10:00:00",
            "updated_at": "2026-11-18T10:30:00",
            "status": "reviewed",
            "mode": "web",
            "owner_id": "usr_test",
            "product": {"name": "烟台苹果", "origin": "山东省烟台市栖霞市", "variety": "红富士", "weight_kg": 500},
            "gate": {"passed": 3, "blocked": 2},
            "claims": [{"id": "C1", "claim": "产地为栖霞"}],
            "compliance": {"level": "blocker", "blocked": True},
            "evidence": [
                {"id": "E1", "type": "BATCH_RECORD", "label": "批次档案", "status": "verified", "provided": True,
                 "sha256": "abc123", "verified_at": "2026-11-18", "verification_note": "内部备注"},
                {"id": "E2", "type": "GI_CERT", "label": "地理标志证明", "status": "missing", "provided": False},
            ],
            "photos": [{"name": "果园.jpg", "caption": "产地实拍", "sha256": "def456", "added_at": "2026-11-18"}],
            "timeline": [{"at": "2026-11-18T10:30:00", "action": "生成方案", "detail": "ok"}],
        }
        path = batch_dir / f"{batch_id}.json"
        path.write_text(json.dumps(batch, ensure_ascii=False), encoding="utf-8")

        found = trace.find(batch_id)
        checks.append(("能按批次号找到档案", found is not None, ""))

        data = trace.payload(batch, path) if found else {}
        checks.append(("产品信息完整", data.get("product", {}).get("产品") == "烟台苹果", str(data.get("product"))))
        checks.append(("证据计数正确", data.get("summary", {}).get("evidence_provided") == 1, ""))
        checks.append(("缺失证据标为未提供", any(e["status_text"] == "未提供" for e in data.get("evidence", [])), ""))
        checks.append(("档案哈希等于文件哈希",
                       data.get("integrity", {}).get("archive_sha256") == hashlib.sha256(path.read_bytes()).hexdigest(), ""))

        code = trace.share_code(batch_id)
        checks.append(("分享码校验通过", trace.code_ok(batch_id, code), code))
        checks.append(("错误分享码被拒", not trace.code_ok(batch_id, "0" * len(code)), ""))
        checks.append(("不同批次分享码不同", trace.share_code(batch_id) != trace.share_code("BAT-20261118-TRACE002"), ""))

        blob = json.dumps(data, ensure_ascii=False)
        checks.append(("不泄露 owner_id", "usr_test" not in blob, ""))
        checks.append(("不含账号密码字段", "password" not in blob.lower(), ""))
        checks.append(("非法批次号返回空", trace.find("not-a-batch") is None, ""))

        svg = trace.qr_svg("https://example.com/t/" + batch_id + "?k=" + code)
        checks.append(("二维码是 SVG", svg.startswith(b"<?xml"), svg[:20].decode("utf-8", "ignore")))
        checks.append(("二维码含路径", b"<path" in svg, str(len(svg))))

        # 页面文件存在
        checks.append(("trace.html 存在", (ROOT / "web" / "trace.html").is_file(), ""))

    failed = [row for row in checks if not row[1]]
    for name, ok, extra in checks:
        print(f"{'PASS' if ok else 'FAIL'}  {name}{('  [' + extra + ']') if extra else ''}")
    print(f"\n共 {len(checks)} 项检查，失败 {len(failed)} 项")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
