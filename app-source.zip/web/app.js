(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const state = {
    me: null,
    batches: [],
    currentBatch: null,
    currentView: "workbench",
    mode: "web",
    photos: [],
    admin: null,
    busy: false
  };
  const FEATURE_LABELS = {
    registration_enabled: "开放自助注册",
    guest_analysis_enabled: "游客临时分析",
    web_collection_enabled: "公开网页采集",
    platform_api_enabled: "启用平台 API",
    user_api_enabled: "允许用户自有 API",
    export_enabled: "报告导出",
    manual_override_enabled: "人工复核申请（不能绕过拦截）"
  };
  const STATUS_LABELS = {
    draft: "档案待补充", collected: "已有线索", evidence: "证据整理中",
    analyzed: "分析完成", reviewed: "合规待处理", paused: "待重新分析",
    exported: "已导出", feedback: "已回填反馈"
  };
  const EVIDENCE_STATUS = {
    pending: "待核验", verified: "已核验", rejected: "已驳回",
    conflict: "存在冲突", expired: "已过期"
  };
  const LEVEL_LABELS = {
    pass: "通过", medium: "需调整", high: "高风险", blocker: "阻断"
  };

  function esc(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function safeUrl(value) {
    try {
      if (!value) return "";
      const url = new URL(String(value), window.location.origin);
      return ["http:", "https:"].includes(url.protocol) ? url.href : "";
    } catch (_) { return ""; }
  }
  const EVIDENCE_LABELS = {BATCH_RECORD:"批次档案",TRANSPORT_STORAGE:"运输仓储",GI_CERT:"地理标志证明",ORIGIN_PROOF:"产地证明",GRADE_STANDARD:"等级依据",TEST_REPORT:"检测报告",PRICE_REF:"价格依据",PROCESS_RECORD:"工艺记录",GREEN_CERT:"认证证书",SALES_DATA:"销售数据",USER_FEEDBACK:"用户反馈"};
  function evidenceNames(values) { return (values || []).map((v) => EVIDENCE_LABELS[v] || v).join("、"); }
  function number(value, digits = 1) {
    const n = Number(value);
    if (!Number.isFinite(n)) return "—";
    return n.toLocaleString("zh-CN", { maximumFractionDigits: digits });
  }
  function money(value) {
    const n = Number(value);
    return Number.isFinite(n) ? `¥${n.toLocaleString("zh-CN", { maximumFractionDigits: 2 })}` : "—";
  }
  function dateText(value) {
    if (!value) return "未记录";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleString("zh-CN", { hour12: false, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
  }
  function statusPill(status) {
    return `<span class="status-pill ${esc(status || "")}">${esc(STATUS_LABELS[status] || status || "未知")}</span>`;
  }
  function modePill(mode) {
    return `<span class="mode-pill ${esc(mode)}">${mode === "agent" ? "Agent 模式" : "联网模式"}</span>`;
  }
  function emptyState(text) { return `<div class="empty-state">${esc(text)}</div>`; }

  function toast(message, type = "success", duration = 4200) {
    const node = document.createElement("div");
    node.className = `toast ${type}`;
    node.textContent = String(message || "操作完成");
    $("#toastRoot").appendChild(node);
    setTimeout(() => node.remove(), duration);
  }
  function setBusy(button, busy, text = "处理中…") {
    if (!button) return;
    if (busy) {
      button.dataset.originalText = button.textContent;
      button.textContent = text;
      button.disabled = true;
    } else {
      button.textContent = button.dataset.originalText || button.textContent;
      button.disabled = false;
    }
  }
  async function api(path, options = {}) {
    const request = { method: options.method || "GET", credentials: "same-origin", headers: {} };
    if (request.method === "POST") {
      request.headers["Content-Type"] = "application/json";
      request.headers["X-Requested-With"] = "YanZhiYouJu";
      request.body = JSON.stringify(options.body || {});
    }
    const response = await fetch(path, request);
    let data = null;
    try { data = await response.json(); } catch (_) { data = null; }
    if (!response.ok) {
      const message = data && data.error ? data.error : `请求失败（HTTP ${response.status}）`;
      const error = new Error(message);
      error.status = response.status;
      throw error;
    }
    return data || {};
  }
  function openModal(title, subtitle, body, options = {}) {
    $("#modalRoot").innerHTML = `
      <div class="modal-backdrop" data-modal-close="backdrop">
        <section class="modal ${options.large ? "large" : ""}" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
          <header class="modal-head">
            <div><h2 id="modalTitle">${esc(title)}</h2><p>${esc(subtitle || "")}</p></div>
            <button class="modal-close" type="button" data-modal-close="button" aria-label="关闭">×</button>
          </header>
          <div class="modal-body">${body}</div>
        </section>
      </div>`;
    document.body.style.overflow = "hidden";
    const first = $("#modalRoot input, #modalRoot select, #modalRoot textarea, #modalRoot button");
    if (first) setTimeout(() => first.focus(), 50);
  }
  function closeModal() {
    $("#modalRoot").innerHTML = "";
    document.body.style.overflow = "";
  }
  function modalError(message) {
    const box = $("#modalError");
    if (box) { box.textContent = message; box.hidden = false; }
  }
  function downloadText(filename, text, mime) {
    const blob = new Blob([text], { type: mime || "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename || "report.txt";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      toast("文案已复制");
    } catch (_) { toast("浏览器未允许复制，请手动选择文本", "warning"); }
  }
  function currentIdentity() { return state.me && state.me.identity ? state.me.identity : {}; }
  function currentUser() { return currentIdentity().user || {}; }
  function isGuest() { return currentIdentity().kind === "guest"; }
  function isAdmin() { return currentUser().role === "admin"; }
  function feature(name) { return !!(state.me && state.me.features && state.me.features[name]); }

  const EXAMPLE = {
    name: "烟台苹果", origin_address: "山东省烟台市栖霞市", organization: "栖霞市示例果业合作社",
    batch_weight_kg: 500, variety: "红富士", spec: "80mm 果径，一级果", unit_price_yuan_per_kg: 8,
    unit_cost_yuan_per_kg: 3, transport: "冷链车", storage: "0–5℃ 冷库，可存 30 天",
    transport_capacity_kg: 1000, daily_capacity_kg: 200, target_market: "西安、成都、企业福利采购",
    notes: "示例数据仅用于演示流程，请以真实批次材料替换。"
  };

  document.addEventListener("click", (event) => {
    const closer = event.target.closest("[data-modal-close]");
    if (closer && (closer.dataset.modalClose === "backdrop" ? event.target === closer : true)) closeModal();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && $("#modalRoot").children.length) closeModal();
  });

  function renderAccount() {
    const area = $("#accountArea");
    if (!state.me) { area.innerHTML = '<span class="loading-pill">会话加载失败</span>'; return; }
    const identity = currentIdentity();
    const user = currentUser();
    $$(".admin-only").forEach((node) => { node.hidden = !isAdmin(); });
    if (identity.kind === "guest") {
      area.innerHTML = `
        <span class="loading-pill" title="临时保存 2 小时">游客 · 临时保存</span>
        <button class="button ghost small" type="button" data-auth="login">登录</button>
        <button class="button primary small" type="button" data-auth="register">注册</button>`;
      return;
    }
    const initial = String(user.username || "用").slice(0, 1);
    area.innerHTML = `
      <div class="account-user"><span class="avatar">${esc(initial)}</span><span class="account-name"><strong>${esc(user.username)}</strong><small>${isAdmin() ? "平台管理员" : "普通用户"}</small></span></div>
      <button class="button ghost small" type="button" data-auth="api">API</button>
      <button class="button ghost small" type="button" data-auth="password">改密</button>
      <button class="button ghost small" type="button" data-auth="logout">退出</button>`;
    if (user.must_change_password) setTimeout(() => openPasswordModal(true), 120);
  }

  function authForm(mode) {
    const isRegister = mode === "register";
    return `
      <form id="authForm" class="form-stack">
        <label class="field"><span>用户名 <b>*</b></span><input name="username" required minlength="3" maxlength="24" autocomplete="username" placeholder="3–24 位中文、字母、数字、下划线或短横线"></label>
        <label class="field"><span>密码 <b>*</b></span><input name="password" type="password" required minlength="8" maxlength="128" autocomplete="${isRegister ? "new-password" : "current-password"}" placeholder="至少 8 位"></label>
        ${isRegister ? '<p class="help">注册后可按账号保存批次；普通用户数据隔离。免费演示服务重启可能丢失记录，请及时导出。</p>' : ""}
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">${isRegister ? "创建账号" : "登录"}</button></div>
      </form>`;
  }
  function openAuth(mode) {
    openModal(mode === "register" ? "注册账号" : "登录", "登录后按账号管理批次和证据，重要记录请导出备份", authForm(mode));
    $("#authForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const button = event.submitter;
      const data = Object.fromEntries(new FormData(event.currentTarget));
      setBusy(button, true, "请稍候…");
      try {
        const result = await api(`/api/auth/${mode}`, { method: "POST", body: data });
        state.me = result.state;
        closeModal();
        renderAccount();
        await loadBatches();
        toast(mode === "register" ? "账号已创建" : "登录成功");
        if (result.user && result.user.must_change_password) openPasswordModal(true);
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }
  function openPasswordModal(forced = false) {
    openModal(forced ? "请先修改密码" : "修改密码", forced ? "首次登录或密码重置后必须修改密码" : "修改后其他会话将需要使用新密码", `
      <form id="passwordForm" class="form-stack">
        <label class="field"><span>当前密码</span><input name="old_password" type="password" required autocomplete="current-password"></label>
        <label class="field"><span>新密码</span><input name="new_password" type="password" required minlength="8" maxlength="128" autocomplete="new-password" placeholder="至少 8 位，不能与旧密码相同"></label>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">稍后</button><button class="button primary" type="submit">确认修改</button></div>
      </form>`);
    $("#passwordForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const button = event.submitter;
      setBusy(button, true);
      try {
        const data = Object.fromEntries(new FormData(event.currentTarget));
        const result = await api("/api/auth/password", { method: "POST", body: data });
        if (state.me) {
          state.me.identity.user = result.user;
          state.me.stats = state.me.stats || {};
        }
        closeModal(); renderAccount(); toast("密码已修改");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }
  async function logout() {
    try {
      await api("/api/auth/logout", { method: "POST", body: {} });
      const result = await api("/api/auth/me");
      state.me = result; state.currentBatch = null; state.batches = [];
      renderAccount(); await loadBatches(); showView("workbench"); toast("已退出登录");
    } catch (error) { toast(error.message, "error"); }
  }
  function openApiConfig() {
    const config = (state.me && state.me.api_config) || {};
    const own = config.own || {};
    const platform = config.platform || {};
    const userApiEnabled = config.user_api_enabled !== false;
    openModal("API 设置", "Agent 模式需要兼容 Chat Completions 的服务", `
      <div class="form-stack">
        <div class="info-box">平台 API：${platform.enabled && platform.configured ? `已启用 · ${esc(platform.model || "")}` : "未启用或未配置"}；我的 API：${own.configured ? `已配置 · ${esc(own.key_masked || "")}` : "未配置"}。密钥只保存加密值，浏览器仅显示掩码。</div>
        <form id="ownApiForm" class="settings-form">
          <label>Base URL<input name="base_url" type="url" value="${esc(own.base_url || "https://api.deepseek.com")}" placeholder="https://api.deepseek.com" ${userApiEnabled ? "" : "disabled"}></label>
          <label>模型名称<input name="model" value="${esc(own.model || "deepseek-chat")}" placeholder="deepseek-chat" ${userApiEnabled ? "" : "disabled"}></label>
          <label>API Key${own.configured ? "（留空保持原值）" : ""}<input name="api_key" type="password" autocomplete="off" placeholder="${own.configured ? "已配置，留空不修改" : "填写服务密钥"}" ${userApiEnabled ? "" : "disabled"}></label>
          ${own.last_test ? `<p class="help">最近测试：${esc(own.last_test.message || own.last_test.status || "")}</p>` : ""}
          <div id="modalError" class="danger-box" hidden></div>
          <div class="modal-actions">
            ${userApiEnabled ? '<button class="button ghost" type="button" id="testOwnApi">测试连接</button><button class="button primary" type="submit">保存我的 API</button>' : '<span class="warning-box">管理员已关闭用户自有 API</span>'}
          </div>
        </form>
      </div>`);
    const form = $("#ownApiForm");
    if (!form) return;
    $("#testOwnApi")?.addEventListener("click", async (event) => {
      const button = event.currentTarget; setBusy(button, true, "测试中…");
      try {
        const result = await api("/api/api-config", { method: "POST", body: { action: "test", source: "own" } });
        toast(result.test?.message || "连接成功");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const button = event.submitter; setBusy(button, true, "保存中…");
      try {
        const body = Object.fromEntries(new FormData(form));
        const result = await api("/api/api-config", { method: "POST", body });
        state.me.api_config = result.config;
        closeModal(); toast("API 设置已保存");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  function setMode(mode) {
    state.mode = mode === "agent" ? "agent" : "web";
    $$("#modeSwitch button").forEach((button) => button.classList.toggle("active", button.dataset.mode === state.mode));
    $("#agentSourceRow").hidden = state.mode !== "agent";
    $("#modeHint").textContent = state.mode === "agent"
      ? "Agent 模式调用兼容 Chat Completions 的 API，用于提取主张、补问和长尾复核；证据门禁仍由本地规则判定。"
      : "联网模式不需要 API，通过公开网页和本地规则完成分析。";
  }
  function fillExample() {
    const form = $("#batchForm");
    Object.entries(EXAMPLE).forEach(([name, value]) => {
      const field = form.elements[name];
      if (field) field.value = value;
    });
    setMode("web");
    toast("已填入示例；这些是模拟数据，请替换为真实材料", "info", 5200);
    form.elements.name.focus();
  }
  function renderPhotoPreview() {
    $("#photoPreview").innerHTML = state.photos.map((photo, index) => `
      <div class="photo-thumb"><img src="${esc(photo.data)}" alt="产品照片 ${index + 1}"><button type="button" data-remove-photo="${index}" aria-label="移除照片">×</button></div>`).join("");
  }
  function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("照片读取失败"));
      reader.readAsDataURL(file);
    });
  }
  async function compressImage(file) {
    const raw = await readFileAsDataUrl(file);
    if (file.size < 650 * 1024) return raw;
    return new Promise((resolve) => {
      const image = new Image();
      image.onload = () => {
        const scale = Math.min(1, 1400 / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", .78));
      };
      image.onerror = () => resolve(raw);
      image.src = raw;
    });
  }
  async function addPhotos(files) {
    for (const file of Array.from(files || [])) {
      if (state.photos.length >= 4) { toast("最多上传 4 张照片", "warning"); break; }
      if (!file.type.startsWith("image/")) continue;
      if (file.size > 8 * 1024 * 1024) { toast(`${file.name} 超过 8MB，已跳过`, "warning"); continue; }
      try { state.photos.push({ data: await compressImage(file), caption: file.name }); }
      catch (error) { toast(error.message, "error"); }
    }
    renderPhotoPreview();
    $("#photoInput").value = "";
  }
  function batchPayload() {
    const form = $("#batchForm");
    const fields = {};
    for (const name of ["name", "origin_address", "organization", "variety", "spec", "transport", "storage", "harvest_date", "package_date", "target_market", "notes"]) {
      fields[name] = String(form.elements[name].value || "").trim();
    }
    for (const name of ["batch_weight_kg", "unit_price_yuan_per_kg", "unit_cost_yuan_per_kg", "transport_capacity_kg", "daily_capacity_kg"]) {
      const value = form.elements[name].value;
      fields[name] = value === "" ? null : Number(value);
    }
    return { product: fields, mode: state.mode, photos: state.photos };
  }
  async function saveBatch(analyze, button) {
    const form = $("#batchForm");
    if (!form.reportValidity()) return;
    if (state.busy) return;
    state.busy = true; setBusy(button, true, analyze ? "正在生成方案…" : "正在保存…");
    try {
      const created = await api("/api/batches", { method: "POST", body: batchPayload() });
      state.currentBatch = created.batch;
      const batchId = created.batch.id;
      await loadBatches();
      if (analyze) {
        const mode = created.batch.mode || state.mode;
        const result = await api(`/api/batches/${encodeURIComponent(batchId)}/analyze`, {
          method: "POST", body: { mode, api_source: $("#apiSourceSelect").value || "auto" }
        });
        state.currentBatch = result.batch;
        showView("report");
        renderReport(result.batch);
        toast(result.notice || "分析完成");
      } else {
        showView("batch");
        await loadBatch(batchId);
        toast(created.guest ? "档案已临时保存 2 小时" : "批次档案已保存", "info");
      }
      state.photos = []; renderPhotoPreview();
    } catch (error) {
      toast(error.message, "error", 7000);
      if (state.currentBatch) { showView("batch"); await loadBatch(state.currentBatch.id); }
    } finally { state.busy = false; setBusy(button, false); }
  }
  async function loadBatches() {
    try {
      const result = await api("/api/batches");
      state.batches = result.batches || [];
      renderRecentBatches();
      if (state.me) state.me.stats = result.stats || state.me.stats;
    } catch (error) {
      $("#recentBatches").innerHTML = emptyState(error.message);
    }
  }
  function renderRecentBatches() {
    const root = $("#recentBatches");
    if (!state.batches.length) {
      root.innerHTML = emptyState("还没有批次。填入最少信息，先跑通一次烟台苹果示例。");
      return;
    }
    root.innerHTML = state.batches.slice(0, 6).map((batch) => `
      <article class="recent-batch" data-open-batch="${esc(batch.id)}" tabindex="0" role="button">
        <div class="recent-batch-top"><strong>${esc(batch.product_name || "未命名产品")}</strong>${statusPill(batch.status)}</div>
        <p>${esc(batch.organization || "")} · ${esc(batch.origin || "")}</p>
        <div class="recent-batch-meta"><span>${number(batch.weight_kg)} kg</span><span>证据 ${number(batch.evidence_verified, 0)}/${number(batch.evidence_total, 0)}</span><span>${esc(batch.best_plan || "尚未测算")}</span></div>
        <div class="recent-batch-foot"><span>${esc(batch.batch_code || batch.id)}</span><span>查看 →</span></div>
      </article>`).join("");
  }

  async function showView(view) {
    if (view === "admin" && !isAdmin()) { toast("仅管理员可进入管理中心", "error"); return; }
    if ((view === "batch" || view === "report") && !state.currentBatch) {
      if (!state.batches.length) { toast("请先创建一个批次", "warning"); return; }
      await loadBatch(state.batches[0].id, view); return;
    }
    state.currentView = view;
    $$(".view").forEach((node) => { node.hidden = node.id !== `view-${view}`; });
    $$(".nav-item").forEach((button) => button.classList.toggle("active", button.dataset.view === view));
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (view === "report" && state.currentBatch) renderReport(state.currentBatch);
    if (view === "admin") await loadAdmin();
  }
  async function loadBatch(id, targetView) {
    try {
      const result = await api(`/api/batches/${encodeURIComponent(id)}`);
      state.currentBatch = result.batch; state.currentDetail = result;
      const wantReport = targetView === "report" || ((result.batch.plans || []).length && !targetView);
      state.currentView = wantReport ? "report" : "batch";
      $$(".view").forEach((node) => { node.hidden = node.id !== `view-${state.currentView}`; });
      $$(".nav-item").forEach((button) => button.classList.toggle("active", button.dataset.view === state.currentView));
      if (wantReport) renderReport(result.batch); else renderBatch(result);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (error) { toast(error.message, "error"); }
  }
  function typeOptions(types, selected) {
    return Object.entries(types || {}).map(([key, item]) => `<option value="${esc(key)}" ${key === selected ? "selected" : ""}>${esc(item.label || key)}</option>`).join("");
  }
  function levelOptions(levels, selected) {
    return (levels || []).map((level) => `<option value="${esc(level)}" ${level === selected ? "selected" : ""}>${esc(level)}</option>`).join("");
  }
  function detailItem(label, value) {
    return `<div class="detail-item"><dt>${esc(label)}</dt><dd>${esc(value || "未填写")}</dd></div>`;
  }

  function evidenceCard(evidence) {
    const url = safeUrl(evidence.source_url);
    const attachment = safeUrl(evidence.attachment?.url || evidence.snapshot?.url || "");
    const hash = (evidence.snapshot && evidence.snapshot.sha256) || (evidence.attachment && evidence.attachment.sha256) || "";
    const status = evidence.status || "pending";
    return `
      <article class="evidence-card ${esc(status)}">
        <div class="evidence-head"><div><strong>${esc(evidence.label || evidence.type)}</strong><small>${esc(evidence.source_level || "未分级")} · ${esc(evidence.source_name || "未填写来源")}</small></div><span class="status-tag ${esc(status)}">${esc(EVIDENCE_STATUS[status] || status)}</span></div>
        <div class="evidence-body">
          <p>${esc((evidence.excerpt || evidence.detail || "暂无材料摘要").slice(0, 420))}</p>
          <div class="evidence-meta"><span>发布：${esc(evidence.published_at || "未填")}</span><span>抓取：${esc(dateText(evidence.fetched_at))}</span><span>有效期：${esc(evidence.expires_at || "未填")}</span><span>批次匹配：${evidence.matches_batch ? "是" : "待确认"}</span></div>
          ${url ? `<div class="evidence-meta"><a href="${esc(url)}" target="_blank" rel="noopener noreferrer">打开来源</a></div>` : ""}
          ${attachment ? `<div class="evidence-meta"><a href="${esc(attachment)}" target="_blank" rel="noopener noreferrer">查看附件</a></div>` : ""}
          ${hash ? `<div class="evidence-meta"><span class="hash">SHA-256 ${esc(hash)}</span></div>` : ""}
          ${evidence.verification_note ? `<p class="help">${esc(evidence.verification_note)}${evidence.verified_by ? ` · ${esc(evidence.verified_by)} ${esc(dateText(evidence.verified_at))}` : ""}</p>` : ""}
          <div class="evidence-actions">
            <button class="button small primary" type="button" data-verify="${esc(evidence.id)}" data-decision="verified">核验通过</button>
            <button class="button small ghost" type="button" data-verify="${esc(evidence.id)}" data-decision="conflict">标记冲突</button>
            <button class="button small ghost" type="button" data-verify="${esc(evidence.id)}" data-decision="rejected">驳回</button>
            ${evidence.origin !== "batch_form" ? `<button class="button small ghost" type="button" data-remove-evidence="${esc(evidence.id)}">移除</button>` : ""}
          </div>
        </div>
      </article>`;
  }

  function renderBatch(detail) {
    const batch = detail.batch || state.currentBatch;
    state.currentBatch = batch;
    const product = batch.product || {};
    const evidence = batch.evidence || [];
    const followups = detail.followups || [];
    const sources = batch.sources || [];
    const verified = evidence.filter((item) => item.status === "verified").length;
    const gates = batch.gate || {};
    $("#batchHeadingActions").innerHTML = `${modePill(batch.mode)}
      <button class="button ghost small" type="button" data-batch-action="switch-mode">切换模式</button>
      <button class="button primary small" type="button" data-batch-action="analyze">${(batch.plans || []).length ? "按当前模式重跑" : "生成方案"}</button>`;
    $("#batchContent").innerHTML = `
      <div class="batch-banner"><div><h2>${esc(product.name || "未命名批次")}</h2><p>${esc(batch.batch_code || batch.id)} · ${esc(product.organization || "")} · ${number(product.batch_weight_kg)} kg</p></div><div class="button-row">${statusPill(batch.status)}<button class="button ghost small" type="button" data-batch-action="report" ${(batch.plans || []).length ? "" : "disabled"}>查看报告</button></div></div>
      <div class="batch-layout"><div class="batch-main">
        <section class="card panel"><div class="panel-head"><div><h3>本批档案</h3><p>档案是本批事实边界，不等于第三方证书。</p></div><button class="text-button" type="button" data-batch-action="edit-product">修改档案</button></div>
          <dl class="detail-grid">
            ${detailItem("产品名", product.name)}${detailItem("品种 / 规格", [product.variety, product.spec].filter(Boolean).join(" · "))}
            ${detailItem("来源地址", product.origin_address)}${detailItem("提交单位", product.organization)}
            ${detailItem("本批重量", `${number(product.batch_weight_kg)} kg`)}${detailItem("期望售价", money(product.unit_price_yuan_per_kg) + "/kg")}
            ${detailItem("综合成本", money(product.unit_cost_yuan_per_kg) + "/kg")}${detailItem("运输工具", product.transport)}
            ${detailItem("储存条件", product.storage)}${detailItem("采摘 / 包装", [product.harvest_date, product.package_date].filter(Boolean).join(" / "))}
          </dl>
          ${(batch.photos || []).length ? `<div class="photo-preview" style="margin-top:12px">${batch.photos.map((photo) => `<div class="photo-thumb"><img src="${esc(photo.url)}" alt="${esc(photo.caption || "产品照片")}"></div>`).join("")}</div>` : ""}
        </section>
        <section class="card panel"><div class="panel-head"><div><h3>Agent 补问</h3><p>先补最影响证据门禁和渠道测算的信息。</p></div><span class="status-pill">${followups.length} 项待补充</span></div>
          ${followups.length ? `<ol class="followup-list">${followups.map((item, index) => `<li class="followup-item"><span class="num">${index + 1}</span><div><strong>${esc(item.question)}</strong><small>${esc(item.why)}</small></div><button class="button small ghost" type="button" data-followup="${esc(item.field)}" data-type="${esc(item.field)}">去补充</button></li>`).join("")}</ol>` : '<div class="hint-box">当前关键字段和证据类型已齐备，可继续核验证据或生成方案。</div>'}
        </section>
        <section class="card panel"><div class="panel-head"><div><h3>证据清单</h3><p>公开搜索只提供线索；核验必须对应主体、批次和有效期。</p></div><div class="summary-strip"><div class="summary-stat"><span>证据</span><strong>${evidence.length}</strong></div><div class="summary-stat"><span>已核验</span><strong>${verified}</strong></div><div class="summary-stat"><span>事实通过</span><strong>${number(gates.passed, 0)}</strong></div><div class="summary-stat"><span>被拦截</span><strong>${number(gates.blocked, 0)}</strong></div></div></div>
          <div class="button-row" style="margin-bottom:13px"><button class="button primary small" type="button" data-batch-action="add-evidence">手工补证</button><button class="button ghost small" type="button" data-batch-action="extract-url">提取网页</button></div>
          <div class="evidence-list">${evidence.map(evidenceCard).join("")}</div>
        </section>
        <section class="card panel"><div class="panel-head"><div><h3>公开来源线索</h3><p>搜索命中不等于事实通过；选择来源后仍需人工核验。</p></div></div>
          <div class="collection-box"><label class="field"><span>搜索关键词</span><input id="collectQuery" maxlength="200" value="${esc(`${product.name || ""} ${product.origin_address || ""} 产地 标准 价格`)}"></label><div class="button-row"><button class="button primary small" type="button" data-batch-action="collect">联网采集</button><span class="help">联网模式无需 API；结果会保存快照摘要与来源。</span></div></div>
          <div class="source-list">${sources.length ? sources.slice().reverse().map((source) => {
            const sourceUrl = safeUrl(source.url);
            return `<article class="source-item"><div class="source-item-head"><div><strong>${esc(source.title || "未命名来源")}</strong><small>${esc(source.source_level || "")} · 建议类型 ${esc(source.suggested_type || "待选择")}</small></div><button class="button small ghost" type="button" data-source-id="${esc(source.id)}" data-source-type="${esc(source.suggested_type || "ORIGIN_PROOF")}">加入证据</button></div><p>${esc((source.snippet || "").slice(0, 300))}</p>${sourceUrl ? `<a class="source-url" href="${esc(sourceUrl)}" target="_blank" rel="noopener noreferrer">${esc(sourceUrl)}</a>` : ""}</article>`;
          }).join("") : '<div class="empty-state">还没有公开来源。可以联网采集，也可以直接手工补证。</div>'}</div>
        </section>
      </div><aside class="batch-side">
        <section class="card panel"><div class="panel-head"><div><h3>当前分析模式</h3><p>切换后旧结果暂停，需按新模式重新分析。</p></div></div>${modePill(batch.mode)}<p class="help">${batch.mode === "agent" ? "Agent 只做语言与长尾辅助，证据门禁、渠道计算和合规规则仍在本地执行。" : "联网模式完全不调用模型 API，使用公开网页、本地规则和模板。"}</p><button class="button ghost small" type="button" data-batch-action="switch-mode">切换为${batch.mode === "agent" ? "联网模式" : "Agent 模式"}</button></section>
        <section class="card panel"><div class="panel-head"><div><h3>证据缺口</h3><p>缺口会直接阻断相关宣传语句。</p></div></div><div class="gap-list">${(gates.gaps || []).length ? gates.gaps.map((gap) => `<span class="status-tag pending">${esc(gap.label)} (${number(gap.blocked_claims, 0)})</span>`).join("") : '<span class="status-tag pass">暂无汇总缺口</span>'}</div></section>
        <section class="card panel"><div class="panel-head"><div><h3>操作时间线</h3><p>关键行为留痕。</p></div></div><ol class="timeline">${(batch.timeline || []).slice().reverse().slice(0, 12).map((item) => `<li><strong>${esc(item.action)}</strong><small>${esc(dateText(item.at))} · ${esc(item.detail || "")}</small></li>`).join("")}</ol></section>
      </aside></div>`;
  }

  function openEditProduct() {
    const p = (state.currentBatch && state.currentBatch.product) || {};
    openModal("修改本批档案", "保存后请按当前模式重新分析", `
      <form id="editProductForm" class="form-stack"><div class="form-2">
        <label class="field"><span>产品名</span><input name="name" required maxlength="80" value="${esc(p.name || "")}"></label>
        <label class="field"><span>来源地址</span><input name="origin_address" required maxlength="240" value="${esc(p.origin_address || "")}"></label>
        <label class="field"><span>公司或单位</span><input name="organization" required maxlength="120" value="${esc(p.organization || "")}"></label>
        <label class="field"><span>本批重量（kg）</span><input name="batch_weight_kg" type="number" min=".01" step=".01" required value="${esc(p.batch_weight_kg || "")}"></label>
        <label class="field"><span>品种</span><input name="variety" value="${esc(p.variety || "")}"></label>
        <label class="field"><span>等级 / 规格</span><input name="spec" value="${esc(p.spec || "")}"></label>
        <label class="field"><span>期望售价（元/kg）</span><input name="unit_price_yuan_per_kg" type="number" min="0" step=".01" value="${esc(p.unit_price_yuan_per_kg ?? "")}"></label>
        <label class="field"><span>综合成本（元/kg）</span><input name="unit_cost_yuan_per_kg" type="number" min="0" step=".01" value="${esc(p.unit_cost_yuan_per_kg ?? "")}"></label>
        <label class="field"><span>运输工具</span><input name="transport" value="${esc(p.transport || "")}"></label>
        <label class="field"><span>储存条件</span><input name="storage" value="${esc(p.storage || "")}"></label>
        <label class="field"><span>运输能力（kg/次）</span><input name="transport_capacity_kg" type="number" min="0" step=".01" value="${esc(p.transport_capacity_kg ?? "")}"></label>
        <label class="field"><span>日发货能力（kg）</span><input name="daily_capacity_kg" type="number" min="0" step=".01" value="${esc(p.daily_capacity_kg ?? "")}"></label>
      </div><div id="modalError" class="danger-box" hidden></div><div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">保存档案</button></div></form>`);
    $("#editProductForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true);
      try {
        const form = event.currentTarget; const product = {};
        for (const element of form.elements) {
          if (!element.name) continue;
          product[element.name] = element.type === "number" && element.value === "" ? null : (element.type === "number" ? Number(element.value) : element.value.trim());
        }
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}`, { method: "POST", body: { product } });
        closeModal(); state.currentBatch = result.batch;
        await loadBatch(result.batch.id, "batch"); toast("档案已保存，请重新分析");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }
  function openEvidenceModal(prefill = {}) {
    const detail = state.currentDetail || {};
    const types = detail.evidence_types || {};
    const levels = detail.source_levels || ["政府/主管部门", "标准/行业机构", "检测/认证机构", "平台公开数据", "企业/合作社自述", "其他公开来源"];
    openModal("手工补充证据", "材料会保存哈希；提交后仍需人工核验", `
      <form id="evidenceForm" class="form-stack"><div class="form-2">
        <label class="field"><span>证据类型</span><select name="type" required>${typeOptions(types, prefill.type || "ORIGIN_PROOF")}</select></label>
        <label class="field"><span>来源等级</span><select name="source_level">${levelOptions(levels, prefill.source_level || "企业/合作社自述")}</select></label>
        <label class="field"><span>出具单位 / 来源名称</span><input name="source_name" required maxlength="180" value="${esc(prefill.source_name || "")}"></label>
        <label class="field"><span>来源链接</span><input name="source_url" type="url" maxlength="2048" value="${esc(prefill.source_url || "")}" placeholder="https://..."></label>
        <label class="field"><span>发布日期</span><input name="published_at" type="date" value="${esc(prefill.published_at || "")}"></label>
        <label class="field"><span>有效期至</span><input name="expires_at" type="date" value="${esc(prefill.expires_at || "")}"></label>
      </div><label class="field"><span>材料内容摘要</span><textarea name="detail" required maxlength="4000" rows="5" placeholder="写明证书编号、检测结论、适用主体和批次等">${esc(prefill.detail || "")}</textarea></label>
      <label class="checkbox-row"><input name="matches_batch" type="checkbox" ${prefill.matches_batch ? "checked" : ""}> 我已确认该材料对应本批次（仍须人工复核）</label>
      <label class="field"><span>原件附件（JPG / PNG / WebP / PDF，≤4MB）</span><input id="evidenceFile" type="file" accept="image/jpeg,image/png,image/webp,application/pdf"></label>
      <div id="modalError" class="danger-box" hidden></div><div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">保存为待核验证据</button></div></form>`);
    $("#evidenceForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const form = event.currentTarget; const button = event.submitter; setBusy(button, true);
      try {
        const body = {};
        for (const element of form.elements) if (element.name && element.type !== "file" && element.type !== "checkbox") body[element.name] = element.value;
        body.matches_batch = form.elements.matches_batch.checked;
        const file = $("#evidenceFile").files[0];
        if (file) {
          if (file.size > 4 * 1024 * 1024) throw new Error("附件不能超过 4MB");
          body.attachment = await readFileAsDataUrl(file); body.attachment_name = file.name;
        }
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/evidence`, { method: "POST", body });
        closeModal(); state.currentBatch = result.batch;
        await loadBatch(result.batch.id, "batch"); toast("证据已保存，请完成核验");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }
  function planCard(plan) {
    const economics = plan.economics || {};
    const assumptions = plan.assumptions || [];
    return `
      <article class="plan-card ${plan.is_best ? "best" : "alt"}">
        <div class="plan-rank"><span>${plan.is_best ? "最优方案" : "次优方案"} · 第 ${number(plan.rank, 0)} 名</span><strong>${number(plan.score, 1)} 分</strong></div>
        <h3>${esc(plan.channel_name || "未命名渠道")}</h3>
        <p class="plan-buyer">${esc(plan.buyer || "")}</p>
        <div class="plan-number">
          <div><span>预计收入</span><strong>${money(economics.revenue)}</strong></div>
          <div><span>情景利润</span><strong>${money(economics.profit)}</strong></div>
          <div><span>利润率</span><strong>${number(economics.margin, 1)}%</strong></div>
          <div><span>能力匹配</span><strong>${number(plan.capability_match, 0)}%</strong></div>
        </div>
        <ul class="plan-list">
          <li>利润区间 ${money(economics.profit_low)}–${money(economics.profit_high)}</li>
          <li>沟通方式：${esc(plan.communication || "待补充")}</li>
          <li>证据缺口：${(plan.evidence_missing || []).length ? esc(evidenceNames(plan.evidence_missing)) : "当前未见汇总缺口"}</li>
        </ul>
        <details class="plan-details"><summary>展开执行步骤与风险</summary><div>
          <h4>执行步骤</h4><ol class="plan-list">${(plan.execution_steps || []).map((step) => `<li>${esc(step)}</li>`).join("")}</ol>
          <h4>风险与边界</h4><ul class="plan-list">${[...(plan.risk_notes || []), ...assumptions].map((item) => `<li>${esc(item)}</li>`).join("")}</ul>
        </div></details>
      </article>`;
  }

  function claimRow(claim) {
    const passed = claim.gate === "PASS";
    return `<div class="claim-item ${passed ? "pass" : "block"}"><p>${esc(claim.claim || "")}</p><small>${passed ? "已通过证据门禁" : `被拦截：${esc(evidenceNames(claim.missing_evidence) || "证据不足")}`}</small></div>`;
  }

  function hitRow(hit) {
    return `<details class="hit"><summary><strong>[${esc(LEVEL_LABELS[hit.severity] || hit.severity || "提示")}] ${esc(hit.rule_name || "合规风险")}</strong> · “${esc(hit.matched || "")}”</summary><p>${esc(hit.advice || hit.why || "请调整该表述。")}</p><small>依据：${esc(hit.basis || "本地规则")}${hit.evidence_note ? ` · ${esc(hit.evidence_note)}` : ""}</small></details>`;
  }

  function complianceBlock(batch) {
    const review = batch.compliance || {};
    const level = review.level || "pass";
    const override = review.manual_override;
    return `
      <section class="compliance-card ${esc(level)}">
        <div class="compliance-head"><div><h3>合规审查 · ${esc(review.level_text || LEVEL_LABELS[level] || "待审查")}</h3><p>本地规则版本 ${esc(review.ruleset_version || "未记录")}，评分 ${number(review.score, 0)} / 100</p></div><span class="status-tag ${level === "pass" ? "pass" : level === "medium" ? "pending" : "rejected"}">${esc(LEVEL_LABELS[level] || level)}</span></div>
        ${(review.hits || []).length ? `<div class="hit-list">${review.hits.map(hitRow).join("")}</div>` : '<div class="hint-box">本地规则未发现命中项。仍须由发布责任人完成事实与场景复核。</div>'}
        ${review.agent_review ? `<p class="help">Agent 长尾复核：${review.agent_review.ok ? `完成 · ${esc(review.agent_review.model || "")}` : `未完成 · ${esc(review.agent_review.error || "可切换联网模式重试")}`}</p>` : ""}
        ${override ? `<div class="override-note">已由 ${esc(override.by || "")} 于 ${esc(dateText(override.at))} 强制放行。理由：${esc(override.reason || "")}</div>` : ""}
        ${["blocker", "high"].includes(level) && !override && !isGuest() && state.me?.features?.manual_override_enabled ? `<div class="button-row report-gap"><button class="button small ghost" type="button" data-report-action="override">提交复核说明（保持拦截）</button></div>` : ""}
      </section>`;
  }

  function renderReport(batch) {
    if (!batch || !(batch.plans || []).length) {
      $("#reportHeadingActions").innerHTML = "";
      $("#reportContent").innerHTML = emptyState("这个批次还没有生成方案。请先回到批次任务，在补问和证据处理后生成方案。");
      return;
    }
    state.currentBatch = batch;
    const plans = batch.plans || [];
    const selected = plans.find((plan) => plan.id === batch.selected_plan_id) || plans.find((plan) => plan.is_best) || plans[0];
    const alternatives = plans.filter((plan) => plan.is_alternative).slice(0, 2);
    const analysis = batch.channel_analysis || {};
    const gate = batch.gate || {};
    const claims = batch.claims || [];
    const content = batch.content || {};
    const feedback = batch.feedback || {};
    const factGuard = batch.fact_guard || content.fact_guard || {};
    $("#reportHeadingActions").innerHTML = `${modePill(batch.mode)}
      <button class="button ghost small" type="button" data-report-action="back-batch">返回批次任务</button>
      <button class="button ghost small" type="button" data-report-action="rerun">按当前模式重跑</button>
      <button class="button primary small" type="button" data-report-action="export-md" ${feature("export_enabled") ? "" : "disabled"}>导出 Markdown</button>`;
    $("#reportContent").innerHTML = `
      <div class="report-grid">
        <section class="report-banner"><div><p class="eyebrow">批次编号 ${esc(batch.batch_code || batch.id)}</p><h2>${esc((batch.product || {}).name || "未命名产品")} · 全渠道测算</h2><p>先计算 ${plans.length} 条渠道，再自动选出 1 个最优和 2 个次优。金额均为情景测算，不构成销量或收益承诺。</p></div><div class="report-metrics">
          <div class="metric-card"><span>事实通过</span><strong>${number(gate.passed, 0)}</strong><small>被门禁拦截 ${number(gate.blocked, 0)} 条</small></div>
          <div class="metric-card"><span>推荐方案利润</span><strong>${money((selected.economics || {}).profit)}</strong><small>区间 ${money((selected.economics || {}).profit_low)}–${money((selected.economics || {}).profit_high)}</small></div>
          <div class="metric-card"><span>能力匹配</span><strong>${number(selected.capability_match, 0)}%</strong><small>${esc(selected.channel_name || "")}</small></div>
          <div class="metric-card"><span>合规结论</span><strong>${esc(LEVEL_LABELS[(batch.compliance || {}).level] || "待审查")}</strong><small>${number((batch.compliance || {}).score, 0)} 分 · 规则 ${esc((batch.compliance || {}).ruleset_version || "")}</small></div>
        </div></section>

        <section class="card panel"><div class="panel-head"><div><h3>推荐方案</h3><p>${esc(analysis.selection_note || "按净利润、证据完整度、能力匹配与执行复杂度综合排序。")}</p></div><span class="mode-pill">共测算 ${plans.length} 条渠道</span></div>
          <div class="plan-stack">${[selected, ...alternatives].filter(Boolean).map(planCard).join("")}</div>
        </section>

        <section class="card panel"><div class="panel-head"><div><h3>全部渠道明细</h3><p>渠道系数为演示模型假设，非实时市场报价；展示收入、成本、利润区间、证据缺口和能力匹配。</p></div></div>
          <div class="channel-table-wrap"><table class="channel-table"><thead><tr><th>排名 / 渠道</th><th>售价</th><th>收入</th><th>总成本</th><th>情景利润</th><th>利润率</th><th>证据缺口</th><th>能力匹配</th></tr></thead><tbody>
          ${plans.map((plan) => { const eco = plan.economics || {}; const costs = plan.costs || {}; return `<tr class="${plan.is_best ? "best-row" : ""}"><td><strong>${number(plan.rank, 0)}. ${esc(plan.channel_name)}</strong><small>${esc(plan.buyer || "")}</small></td><td>${money(eco.unit_price)}/kg</td><td>${money(eco.revenue)}</td><td>${money(costs.total)}</td><td>${money(eco.profit)}<small>${money(eco.profit_low)}–${money(eco.profit_high)}</small></td><td>${number(eco.margin, 1)}%</td><td>${esc(evidenceNames(plan.evidence_missing) || "无汇总缺口")}</td><td>${number(plan.capability_match, 0)}%</td></tr>`; }).join("")}
          </tbody></table></div>
        </section>

        <section class="card panel"><div class="panel-head"><div><h3>事实门禁</h3><p>只有通过门禁的事实才能进入对外正文；证据不足时会阻断相关主张。</p></div><span class="status-pill">${number(gate.passed, 0)} 条可发布</span></div>
          <div class="gate-grid"><div class="gate-summary"><span>事实通过率</span><strong>${number((gate.summary || {}).pass_rate, 0)}%</strong><p>共检查 ${number((gate.summary || {}).total, 0)} 条主张。缺口会同时影响渠道证据建议。</p></div><div class="claim-list">${claims.length ? claims.map(claimRow).join("") : emptyState("暂无主张记录，请重新分析。")}</div></div>
          ${factGuard.issues && factGuard.issues.length ? `<div class="warning-box report-gap">事实约束发现 ${factGuard.issues.length} 个潜在新增信息，已保留供人工复核。</div>` : ""}
        </section>

        <section class="card panel"><div class="panel-head"><div><h3>传播文案编辑</h3><p>可人工调整。保存后会立即重新执行本地事实门禁与合规审查。</p></div><span class="status-pill">${esc(content.source === "agent" ? content.model || "Agent" : "本地合规模板")}</span></div>
          <form id="contentForm" class="content-editor">
            <label><span>商品详情页 <small>${number((content.detail_page || "").length, 0)} 字</small></span><textarea class="tall" name="detail_page" maxlength="8000" required>${esc(content.detail_page || "")}</textarea></label>
            <label><span>口播稿 <small>${number((content.oral_script || "").length, 0)} 字</small></span><textarea name="oral_script" maxlength="8000" required>${esc(content.oral_script || "")}</textarea></label>
            <label><span>社群图文 <small>${number((content.social_post || "").length, 0)} 字</small></span><textarea name="social_post" maxlength="8000" required>${esc(content.social_post || "")}</textarea></label>
            <div class="button-row"><button class="button primary small" type="submit">保存并重新审查</button><button class="button ghost small" type="button" data-copy-content="detail_page">复制商品页</button><button class="button ghost small" type="button" data-copy-content="oral_script">复制口播</button><button class="button ghost small" type="button" data-copy-content="social_post">复制社群文案</button></div>
          </form>
        </section>

        ${complianceBlock(batch)}

        <section class="card panel"><div class="panel-head"><div><h3>销售结果回填</h3><p>用于复盘推荐是否成立；不会改写本批历史测算。</p></div></div>
          <form id="feedbackForm" class="feedback-grid">
            <label class="field"><span>实际渠道</span><select name="channel_code">${plans.map((plan) => `<option value="${esc(plan.channel_code)}" ${feedback.channel_code === plan.channel_code ? "selected" : ""}>${esc(plan.channel_name)}</option>`).join("")}</select></label>
            <label class="field"><span>售出（kg）</span><input name="sold_kg" type="number" min="0" step=".01" value="${esc(feedback.sold_kg ?? "")}"></label>
            <label class="field"><span>收入（元）</span><input name="revenue_yuan" type="number" min="0" step=".01" value="${esc(feedback.revenue_yuan ?? "")}"></label>
            <label class="field"><span>退货（kg）</span><input name="returns_kg" type="number" min="0" step=".01" value="${esc(feedback.returns_kg ?? "")}"></label>
            <label class="field"><span>利润（元）</span><input name="profit_yuan" type="number" step=".01" value="${esc(feedback.profit_yuan ?? "")}"></label>
            <label class="field span-2"><span>复盘备注</span><textarea name="notes" maxlength="1000" rows="2" placeholder="实际询价、退货原因、履约问题等">${esc(feedback.notes || "")}</textarea></label>
            <div class="feedback-submit"><button class="button primary small" type="submit">保存销售反馈</button></div>
          </form>
        </section>

        <div class="report-footer"><span>${esc(analysis.disclaimer || "平台不承诺销量、成交、最高利润或法律绝对合规。")}</span><div class="button-row"><button class="button ghost small" type="button" data-report-action="export-json" ${feature("export_enabled") ? "" : "disabled"}>导出 JSON</button><button class="button ghost small" type="button" data-report-action="back-batch">检查证据</button></div></div>
      </div>`;
  }

  function openSwitchMode() {
    const batch = state.currentBatch;
    if (!batch) return;
    openModal("切换分析模式", "旧结果会暂停，但档案、证据和人工操作记录会保留", `
      <form id="switchModeForm" class="form-stack">
        <label class="field"><span>选择新分析模式</span><select name="mode"><option value="web" ${batch.mode === "web" ? "selected" : ""}>联网模式 · 不调用模型 API</option><option value="agent" ${batch.mode === "agent" ? "selected" : ""}>Agent 模式 · 调用兼容 API</option></select></label>
        <div class="info-box">Agent 只负责主张提取、补问和长尾复核；事实门禁、渠道计算、本地合规规则始终由确定性引擎执行。</div>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">切换并暂停旧结果</button></div>
      </form>`);
    $("#switchModeForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true);
      try {
        const mode = event.currentTarget.elements.mode.value;
        if (mode === batch.mode) throw new Error("当前已经是该模式");
        const result = await api(`/api/batches/${encodeURIComponent(batch.id)}`, { method: "POST", body: { mode } });
        closeModal(); state.currentBatch = result.batch;
        await loadBatch(batch.id, "batch");
        toast("模式已切换，请按当前模式重新分析", "warning");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  function openVerify(evidenceId, decision) {
    const evidence = (state.currentBatch?.evidence || []).find((item) => item.id === evidenceId);
    if (!evidence) return;
    const labels = { verified: "核验通过", conflict: "标记冲突", rejected: "驳回证据" };
    const required = decision !== "verified";
    openModal(labels[decision] || "证据核验", `${evidence.label || evidence.type} · ${evidence.source_name || "未填写来源"}`, `
      <form id="verifyForm" class="form-stack">
        <div class="info-box">${decision === "verified" ? "通过后，该证据才可支撑相关宣传语句。系统会记录核验人和时间。" : "该结论会阻断依赖此证据的宣传语句，请写明原因。"}</div>
        <label class="field"><span>核验说明 ${required ? "<b>*</b>" : "（可选）"}</span><textarea name="reason" rows="4" maxlength="1000" ${required ? "required minlength=4" : ""} placeholder="${decision === "verified" ? "可写明已核对的主体、批次和有效期" : "至少 4 个字，说明冲突或驳回原因"}"></textarea></label>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button ${decision === "verified" ? "primary" : "ghost"}" type="submit">${esc(labels[decision] || "保存")}</button></div>
      </form>`);
    $("#verifyForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true);
      try {
        const reason = event.currentTarget.elements.reason.value.trim();
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/verify`, { method: "POST", body: { evidence_id: evidenceId, decision, reason } });
        closeModal(); state.currentBatch = result.batch;
        await loadBatch(result.batch.id, "batch"); toast("证据核验结论已留痕");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  function openWebEvidence(sourceId) {
    const source = (state.currentBatch?.sources || []).find((item) => item.id === sourceId);
    if (!source) return;
    const detail = state.currentDetail || {};
    openModal("把公开来源加入证据", "系统会重新读取网页快照并计算哈希，但仍需人工核验主体和批次", `
      <form id="webEvidenceForm" class="form-stack">
        <div class="info-box"><strong>${esc(source.title || "未命名来源")}</strong><br>${esc(source.source_level || "")} · ${esc(source.url || "")}</div>
        <label class="field"><span>这份材料拟证明什么？</span><select name="type" required>${typeOptions(detail.evidence_types || {}, source.suggested_type || "ORIGIN_PROOF")}</select></label>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">读取快照并保存证据</button></div>
      </form>`);
    $("#webEvidenceForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true, "读取网页…");
      try {
        const type = event.currentTarget.elements.type.value;
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/evidence`, { method: "POST", body: { provider: "web", source_id: sourceId, type } });
        closeModal(); state.currentBatch = result.batch;
        await loadBatch(result.batch.id, "batch"); toast(result.notice || "证据已保存，请人工核验", "info", 6200);
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  function openExtract() {
    openModal("提取公开网页", "只接受互联网公开 HTTP(S) 页面，不访问本机或内网地址", `
      <form id="extractForm" class="form-stack">
        <label class="field"><span>网页地址</span><input name="url" type="url" required maxlength="2048" placeholder="https://..."></label>
        <div id="extractResult"></div>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">读取网页正文</button></div>
      </form>`);
    $("#extractForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true, "提取中…");
      try {
        const url = event.currentTarget.elements.url.value.trim();
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/extract`, { method: "POST", body: { url } });
        $("#extractResult").innerHTML = `<div class="info-box"><strong>${esc(result.title || "网页正文")}</strong><p>${esc((result.excerpt || "").slice(0, 700))}</p><small>${esc(result.notice || "")}</small></div><div class="button-row report-gap"><button class="button small primary" type="button" data-add-extracted="${esc(result.url)}" data-suggested-type="${esc(result.suggested_type || "ORIGIN_PROOF")}">加入为待核验证据</button></div>`;
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  async function addExtractedEvidence(url, type, button) {
    setBusy(button, true, "保存快照…");
    try {
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/evidence`, { method: "POST", body: { provider: "web", url, type } });
      closeModal(); state.currentBatch = result.batch;
      await loadBatch(result.batch.id, "batch"); toast("网页快照已保存，请人工核验", "info", 6200);
    } catch (error) { toast(error.message, "error", 7000); }
    finally { setBusy(button, false); }
  }

  async function collectSources(button) {
    const input = $("#collectQuery");
    const query = input ? input.value.trim() : "";
    setBusy(button, true, "联网采集中…");
    try {
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/collect`, { method: "POST", body: { query } });
      state.currentBatch = result.batch;
      await loadBatch(result.batch.id, "batch");
      toast(`${result.notice || "采集完成"} 新增 ${number((result.sources || []).length, 0)} 个来源`, "info", 7000);
      if ((result.errors || []).length) toast(`部分来源读取失败：${result.errors.slice(0, 2).join("；")}`, "warning", 8000);
    } catch (error) { toast(error.message, "error", 9000); }
    finally { setBusy(button, false); }
  }

  async function analyzeCurrent(button) {
    if (!state.currentBatch) return;
    setBusy(button, true, state.currentBatch.mode === "agent" ? "Agent 分析中…" : "正在测算…");
    try {
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/analyze`, {
        method: "POST", body: { mode: state.currentBatch.mode, api_source: $("#apiSourceSelect")?.value || "auto" }
      });
      state.currentBatch = result.batch;
      showView("report"); renderReport(result.batch); toast(result.notice || "分析完成", "success", 6500);
    } catch (error) { toast(error.message, "error", 10000); }
    finally { setBusy(button, false); }
  }

  async function saveContentForm(form, button) {
    setBusy(button, true, "审查中…");
    try {
      const content = Object.fromEntries(new FormData(form));
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/content`, {
        method: "POST", body: { content, mode: state.currentBatch.mode, api_source: $("#apiSourceSelect")?.value || "auto" }
      });
      state.currentBatch = result.batch;
      renderReport(result.batch); toast("文案已保存并重新审查", "success");
      const level = (result.compliance || {}).level;
      if (["blocker", "high"].includes(level)) toast("当前文案仍存在高风险，导出已被阻止", "warning", 6500);
    } catch (error) { toast(error.message, "error", 8500); }
    finally { setBusy(button, false); }
  }

  function openOverride() {
    if (isGuest()) { toast("游客不能强制放行，请先注册或登录", "warning"); return; }
    openModal("提交复核说明", "记录问题与补证计划，仍需整改并通过审查才能导出", `
      <form id="overrideForm" class="form-stack">
        <div class="warning-box">提交复核说明不会解除拦截。请先修改风险文案或补充证据，再重新分析；说明将写入审计记录。</div>
        <label class="field"><span>复核说明与补证计划（至少 10 个字）</span><textarea name="reason" rows="5" maxlength="1000" required minlength="10" placeholder="例如：已与合作社确认本周补交产地证明，先用于内部审稿，不对外发布。"></textarea></label>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button ghost" type="submit">提交说明</button></div>
      </form>`);
    $("#overrideForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true);
      try {
        const reason = event.currentTarget.elements.reason.value.trim();
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/override`, { method: "POST", body: { reason } });
        closeModal(); state.currentBatch = result.batch; renderReport(result.batch); toast(result.notice || "已记录强制放行", "warning", 7000);
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  async function exportCurrent(format, button) {
    setBusy(button, true, "生成文件…");
    try {
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/export`, { method: "POST", body: { format } });
      downloadText(result.filename, result.text, result.mime);
      state.currentBatch = result.batch; renderReport(result.batch); toast("报告已导出并留痕");
    } catch (error) { toast(error.message, "error", 9000); }
    finally { setBusy(button, false); }
  }

  async function saveFeedbackForm(form, button) {
    setBusy(button, true, "保存中…");
    try {
      const raw = Object.fromEntries(new FormData(form));
      const body = { channel_code: raw.channel_code, notes: raw.notes };
      for (const name of ["sold_kg", "revenue_yuan", "returns_kg", "profit_yuan"]) body[name] = raw[name] === "" ? null : Number(raw[name]);
      const allEmpty = ["sold_kg", "revenue_yuan", "returns_kg", "profit_yuan"].every((name) => body[name] === null) && !body.notes;
      if (allEmpty) throw new Error("请至少填写一项真实销售结果或复盘备注");
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/feedback`, { method: "POST", body });
      state.currentBatch = result.batch; renderReport(result.batch); toast(result.notice || "销售反馈已保存", "success", 6500);
    } catch (error) { toast(error.message, "error", 7000); }
    finally { setBusy(button, false); }
  }


  function featureSwitch(key, checked) {
    const label = FEATURE_LABELS[key] || key;
    return `<label class="switch-row"><span>${esc(label)}</span><span class="switch"><input type="checkbox" name="${esc(key)}" ${checked ? "checked" : ""}><i></i></span></label>`;
  }

  function renderAdmin() {
    const root = $("#adminContent");
    const data = state.admin;
    if (!data) {
      root.innerHTML = emptyState("管理中心数据尚未加载。");
      return;
    }
    const users = data.users || [];
    const stats = data.stats || {};
    const batches = data.batches || [];
    const settings = data.settings || {};
    const features = settings.features || {};
    const platform = settings.platform_api || {};
    const sources = settings.data_sources || {};
    const audit = data.audit || {};
    const verification = audit.verification || {};
    const rules = data.rules || {};
    const prompts = data.prompts || [];
    const configuredOrder = sources.search_order || [];
    const knownSources = ["必应 RSS", "必应网页", "搜狗", "360", "DuckDuckGo"];
    const sourceNames = [...configuredOrder.filter((name) => knownSources.includes(name)), ...knownSources.filter((name) => !configuredOrder.includes(name))];
    root.innerHTML = `
      <div class="admin-grid">
        <section class="card panel admin-wide">
          <div class="panel-head"><div><h3>平台概览</h3><p>用户、批次、证据链与当前管理员身份。</p></div><span class="status-pill">${esc((data.acting_admin || {}).username || "")}</span></div>
          <div class="admin-stats">
            <div class="admin-stat"><span>注册用户</span><strong>${number(stats.users, 0)}</strong></div>
            <div class="admin-stat"><span>启用账号</span><strong>${number(stats.active_users, 0)}</strong></div>
            <div class="admin-stat"><span>批次总数</span><strong>${number(stats.batches, 0)}</strong></div>
            <div class="admin-stat"><span>审计记录</span><strong>${number(verification.total, 0)}</strong></div>
          </div>
        </section>

        <section class="card panel admin-wide">
          <div class="panel-head"><div><h3>用户与权限</h3><p>管理员可停用账号、调整角色或重置密码；当前管理员不能停用或降级自己。</p></div><span class="status-pill">${users.length} 个账号</span></div>
          <div class="table-wrap"><table class="data-table"><thead><tr><th>用户</th><th>角色</th><th>状态</th><th>最近登录</th><th>密码状态</th><th>操作</th></tr></thead><tbody>
          ${users.map((user) => `<tr><td><strong>${esc(user.username)}</strong><small>${esc(user.id)}</small></td><td>${user.role === "admin" ? "管理员" : "普通用户"}</td><td>${user.active ? '<span class="status-tag pass">启用</span>' : '<span class="status-tag rejected">停用</span>'}</td><td>${esc(dateText(user.last_login_at))}</td><td>${user.must_change_password ? "首次登录须改密" : "正常"}</td><td><div class="user-actions"><button class="button small ghost" type="button" data-admin-user="${esc(user.id)}" data-admin-action="toggle-active" data-active="${user.active ? "true" : "false"}">${user.active ? "停用" : "启用"}</button><button class="button small ghost" type="button" data-admin-user="${esc(user.id)}" data-admin-action="toggle-role" data-role="${esc(user.role)}">${user.role === "admin" ? "设为用户" : "设为管理员"}</button><button class="button small ghost" type="button" data-admin-user="${esc(user.id)}" data-admin-action="reset-password">重置密码</button><button class="button small ghost" type="button" data-admin-user="${esc(user.id)}" data-admin-action="must-change" data-change="${user.must_change_password ? "false" : "true"}">${user.must_change_password ? "取消改密要求" : "要求改密"}</button></div></td></tr>`).join("")}
          </tbody></table></div>
        </section>

        <section class="card panel admin-wide">
          <div class="panel-head"><div><h3>全部批次</h3><p>只读查看产品档案、证据状态、核验结果和审计记录，不代替用户操作。</p></div><span class="status-pill">${batches.length} 个批次</span></div>
          <div class="table-wrap"><table class="data-table"><thead><tr><th>批次 / 产品</th><th>所有者</th><th>来源</th><th>状态</th><th>证据</th><th>门禁</th><th>合规</th><th>最优渠道</th><th>操作</th></tr></thead><tbody>
          ${batches.length ? batches.map((batch) => `<tr><td><strong>${esc(batch.product_name || "未命名")}</strong><small>${esc(batch.batch_code || batch.id)}</small></td><td>${esc(batch.owner_username || "游客")}</td><td>${esc(batch.origin || "")}</td><td>${statusPill(batch.status)}</td><td>${number(batch.evidence_verified, 0)} / ${number(batch.evidence_total, 0)} 已核验</td><td>${number(batch.claims_passed, 0)} 通过 · ${number(batch.claims_blocked, 0)} 拦截</td><td>${esc(LEVEL_LABELS[batch.compliance_level] || batch.compliance_level || "待审查")}</td><td>${esc(batch.best_plan || "尚未测算")}</td><td><button class="button small ghost" type="button" data-admin-batch="${esc(batch.id)}">只读查看</button></td></tr>`).join("") : `<tr><td colspan="9">${emptyState("暂无批次")}</td></tr>`}
          </tbody></table></div>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>平台功能开关</h3><p>关闭后立即影响游客、注册、采集、导出与 API 可用性。</p></div></div>
          <form id="adminFeatureForm" class="settings-form">
            <div class="switch-grid">${Object.keys(FEATURE_LABELS).map((key) => featureSwitch(key, !!features[key])).join("")}</div>
            <div class="button-row"><button class="button primary small" type="submit">保存功能开关</button></div>
          </form>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>平台 Agent API</h3><p>仅支持 HTTPS 兼容 Chat Completions 服务；密钥加密保存，界面只显示掩码。</p></div><span class="status-pill">${platform.configured ? "已配置" : "未配置"}</span></div>
          <form id="adminApiForm" class="settings-form">
            <label>Base URL<input name="base_url" type="url" value="${esc(platform.base_url || "https://api.deepseek.com")}" required></label>
            <label>模型名称<input name="model" value="${esc(platform.model || "deepseek-chat")}" required></label>
            <label>API Key（留空保持原值）<input name="api_key" type="password" autocomplete="off" placeholder="${esc(platform.key_masked || "填写服务密钥")}"></label>
            <label class="checkbox-row"><input name="enabled" type="checkbox" ${platform.enabled ? "checked" : ""}> 启用平台 API</label>
            <label class="checkbox-row"><input name="clear_key" type="checkbox"> 清除已保存密钥</label>
            <p class="help">最近测试：${esc((platform.last_test || {}).message || "尚未测试")}</p>
            <div class="button-row"><button class="button ghost small" type="button" id="adminTestApi">测试已保存配置</button><button class="button primary small" type="submit">保存平台 API</button></div>
          </form>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>联网数据源</h3><p>联网模式不调用模型 API；勾选允许使用的公开搜索源，并保持固定顺序。</p></div></div>
          <form id="adminSourceForm" class="settings-form">
            <div class="source-order">${sourceNames.map((name) => `<label><input type="checkbox" name="search_order" value="${esc(name)}" ${configuredOrder.includes(name) ? "checked" : ""}> ${esc(name)}</label>`).join("")}</div>
            <label>单次最多读取网页数<input name="max_pages_per_collect" type="number" min="1" max="5" step="1" value="${esc(sources.max_pages_per_collect || 3)}" required></label>
            <div class="button-row"><button class="button primary small" type="submit">保存数据源设置</button></div>
          </form>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>审计链完整性</h3><p>校验现存记录的哈希与前后关联。完整性校验不等同于权威认证，仍需备份与外部存证。</p></div><span class="status-tag ${verification.ok ? "pass" : "rejected"}">${verification.ok ? "链完整" : "需要检查"}</span></div>
          <p class="help">共 ${number(verification.total, 0)} 条记录；异常 ${number((verification.broken || []).length, 0)} 条。最后哈希：<span class="hash">${esc(verification.last_hash || "无")}</span></p>
          <div class="button-row"><button class="button ghost small" type="button" id="verifyAudit">重新校验审计链</button></div>
          <div class="audit-list report-gap">${(audit.entries || []).slice(0, 30).map((entry) => `<div class="audit-row"><span>${esc(dateText(entry.at))}</span><strong>${esc(entry.action)} · ${esc(entry.actor_username || "")}</strong><code>${esc(entry.resource_type || "")}:${esc(entry.resource_id || "")} ${esc(JSON.stringify(entry.detail || {}).slice(0, 150))}</code></div>`).join("") || emptyState("暂无审计记录")}</div>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>合规规则版本</h3><p>当前规则集 ${esc(rules.version || "未加载")}，共 ${number((rules.rules || []).length, 0)} 条。</p></div></div>
          <div class="rule-grid">${(rules.rules || []).map((rule) => `<div class="rule-chip"><strong>${esc(rule.id)} · ${esc(rule.name)}</strong><span>${esc(rule.severity)} · ${esc(rule.basis || "")}</span></div>`).join("") || emptyState("暂无规则")}</div>
          <p class="help report-gap">来源：${esc((rules.sources || []).join("；") || "未记录")}</p>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>提示词版本</h3><p>关键提示词可追溯，展示当前版本和历史变更。</p></div><span class="status-pill">${prompts.length} 组</span></div>
          ${prompts.length ? prompts.map((prompt) => `<details class="hit"><summary><strong>${esc(prompt.name || prompt.id)}</strong> · 当前 ${esc(prompt.current || "未标版本")}</summary>${(prompt.versions || []).map((item) => `<p><strong>${esc(item.version)}</strong> · ${esc(item.changelog || "无变更说明")}${item.retired ? " · 已退役" : " · 当前"}</p>`).join("")}<small>${esc(prompt.versions?.length || 0)} 个版本已留档</small></details>`).join("") : emptyState("暂无提示词记录")}
        </section>
      </div>`;
  }

  async function loadAdmin() {
    if (!isAdmin()) {
      $("#adminContent").innerHTML = emptyState("仅管理员可访问管理中心。");
      return;
    }
    $("#adminContent").innerHTML = '<div class="loading-block">正在读取用户、批次、规则和审计链…</div>';
    try {
      const [users, batches, settings, audit, rules, prompts] = await Promise.all([
        api("/api/admin/users"),
        api("/api/admin/batches"),
        api("/api/admin/settings"),
        api("/api/admin/audit?limit=200"),
        api("/api/admin/rules"),
        api("/api/admin/prompts")
      ]);
      state.admin = {
        users: users.users || [], stats: users.stats || {}, acting_admin: users.acting_admin || {},
        batches: batches.batches || [], settings: settings.settings || {},
        audit, rules, prompts: prompts.prompts || []
      };
      renderAdmin();
    } catch (error) {
      $("#adminContent").innerHTML = emptyState(`管理中心加载失败：${error.message}`);
      toast(error.message, "error", 7000);
    }
  }

  async function updateAdminUser(userId, action, trigger) {
    let patch = null;
    if (action === "toggle-active") patch = { active: trigger.dataset.active !== "true" };
    if (action === "toggle-role") patch = { role: trigger.dataset.role === "admin" ? "user" : "admin" };
    if (action === "must-change") patch = { must_change_password: trigger.dataset.change === "true" };
    if (!patch) return;
    if (action === "toggle-role" && !window.confirm("确认调整该用户的平台角色？角色变化会立即生效。")) return;
    setBusy(trigger, true);
    try {
      await api(`/api/admin/users/${encodeURIComponent(userId)}`, { method: "POST", body: patch });
      await loadAdmin();
      toast("账号权限已更新");
    } catch (error) {
      toast(error.message, "error", 7000);
    } finally {
      setBusy(trigger, false);
    }
  }

  function openResetPassword(userId) {
    const user = (state.admin?.users || []).find((item) => item.id === userId);
    openModal("重置用户密码", user ? `${user.username} · ${user.id}` : userId, `
      <form id="resetPasswordForm" class="form-stack">
        <div class="warning-box">重置后旧密码立即失效，该用户下次登录必须修改密码。新密码至少 8 位，并同时包含字母和数字。</div>
        <label class="field"><span>新密码</span><input name="new_password" type="password" minlength="8" maxlength="128" required autocomplete="new-password"></label>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">确认重置</button></div>
      </form>`);
    $("#resetPasswordForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true, "重置中…");
      try {
        const result = await api(`/api/admin/users/${encodeURIComponent(userId)}/reset-password`, {
          method: "POST", body: { new_password: event.currentTarget.elements.new_password.value }
        });
        closeModal(); toast(result.notice || "密码已重置", "warning", 6500); await loadAdmin();
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  async function openAdminBatch(batchId) {
    try {
      const result = await api(`/api/admin/batch/${encodeURIComponent(batchId)}`);
      const batch = result.batch || {};
      const product = batch.product || {};
      const evidence = batch.evidence || [];
      const claims = batch.claims || [];
      const audit = result.audit || [];
      openModal("批次只读审查", `${batch.batch_code || batch.id} · 管理员不能代替所有者修改、核验或放行`, `
        <div class="form-stack">
          <div class="warning-box">以下内容仅供管理员查看证据来源与核验结果。任何修改、证据核验和强制放行都必须由批次所有者完成并留痕。</div>
          <dl class="detail-grid">
            ${detailItem("产品", product.name)}${detailItem("所有者", batch.owner_username)}
            ${detailItem("来源地址", product.origin_address)}${detailItem("提交单位", product.organization)}
            ${detailItem("本批重量", `${number(product.batch_weight_kg)} kg`)}${detailItem("分析模式", batch.mode === "agent" ? "Agent 模式" : "联网模式")}
            ${detailItem("事实门禁", `${number((batch.gate || {}).passed, 0)} 通过 / ${number((batch.gate || {}).blocked, 0)} 拦截`)}${detailItem("合规结论", LEVEL_LABELS[(batch.compliance || {}).level] || (batch.compliance || {}).level || "待审查")}
          </dl>
          <section><h3>证据与核验结果</h3><div class="evidence-list report-gap">${evidence.length ? evidence.map((item) => {
            const sourceUrl = safeUrl(item.source_url);
            const attachment = safeUrl(item.attachment?.url || item.snapshot?.url || "");
            const hash = item.snapshot?.sha256 || item.attachment?.sha256 || "";
            return `<article class="evidence-card ${esc(item.status || "pending")}"><div class="evidence-head"><div><strong>${esc(item.label || item.type)}</strong><small>${esc(item.source_level || "")} · ${esc(item.source_name || "")}</small></div><span class="status-tag ${esc(item.status || "pending")}">${esc(EVIDENCE_STATUS[item.status] || item.status || "待核验")}</span></div><div class="evidence-body"><p>${esc((item.excerpt || item.detail || "暂无摘要").slice(0, 500))}</p><div class="evidence-meta"><span>发布：${esc(item.published_at || "未填")}</span><span>抓取：${esc(dateText(item.fetched_at))}</span><span>有效期：${esc(item.expires_at || "未填")}</span><span>批次匹配：${item.matches_batch ? "是" : "待确认"}</span></div>${item.verification_note ? `<p class="help">核验说明：${esc(item.verification_note)} · ${esc(item.verified_by || "")} ${esc(dateText(item.verified_at))}</p>` : ""}${sourceUrl ? `<a class="source-url" href="${esc(sourceUrl)}" target="_blank" rel="noopener noreferrer">${esc(sourceUrl)}</a>` : ""}${attachment ? `<a class="source-url" href="${esc(attachment)}" target="_blank" rel="noopener noreferrer">查看原始附件</a>` : ""}${hash ? `<span class="hash">SHA-256 ${esc(hash)}</span>` : ""}</div></article>`;
          }).join("") : emptyState("暂无证据")}</div></section>
          <section><h3>事实门禁结果</h3><div class="claim-list report-gap">${claims.length ? claims.map(claimRow).join("") : emptyState("尚无主张记录")}</div></section>
          <section><h3>批次审计记录</h3><div>${audit.length ? audit.map((entry) => `<div class="audit-row"><span>${esc(dateText(entry.at))}</span><strong>${esc(entry.action)} · ${esc(entry.actor_username || "")}</strong><code>${esc(JSON.stringify(entry.detail || {}).slice(0, 180))}</code></div>`).join("") : emptyState("暂无批次审计记录")}</div></section>
          <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">关闭</button></div>
        </div>`, { large: true });
    } catch (error) { toast(error.message, "error", 7000); }
  }

  async function saveAdminSettings(body, button, message) {
    setBusy(button, true, "保存中…");
    try {
      const result = await api("/api/admin/settings", { method: "POST", body });
      state.admin.settings = result.settings || state.admin.settings;
      if (state.admin.settings?.features) state.me.features = state.admin.settings.features;
      renderAdmin();
      toast(message || "平台设置已保存");
    } catch (error) {
      toast(error.message, "error", 8000);
    } finally {
      setBusy(button, false);
    }
  }

  async function adminFeaturesSubmit(form, button) {
    const features = Object.fromEntries(Object.keys(FEATURE_LABELS).map((key) => [key, false]));
    for (const key of Object.keys(FEATURE_LABELS)) features[key] = !!form.elements[key]?.checked;
    await saveAdminSettings({ features }, button, "功能开关已保存");
  }

  async function adminApiSubmit(form, button) {
    const values = Object.fromEntries(new FormData(form));
    const body = {
      base_url: values.base_url, model: values.model, enabled: form.elements.enabled.checked,
      clear_key: form.elements.clear_key.checked, api_key: String(values.api_key || "")
    };
    await saveAdminSettings({ platform_api: body }, button, "平台 API 设置已保存");
  }

  async function adminSourcesSubmit(form, button) {
    const order = new FormData(form).getAll("search_order").filter((name) => ["必应 RSS", "必应网页", "搜狗", "360", "DuckDuckGo"].includes(name));
    if (!order.length) { toast("至少保留一个联网搜索源", "warning"); return; }
    const value = Number(form.elements.max_pages_per_collect.value);
    if (!Number.isInteger(value) || value < 1 || value > 5) { toast("单次采集页数须为 1–5 的整数", "warning"); return; }
    await saveAdminSettings({ data_sources: { search_order: order, max_pages_per_collect: value } }, button, "数据源设置已保存");
  }

  async function testAdminApi(button) {
    setBusy(button, true, "测试中…");
    try {
      const result = await api("/api/admin/settings", { method: "POST", body: { action: "test_api" } });
      if (state.admin) state.admin.settings = result.settings || state.admin.settings;
      renderAdmin();
      toast(result.test?.message || "平台 API 连接成功");
    } catch (error) {
      toast(error.message, "error", 9000);
    } finally {
      setBusy(button, false);
    }
  }

  document.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;

    const viewButton = target.closest("[data-view]");
    if (viewButton) { void showView(viewButton.dataset.view); return; }

    const authButton = target.closest("[data-auth]");
    if (authButton) {
      const action = authButton.dataset.auth;
      if (action === "login" || action === "register") openAuth(action);
      else if (action === "password") openPasswordModal(false);
      else if (action === "api") openApiConfig();
      else if (action === "logout") void logout();
      return;
    }

    const modeButton = target.closest("[data-mode]");
    if (modeButton) { setMode(modeButton.dataset.mode); return; }

    const removePhoto = target.closest("[data-remove-photo]");
    if (removePhoto) {
      state.photos.splice(Number(removePhoto.dataset.removePhoto), 1);
      renderPhotoPreview();
      return;
    }

    const recent = target.closest("[data-open-batch]");
    if (recent) { void loadBatch(recent.dataset.openBatch); return; }

    const followup = target.closest("[data-followup]");
    if (followup) {
      const field = followup.dataset.followup;
      if (["unit_price_yuan_per_kg", "unit_cost_yuan_per_kg", "transport", "storage"].includes(field)) {
        openEditProduct();
        setTimeout(() => $(`#editProductForm [name="${field}"]`)?.focus(), 80);
      } else {
        openEvidenceModal({ type: field });
      }
      return;
    }

    const verify = target.closest("[data-verify]");
    if (verify) { openVerify(verify.dataset.verify, verify.dataset.decision); return; }

    const removeEvidence = target.closest("[data-remove-evidence]");
    if (removeEvidence) {
      const button = removeEvidence;
      if (!window.confirm("确认移除这条证据？核验结论和关联事实将重新计算。")) return;
      setBusy(button, true);
      (async () => {
        try {
          const batchId = state.currentBatch.id;
          await api(`/api/batches/${encodeURIComponent(batchId)}/evidence/remove`, {
            method: "POST", body: { evidence_id: button.dataset.removeEvidence }
          });
          await loadBatch(batchId, "batch"); toast("证据已移除并重新计算门禁");
        } catch (error) { toast(error.message, "error", 7000); }
        finally { setBusy(button, false); }
      })();
      return;
    }

    const sourceButton = target.closest("[data-source-id]");
    if (sourceButton) {
      const source = (state.currentBatch?.sources || []).find((item) => item.id === sourceButton.dataset.sourceId);
      if (!source) { toast("来源记录不存在，请刷新批次", "warning"); return; }
      openEvidenceModal({
        type: source.suggested_type || sourceButton.dataset.sourceType || "ORIGIN_PROOF",
        source_level: source.source_level || "公开网页",
        source_name: source.title || "公开来源",
        source_url: source.url || "",
        detail: source.snippet || source.title || "",
        published_at: source.published_at || "",
        fetched_at: source.fetched_at || ""
      });
      return;
    }

    const batchAction = target.closest("[data-batch-action]");
    if (batchAction) {
      const action = batchAction.dataset.batchAction;
      if (action === "edit-product") openEditProduct();
      else if (action === "add-evidence") openEvidenceModal();
      else if (action === "extract-url") openExtract();
      else if (action === "collect") void collectSources(batchAction);
      else if (action === "switch-mode") openSwitchMode();
      else if (action === "analyze" || action === "rerun") void analyzeCurrent(batchAction);
      else if (action === "report" && state.currentBatch) { void showView("report"); }
      return;
    }

    const reportAction = target.closest("[data-report-action]");
    if (reportAction && state.currentBatch) {
      const action = reportAction.dataset.reportAction;
      if (action === "back-batch") void loadBatch(state.currentBatch.id, "batch");
      else if (action === "rerun") void analyzeCurrent(reportAction);
      else if (action === "override") openOverride();
      else if (action === "export-md") void exportCurrent("markdown", reportAction);
      else if (action === "export-json") void exportCurrent("json", reportAction);
      return;
    }

    const copyButton = target.closest("[data-copy-content]");
    if (copyButton) {
      const field = copyButton.dataset.copyContent;
      const fieldNode = $(`#contentForm [name="${field}"]`);
      const review = state.currentBatch?.compliance || {};
      if (!review.level || review.blocked || state.currentBatch?.mode_switch_pending) { toast("当前文案尚未通过审查，请整改并保存后再复制", "warning"); return; }
      const hasEdits = ["detail_page", "oral_script", "social_post"].some((key) => document.querySelector('[name="' + key + '"]')?.value !== state.currentBatch?.content?.[key]);
      if (hasEdits) { toast("文案已修改，请先保存并重新审查", "warning"); return; }
      if (fieldNode) void copyText(fieldNode.value);
      return;
    }

    const adminUser = target.closest("[data-admin-user]");
    if (adminUser) {
      const action = adminUser.dataset.adminAction;
      if (action === "reset-password") openResetPassword(adminUser.dataset.adminUser);
      else void updateAdminUser(adminUser.dataset.adminUser, action, adminUser);
      return;
    }

    const adminBatch = target.closest("[data-admin-batch]");
    if (adminBatch) { void openAdminBatch(adminBatch.dataset.adminBatch); return; }
  });

  document.addEventListener("submit", (event) => {
    const form = event.target;
    if (form.id === "batchForm") {
      event.preventDefault();
      void saveBatch(false, event.submitter || $("#saveDraft"));
    } else if (form.id === "contentForm") {
      event.preventDefault();
      void saveContentForm(form, event.submitter);
    } else if (form.id === "feedbackForm") {
      event.preventDefault();
      void saveFeedbackForm(form, event.submitter);
    } else if (form.id === "adminFeatureForm") {
      event.preventDefault();
      void adminFeaturesSubmit(form, event.submitter);
    } else if (form.id === "adminApiForm") {
      event.preventDefault();
      void adminApiSubmit(form, event.submitter);
    } else if (form.id === "adminSourceForm") {
      event.preventDefault();
      void adminSourcesSubmit(form, event.submitter);
    }
  });

  document.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    if (target.closest("#exampleFill") || target.closest("#exampleFillSide")) { fillExample(); return; }
    if (target.closest("#saveAnalyze")) { void saveBatch(true, target.closest("#saveAnalyze")); return; }
    if (target.closest("#openApiConfig")) { openApiConfig(); return; }
    if (target.closest("#refreshBatches")) { void loadBatches(); return; }
    if (target.closest("#adminRefresh")) { void loadAdmin(); return; }
    if (target.closest("#adminTestApi")) { void testAdminApi(target.closest("#adminTestApi")); return; }
    if (target.closest("#verifyAudit")) {
      const button = target.closest("#verifyAudit");
      setBusy(button, true, "校验中…");
      (async () => {
        try {
          const result = await api("/api/admin/audit/verify");
          if (state.admin?.audit) state.admin.audit.verification = result;
          renderAdmin();
          toast(result.ok ? `审计链完整，共 ${number(result.total, 0)} 条记录` : "审计链发现异常，请立即检查", result.ok ? "success" : "error", 7000);
        } catch (error) { toast(error.message, "error", 7000); }
        finally { setBusy(button, false); }
      })();
    }
  });

  document.addEventListener("change", (event) => {
    if (event.target.id === "photoInput") void addPhotos(event.target.files);
  });

  document.addEventListener("keydown", (event) => {
    if ((event.key === "Enter" || event.key === " ") && event.target.matches("[data-open-batch]")) {
      event.preventDefault();
      void loadBatch(event.target.dataset.openBatch);
    }
  });

  async function init() {
    try {
      state.me = await api("/api/auth/me");
      renderAccount();
      setMode("web");
      await loadBatches();
    } catch (error) {
      toast(`初始化失败：${error.message}`, "error", 9000);
      $("#recentBatches").innerHTML = emptyState("平台会话初始化失败，请刷新页面重试。");
    }
  }

  init();
})();

