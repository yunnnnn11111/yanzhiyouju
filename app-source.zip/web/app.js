(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const state = {
    shandong: null,
    yantai: null,
    moa: null,
    moaMode: "",
    yantaiMode: "",
    me: null,
    batches: [],
    currentBatch: null,
    currentView: "workbench",
    mode: "web",
    photos: [],
    admin: null,
    rules: null,
    catalog: null,
    market: null,
    marketProduct: "",
    marketPick: "",
    marketResolvedName: "",
    marketDemo: false,
    channelSort: "profit",
    busy: false
  };
  const FEATURE_LABELS = {
    registration_enabled: "开放自助注册",
    guest_analysis_enabled: "游客临时分析",
    web_collection_enabled: "公开网页采集",
    platform_api_enabled: "启用平台 API",
    user_api_enabled: "允许用户自有 API",
    export_enabled: "报告导出",
    manual_override_enabled: "人工复核申请（不能绕过拦截）"
  };
  const STATUS_LABELS = {
    draft: "档案待补充", collected: "已有线索", evidence: "证据整理中",
    analyzed: "分析完成", reviewed: "合规待处理", paused: "待重新分析",
    exported: "已导出", feedback: "已回填反馈"
  };
  const EVIDENCE_STATUS = {
    pending: "待核验", verified: "已核验", rejected: "已驳回",
    conflict: "存在冲突", expired: "已过期"
  };
  const LEVEL_LABELS = {
    pass: "通过", medium: "需调整", high: "高风险", blocker: "阻断"
  };

  function esc(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function safeUrl(value) {
    try {
      if (!value) return "";
      const url = new URL(String(value), window.location.origin);
      return ["http:", "https:"].includes(url.protocol) ? url.href : "";
    } catch (_) { return ""; }
  }
  const EVIDENCE_LABELS = {BATCH_RECORD:"批次档案",TRANSPORT_STORAGE:"运输仓储",GI_CERT:"地理标志证明",ORIGIN_PROOF:"产地证明",GRADE_STANDARD:"等级依据",TEST_REPORT:"检测报告",PRICE_REF:"价格依据",PROCESS_RECORD:"工艺记录",GREEN_CERT:"认证证书",SALES_DATA:"销售数据",USER_FEEDBACK:"用户反馈"};
  function evidenceNames(values) { return (values || []).map((v) => EVIDENCE_LABELS[v] || v).join("、"); }
  function number(value, digits = 1) {
    const n = Number(value);
    if (!Number.isFinite(n)) return "—";
    return n.toLocaleString("zh-CN", { maximumFractionDigits: digits });
  }
  function money(value) {
    const n = Number(value);
    return Number.isFinite(n) ? `¥${n.toLocaleString("zh-CN", { maximumFractionDigits: 2 })}` : "—";
  }
  function dateText(value) {
    if (!value) return "未记录";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleString("zh-CN", { hour12: false, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
  }
  function statusPill(status) {
    return `<span class="status-pill ${esc(status || "")}">${esc(STATUS_LABELS[status] || status || "未知")}</span>`;
  }
  function modePill(mode) {
    return `<span class="mode-pill ${esc(mode)}">${mode === "agent" ? "Agent 模式" : "联网模式"}</span>`;
  }
  function emptyState(text) { return `<div class="empty-state">${esc(text)}</div>`; }

  function toast(message, type = "success", duration = 4200) {
    const node = document.createElement("div");
    node.className = `toast ${type}`;
    node.textContent = String(message || "操作完成");
    $("#toastRoot").appendChild(node);
    setTimeout(() => node.remove(), duration);
  }
  function setBusy(button, busy, text = "处理中…") {
    if (!button) return;
    if (busy) {
      button.dataset.originalText = button.textContent;
      button.textContent = text;
      button.disabled = true;
    } else {
      button.textContent = button.dataset.originalText || button.textContent;
      button.disabled = false;
    }
  }
  async function api(path, options = {}) {
    const request = { method: options.method || "GET", credentials: "same-origin", headers: {} };
    if (request.method === "POST") {
      request.headers["Content-Type"] = "application/json";
      request.headers["X-Requested-With"] = "YanZhiYouJu";
      request.body = JSON.stringify(options.body || {});
    }
    const SOFT = [502, 503, 504];
    let response = await fetch(path, request);
    if (!response.ok && request.method === "GET" && SOFT.indexOf(response.status) >= 0) {
      await new Promise((resolve) => setTimeout(resolve, 6000));
      response = await fetch(path, request);
    }
    let data = null;
    try { data = await response.json(); } catch (_) { data = null; }
    if (!response.ok) {
      const soft = SOFT.indexOf(response.status) >= 0;
      const message = data && data.error
        ? data.error
        : soft
          ? "服务正在唤醒（免费实例休眠后约 20–50 秒），请稍后重试"
          : `请求失败（HTTP ${response.status}）`;
      const error = new Error(message);
      error.status = response.status;
      throw error;
    }
    return data || {};
  }
  function openModal(title, subtitle, body, options = {}) {
    $("#modalRoot").innerHTML = `
      <div class="modal-backdrop" data-modal-close="backdrop">
        <section class="modal ${options.large ? "large" : ""}" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
          <header class="modal-head">
            <div><h2 id="modalTitle">${esc(title)}</h2><p>${esc(subtitle || "")}</p></div>
            <button class="modal-close" type="button" data-modal-close="button" aria-label="关闭">×</button>
          </header>
          <div class="modal-body">${body}</div>
        </section>
      </div>`;
    document.body.style.overflow = "hidden";
    const first = $("#modalRoot input, #modalRoot select, #modalRoot textarea, #modalRoot button");
    if (first) setTimeout(() => first.focus(), 50);
  }
  function closeModal() {
    $("#modalRoot").innerHTML = "";
    document.body.style.overflow = "";
  }
  function modalError(message) {
    const box = $("#modalError");
    if (box) { box.textContent = message; box.hidden = false; }
  }
  function downloadText(filename, text, mime) {
    const blob = new Blob([text], { type: mime || "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename || "report.txt";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      toast("文案已复制");
    } catch (_) { toast("浏览器未允许复制，请手动选择文本", "warning"); }
  }
  function currentIdentity() { return state.me && state.me.identity ? state.me.identity : {}; }
  function currentUser() { return currentIdentity().user || {}; }
  function isGuest() { return currentIdentity().kind === "guest"; }
  function isAdmin() { return currentUser().role === "admin"; }
  function feature(name) { return !!(state.me && state.me.features && state.me.features[name]); }

  const EXAMPLE = {
    name: "烟台苹果", origin_address: "山东省烟台市栖霞市", organization: "栖霞市示例果业合作社",
    batch_weight_kg: 500, variety: "红富士", spec: "80mm 果径，一级果", unit_price_yuan_per_kg: 8,
    unit_cost_yuan_per_kg: 3, transport: "冷链车", storage: "0–5℃ 冷库，可存 30 天",
    transport_capacity_kg: 1000, daily_capacity_kg: 200, target_market: "西安、成都、企业福利采购",
    notes: "示例数据仅用于演示流程，请以真实批次材料替换。"
  };

  document.addEventListener("click", (event) => {
    const closer = event.target.closest("[data-modal-close]");
    if (closer && (closer.dataset.modalClose === "backdrop" ? event.target === closer : true)) closeModal();
  });
  document.addEventListener("click", (event) => {
    const tab = event.target.closest("[data-market-product]");
    if (tab) {
      state.marketPick = tab.dataset.marketProduct;
      state.marketProduct = tab.dataset.marketProduct;
      state.market = null;
      loadMarket(true);
      return;
    }
    if (event.target.closest("#marketRefresh")) {
      state.market = null;
      loadMarket(true);
    }
    const pullMoa = event.target.closest("[data-moa-refresh]");
    if (pullMoa) {
      if (pullMoa.dataset.busy === "1") return;
      pullMoa.dataset.busy = "1";
      pullMoa.textContent = "正在抓取…";
      pullMoa.disabled = true;
      api("/api/market/moa?refresh=1")
        .then((data) => {
          state.moa = data.moa || {};
          state.moaMode = data.mode || "";
          renderMoa(state.moa);
        })
        .catch(() => {
          pullMoa.textContent = "抓取失败，稍后重试";
        })
        .finally(() => {
          const again = document.querySelector("[data-moa-refresh]");
          if (again) {
            again.dataset.busy = "0";
            again.disabled = false;
            again.textContent = "抓取最新";
          }
        });
      return;
    }
    const pull = event.target.closest("[data-yt-refresh]");
    if (pull) {
      if (pull.dataset.busy === "1") return;
      pull.dataset.busy = "1";
      const label = pull.textContent;
      pull.textContent = "正在抓取…";
      pull.disabled = true;
      api("/api/market/yantai?refresh=1")
        .then((data) => {
          state.yantai = data.yantai || {};
          state.yantaiMode = data.mode || "";
          renderYT(state.yantai);
        })
        .catch(() => {
          pull.textContent = "抓取失败，稍后重试";
        })
        .finally(() => {
          const again = document.querySelector("[data-yt-refresh]");
          if (again) {
            again.dataset.busy = "0";
            again.disabled = false;
            again.textContent = label || "抓取最新一期";
          }
        });
    }
  });

  document.addEventListener("change", (event) => {
    const el = event.target;
    if (el && (el.id === "marketWeight" || el.id === "marketHold")) {
      el.dataset.touched = "1";
      state.market = null;
      loadMarket(true);
    }
    if (el && el.id === "marketSearch") {
      const value = String(el.value || "").trim();
      if (value) {
        state.marketPick = value;
        state.market = null;
        loadMarket(true);
      }
    }
  });

  document.addEventListener("keydown", (event) => {
    const el = event.target;
    if (el && el.id === "marketSearch" && event.key === "Enter") {
      const value = String(el.value || "").trim();
      if (value) {
        state.marketPick = value;
        state.market = null;
        loadMarket(true);
      }
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && $("#modalRoot").children.length) closeModal();
  });

  function renderAccount() {
    const area = $("#accountArea");
    if (!state.me) { area.innerHTML = '<span class="loading-pill">会话加载失败</span>'; return; }
    const identity = currentIdentity();
    const user = currentUser();
    $$(".admin-only").forEach((node) => { node.hidden = !isAdmin(); });
    if (identity.kind === "guest") {
      area.innerHTML = `
        <span class="loading-pill" title="临时保存 2 小时">游客 · 临时保存</span>
        <button class="button ghost small" type="button" data-auth="login">登录</button>
        <button class="button primary small" type="button" data-auth="register">注册</button>`;
      return;
    }
    const initial = String(user.username || "用").slice(0, 1);
    area.innerHTML = `
      <div class="account-user"><span class="avatar">${esc(initial)}</span><span class="account-name"><strong>${esc(user.username)}</strong><small>${isAdmin() ? "平台管理员" : "普通用户"}</small></span></div>
      <button class="button ghost small" type="button" data-auth="api">API</button>
      <button class="button ghost small" type="button" data-auth="password">改密</button>
      <button class="button ghost small" type="button" data-auth="logout">退出</button>`;
    if (user.must_change_password) setTimeout(() => openPasswordModal(true), 120);
  }

  function authForm(mode) {
    const isRegister = mode === "register";
    return `
      <form id="authForm" class="form-stack">
        <label class="field"><span>用户名 <b>*</b></span><input name="username" required minlength="3" maxlength="24" autocomplete="username" placeholder="3–24 位中文、字母、数字、下划线或短横线"></label>
        <label class="field"><span>密码 <b>*</b></span><input name="password" type="password" required minlength="8" maxlength="128" autocomplete="${isRegister ? "new-password" : "current-password"}" placeholder="至少 8 位"></label>
        ${isRegister ? '<p class="help">注册后可按账号保存批次；普通用户数据隔离。免费演示服务重启可能丢失记录，请及时导出。</p>' : ""}
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">${isRegister ? "创建账号" : "登录"}</button></div>
      </form>`;
  }
  function openAuth(mode) {
    openModal(mode === "register" ? "注册账号" : "登录", "登录后按账号管理批次和证据，重要记录请导出备份", authForm(mode));
    $("#authForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const button = event.submitter;
      const data = Object.fromEntries(new FormData(event.currentTarget));
      setBusy(button, true, "请稍候…");
      try {
        const result = await api(`/api/auth/${mode}`, { method: "POST", body: data });
        state.me = result.state;
        closeModal();
        renderAccount();
        await loadBatches();
        toast(mode === "register" ? "账号已创建" : "登录成功");
        if (result.user && result.user.must_change_password) openPasswordModal(true);
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }
  function openPasswordModal(forced = false) {
    openModal(forced ? "请先修改密码" : "修改密码", forced ? "首次登录或密码重置后必须修改密码" : "修改后其他会话将需要使用新密码", `
      <form id="passwordForm" class="form-stack">
        <label class="field"><span>当前密码</span><input name="old_password" type="password" required autocomplete="current-password"></label>
        <label class="field"><span>新密码</span><input name="new_password" type="password" required minlength="8" maxlength="128" autocomplete="new-password" placeholder="至少 8 位，不能与旧密码相同"></label>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">稍后</button><button class="button primary" type="submit">确认修改</button></div>
      </form>`);
    $("#passwordForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const button = event.submitter;
      setBusy(button, true);
      try {
        const data = Object.fromEntries(new FormData(event.currentTarget));
        const result = await api("/api/auth/password", { method: "POST", body: data });
        if (state.me) {
          state.me.identity.user = result.user;
          state.me.stats = state.me.stats || {};
        }
        closeModal(); renderAccount(); toast("密码已修改");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }
  async function logout() {
    try {
      await api("/api/auth/logout", { method: "POST", body: {} });
      const result = await api("/api/auth/me");
      state.me = result; state.currentBatch = null; state.batches = [];
      renderAccount(); await loadBatches(); showView("workbench"); toast("已退出登录");
    } catch (error) { toast(error.message, "error"); }
  }
  function openApiConfig() {
    const config = (state.me && state.me.api_config) || {};
    const own = config.own || {};
    const platform = config.platform || {};
    const userApiEnabled = config.user_api_enabled !== false;
    openModal("API 设置", "Agent 模式需要兼容 Chat Completions 的服务", `
      <div class="form-stack">
        <div class="info-box">平台 API：${platform.enabled && platform.configured ? `已启用 · ${esc(platform.model || "")}` : "未启用或未配置"}；我的 API：${own.configured ? `已配置 · ${esc(own.key_masked || "")}` : "未配置"}。密钥只保存加密值，浏览器仅显示掩码。</div>
        <form id="ownApiForm" class="settings-form">
          <label>Base URL<input name="base_url" type="url" value="${esc(own.base_url || "https://api.deepseek.com")}" placeholder="https://api.deepseek.com" ${userApiEnabled ? "" : "disabled"}></label>
          <label>模型名称<input name="model" value="${esc(own.model || "deepseek-chat")}" placeholder="deepseek-chat" ${userApiEnabled ? "" : "disabled"}></label>
          <label>API Key${own.configured ? "（留空保持原值）" : ""}<input name="api_key" type="password" autocomplete="off" placeholder="${own.configured ? "已配置，留空不修改" : "填写服务密钥"}" ${userApiEnabled ? "" : "disabled"}></label>
          ${own.last_test ? `<p class="help">最近测试：${esc(own.last_test.message || own.last_test.status || "")}</p>` : ""}
          <div id="modalError" class="danger-box" hidden></div>
          <div class="modal-actions">
            ${userApiEnabled ? '<button class="button ghost" type="button" id="testOwnApi">测试连接</button><button class="button primary" type="submit">保存我的 API</button>' : '<span class="warning-box">管理员已关闭用户自有 API</span>'}
          </div>
        </form>
      </div>`);
    const form = $("#ownApiForm");
    if (!form) return;
    $("#testOwnApi")?.addEventListener("click", async (event) => {
      const button = event.currentTarget; setBusy(button, true, "测试中…");
      try {
        const result = await api("/api/api-config", { method: "POST", body: { action: "test", source: "own" } });
        toast(result.test?.message || "连接成功");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const button = event.submitter; setBusy(button, true, "保存中…");
      try {
        const body = Object.fromEntries(new FormData(form));
        const result = await api("/api/api-config", { method: "POST", body });
        state.me.api_config = result.config;
        closeModal(); toast("API 设置已保存");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  function setMode(mode) {
    state.mode = mode === "agent" ? "agent" : "web";
    $$("#modeSwitch button").forEach((button) => button.classList.toggle("active", button.dataset.mode === state.mode));
    $("#agentSourceRow").hidden = state.mode !== "agent";
    $("#modeHint").textContent = state.mode === "agent"
      ? "Agent 模式调用兼容 Chat Completions 的 API，用于提取主张、补问和长尾复核；证据门禁仍由本地规则判定。"
      : "联网模式不需要 API，先查本地案例库再检索公开网页，由本地规则完成分析。";
  }
  function fillExample() {
    const form = $("#batchForm");
    Object.entries(EXAMPLE).forEach(([name, value]) => {
      const field = form.elements[name];
      if (field) field.value = value;
    });
    setMode("web");
    toast("已填入示例；这些是模拟数据，请替换为真实材料", "info", 5200);
    form.elements.name.focus();
  }
  function renderPhotoPreview() {
    $("#photoPreview").innerHTML = state.photos.map((photo, index) => `
      <div class="photo-thumb"><img src="${esc(photo.data)}" alt="产品照片 ${index + 1}"><button type="button" data-remove-photo="${index}" aria-label="移除照片">×</button></div>`).join("");
  }
  function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("照片读取失败"));
      reader.readAsDataURL(file);
    });
  }
  async function compressImage(file) {
    const raw = await readFileAsDataUrl(file);
    if (file.size < 650 * 1024) return raw;
    return new Promise((resolve) => {
      const image = new Image();
      image.onload = () => {
        const scale = Math.min(1, 1400 / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", .78));
      };
      image.onerror = () => resolve(raw);
      image.src = raw;
    });
  }
  async function addPhotos(files) {
    for (const file of Array.from(files || [])) {
      if (state.photos.length >= 4) { toast("最多上传 4 张照片", "warning"); break; }
      if (!file.type.startsWith("image/")) continue;
      if (file.size > 8 * 1024 * 1024) { toast(`${file.name} 超过 8MB，已跳过`, "warning"); continue; }
      try { state.photos.push({ data: await compressImage(file), caption: file.name }); }
      catch (error) { toast(error.message, "error"); }
    }
    renderPhotoPreview();
    $("#photoInput").value = "";
  }
  function batchPayload() {
    const form = $("#batchForm");
    const fields = {};
    for (const name of ["name", "origin_address", "organization", "variety", "spec", "transport", "storage", "harvest_date", "package_date", "target_market", "notes"]) {
      fields[name] = String(form.elements[name].value || "").trim();
    }
    for (const name of ["batch_weight_kg", "unit_price_yuan_per_kg", "unit_cost_yuan_per_kg", "transport_capacity_kg", "daily_capacity_kg"]) {
      const value = form.elements[name].value;
      fields[name] = value === "" ? null : Number(value);
    }
    return { product: fields, mode: state.mode, photos: state.photos };
  }
  async function saveBatch(analyze, button) {
    const form = $("#batchForm");
    if (!form.reportValidity()) return;
    if (state.busy) return;
    state.busy = true; setBusy(button, true, analyze ? "正在生成方案…" : "正在保存…");
    try {
      const created = await api("/api/batches", { method: "POST", body: batchPayload() });
      state.currentBatch = created.batch;
      const batchId = created.batch.id;
      await loadBatches();
      if (analyze) {
        const mode = created.batch.mode || state.mode;
        const result = await api(`/api/batches/${encodeURIComponent(batchId)}/analyze`, {
          method: "POST", body: { mode, api_source: $("#apiSourceSelect").value || "auto" }
        });
        state.currentBatch = result.batch;
        showView("report");
        renderReport(result.batch);
        toast(result.notice || "分析完成");
      } else {
        showView("batch");
        await loadBatch(batchId);
        toast(created.guest ? "档案已临时保存 2 小时" : "批次档案已保存", "info");
      }
      state.photos = []; renderPhotoPreview();
    } catch (error) {
      toast(error.message, "error", 7000);
      if (state.currentBatch) await loadBatch(state.currentBatch.id, "batch");
    } finally { state.busy = false; setBusy(button, false); }
  }
  async function loadBatches() {
    try {
      const result = await api("/api/batches");
      state.batches = result.batches || [];
      renderRecentBatches();
      if (state.me) state.me.stats = result.stats || state.me.stats;
    } catch (error) {
      $("#recentBatches").innerHTML = emptyState(error.message);
    }
  }
  function renderRecentBatches() {
    const root = $("#recentBatches");
    if (!state.batches.length) {
      root.innerHTML = emptyState("还没有批次。填入最少信息，先跑通一次烟台苹果示例。");
      return;
    }
    root.innerHTML = state.batches.slice(0, 6).map((batch) => `
      <article class="recent-batch" data-open-batch="${esc(batch.id)}" tabindex="0" role="button">
        <div class="recent-batch-top"><strong>${esc(batch.product_name || "未命名产品")}</strong>${statusPill(batch.status)}</div>
        <p>${esc(batch.organization || "")} · ${esc(batch.origin || "")}</p>
        <div class="recent-batch-meta"><span>${number(batch.weight_kg)} kg</span><span>证据 ${number(batch.evidence_verified, 0)}/${number(batch.evidence_total, 0)}</span><span>${esc(batch.best_plan || "尚未测算")}</span></div>
        <div class="recent-batch-foot"><span>${esc(batch.batch_code || batch.id)}</span><span>查看 →</span></div>
      </article>`).join("");
  }

  async function showView(view) {
    if (view === "admin" && !isAdmin()) { toast("仅管理员可进入管理中心", "error"); return; }
    if ((view === "batch" || view === "report") && !state.currentBatch) {
      if (!state.batches.length) { toast("请先创建一个批次", "warning"); return; }
      await loadBatch(state.batches[0].id, view); return;
    }
    if (view === "batch" && state.currentBatch) {
      await loadBatch(state.currentBatch.id, "batch"); return;
    }
    state.currentView = view;
    $$(".view").forEach((node) => { node.hidden = node.id !== `view-${view}`; });
    $$(".nav-item").forEach((button) => button.classList.toggle("active", button.dataset.view === view));
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (view === "report" && state.currentBatch) renderReport(state.currentBatch);
    if (view === "admin") await loadAdmin();
    if (view === "rules") await loadRules();
    if (view === "cases") await loadCases();
    if (view === "market") await loadMarket();
  }


  /* ---------------- 行情与卖窗口（2026-11-18 新增） ---------------- */

  const MARKET_TONES = { up: "持有更划算", down: "现在出手更稳", flat: "分批走，别押一个点" };

  function marketMA(rows, span) {
    return rows.map((row, i) => {
      const from = Math.max(0, i - span + 1);
      const slice = rows.slice(from, i + 1);
      return slice.reduce((sum, r) => sum + r.avg, 0) / slice.length;
    });
  }

  function marketPriceChart(rows) {
    if (!rows || rows.length < 2) return `<div class="empty-state">这一段没有可用的连续报价</div>`;
    const W = 1160, H = 320, PADL = 56, PADR = 20, PADT = 22, PADB = 34;
    const lows = rows.map((r) => r.low), highs = rows.map((r) => r.high);
    const all = rows.map((r) => r.avg);
    const minAll = Math.min(...lows), maxAll = Math.max(...highs);
    const min = Math.min(...all, minAll), max = Math.max(...all, maxAll);
    const span = max - min || 1;
    const x = (i) => PADL + (i * (W - PADL - PADR)) / (rows.length - 1);
    const y = (v) => PADT + (1 - (v - min) / span) * (H - PADT - PADB);
    const daily = rows.map((r, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(r.avg).toFixed(1)}`).join(" ");
    const ma = marketMA(rows, 7);
    const maPath = ma.map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");

    const grid = [0, 0.5, 1].map((t) => {
      const v = min + span * t;
      return `<line class="m-grid" x1="${PADL}" y1="${y(v).toFixed(1)}" x2="${W - PADR}" y2="${y(v).toFixed(1)}"/>
        <text class="m-axis" x="${PADL - 10}" y="${(y(v) + 4).toFixed(1)}" text-anchor="end">${v.toFixed(2)}</text>`;
    }).join("");
    const step = Math.max(1, Math.floor((rows.length - 1) / 4));
    const ticks = [];
    for (let i = 0; i <= rows.length - 1; i += step) ticks.push(i);
    if (ticks[ticks.length - 1] !== rows.length - 1) ticks.push(rows.length - 1);
    const tickHtml = ticks.map((i) =>
      `<text class="m-axis" x="${x(i).toFixed(1)}" y="${H - 10}" text-anchor="${i === 0 ? "start" : i === rows.length - 1 ? "end" : "middle"}">${rows[i].date.slice(5)}</text>`).join("");
    const last = rows[rows.length - 1];
    return `<svg class="m-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="近 ${rows.length} 天价格走势">
      ${grid}
      <path class="m-daily" d="${daily}"/>
      <path class="m-ma" d="${maPath}"/>
      <circle class="m-dot" cx="${x(rows.length - 1).toFixed(1)}" cy="${y(last.avg).toFixed(1)}" r="4"/>
      <text class="m-now" x="${(W - PADR).toFixed(1)}" y="${PADT + 2}" text-anchor="end">最新 ${last.avg.toFixed(2)} 元/斤</text>
      ${tickHtml}
    </svg>
    <div class="m-legend"><span class="l-ma">7 日均线</span><span class="l-daily">当日均价</span><span class="l-range">当日最低–最高 ${min.toFixed(2)}–${max.toFixed(2)} 元/斤（不同规格/产地价差）</span></div>`;
  }

  function marketStatCells(st) {
    const pct = (v) => (v === null || v === undefined) ? "—" : `${v > 0 ? "+" : ""}${v}%`;
    const cells = [
      ["最新均价", `${st.today} 元/斤`, `日 ${pct(st.day_change_pct)}`],
      ["近 7 天", `${st.week_avg} 元/斤`, `周 ${pct(st.week_change_pct)}`, st.week_change_pct < 0 ? "down" : "up"],
      ["近 30 天", `${st.month_avg} 元/斤`, `月 ${pct(st.month_change_pct)}`, st.month_change_pct < 0 ? "down" : "up"],
      ["90 天区间", `${st.min_90d.toFixed(2)} – ${st.max_90d.toFixed(2)}`, `波动率 ${st.volatility_pct}%`],
    ];
    return cells.map(([k, v, sub, tone]) => `<div class="m-stat ${tone || ""}"><span>${esc(k)}</span><b>${esc(v)}</b><em>${esc(sub)}</em></div>`).join("");
  }

  function marketHoldTable(ad, weight) {
    const h = ad.hold || {};
    const delta = h.delta_vs_now || 0;
    const tone = delta > 0 ? "up" : "down";
    return `<table class="m-table">
      <thead><tr><th>方案</th><th>单价</th><th>${Math.round(weight)} kg 折价</th><th>成本</th><th>净额</th></tr></thead>
      <tbody>
        <tr><td>今天全卖</td><td>${ad.sell_now.price} 元/斤</td><td>${money(ad.sell_now.value)}</td><td>—</td><td>${money(ad.sell_now.value)}</td></tr>
        <tr><td>入库 ${ad.hold_days} 天</td><td>${h.expected_price} 元/斤</td><td>${money(h.value)}</td><td>${money(h.storage_cost)} 冷藏 + ${h.loss_kg} kg 损耗</td><td class="${tone}">${money(h.net)}</td></tr>
      </tbody>
      <tfoot><tr><td colspan="5">相对今天差 ${delta >= 0 ? "+" : ""}${money(delta)}（按近 30 天涨跌幅外推到期价；冷藏 ${ad.assumptions.storage_cost_per_kg_day} 元/kg/天、日损耗 ${(ad.assumptions.loss_per_day * 100).toFixed(2)}%）</td></tr></tfoot>
    </table>`;
  }

  function ytChart(series) {
    const rows = (series || []).filter((r) => r && r.price);
    if (rows.length < 2) return "";
    const W = 1160, H = 240, padL = 54, padR = 74, padT = 18, padB = 30;
    const prices = rows.map((r) => r.price);
    const lo = Math.min(...prices), hi = Math.max(...prices);
    const span = hi - lo || 1;
    const x = (i) => padL + (i * (W - padL - padR)) / (rows.length - 1);
    const y = (v) => padT + ((hi - v) / span) * (H - padT - padB);
    const pts = rows.map((r, i) => `${x(i).toFixed(1)},${y(r.price).toFixed(1)}`).join(" ");
    const dots = rows.map((r, i) => `<circle class="yt-dot" cx="${x(i).toFixed(1)}" cy="${y(r.price).toFixed(1)}" r="2.6"><title>${esc(r.date)} · ${r.price.toFixed(2)} 元/斤</title></circle>`).join("");
    const ticks = [hi, (hi + lo) / 2, lo].map((v) => `<text class="yt-axis" x="${padL - 8}" y="${(y(v) + 3.5).toFixed(1)}" text-anchor="end">${v.toFixed(2)}</text>`).join("");
    const dateLabels = [0, Math.floor((rows.length - 1) / 2), rows.length - 1]
      .map((i) => `<text class="yt-axis" x="${x(i).toFixed(1)}" y="${H - 8}" text-anchor="${i === 0 ? "start" : i === rows.length - 1 ? "end" : "middle"}">${esc((rows[i].date || "").slice(5))}</text>`)
      .join("");
    return `<svg class="yt-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="烟台红富士一级零售价周走势">
      <line class="yt-grid" x1="${padL}" y1="${padT}" x2="${W - padR}" y2="${padT}" />
      <line class="yt-grid" x1="${padL}" y1="${padT + (H - padT - padB) / 2}" x2="${W - padR}" y2="${padT + (H - padT - padB) / 2}" />
      <line class="yt-grid" x1="${padL}" y1="${H - padB}" x2="${W - padR}" y2="${H - padB}" />
      ${ticks}${dateLabels}
      <polyline class="yt-line" points="${pts}" />
      ${dots}
      <text class="yt-now" x="${W - padR + 8}" y="${(y(rows[rows.length - 1].price) + 4).toFixed(1)}">${rows[rows.length - 1].price.toFixed(2)}</text>
    </svg>`;
  }

  function ytItemsTable(items) {
    const rows = (items || []).filter((it) => it && it.price != null && ["水果", "蔬菜"].includes(it.category));
    if (!rows.length) return "";
    const body = rows.map((it) => {
      const pct = it.change_pct;
      const dir = pct == null ? "flat" : pct > 0 ? "up" : pct < 0 ? "down" : "flat";
      const txt = pct == null ? "—" : `${pct > 0 ? "+" : ""}${pct.toFixed(2)}%`;
      return `<tr><td>${esc(it.category)}</td><td>${esc(it.name)}</td><td>${esc(it.grade)}</td><td class="num">${it.price.toFixed(2)}</td><td class="num ${dir}">${txt}</td></tr>`;
    }).join("");
    return `<details class="yt-items"><summary>最新一期监测明细（${rows.length} 项）</summary>
      <table class="sd-table"><thead><tr><th>类别</th><th>品名</th><th>标准等级</th><th class="num">元/斤</th><th class="num">较上周</th></tr></thead><tbody>${body}</tbody></table>
    </details>`;
  }

  function ytPickFruit(yt, activeName) {
    const series = (yt && yt.fruit_series) || {};
    const keys = Object.keys(series).filter((key) => (series[key] || []).length >= 2);
    if (!keys.length) return null;
    const tries = [];
    if (isAppleName(activeName)) tries.push("苹果");
    keys.forEach((key) => { if (nameHit(key, activeName)) tries.push(key); });
    if (String(activeName).includes("桔") || String(activeName).includes("橘")) tries.push("桔子");
    const host = String(activeName).replace(/^(国产|进口|山东|烟台|栖霞)/, "");
    keys.forEach((key) => { if (host && key.includes(host)) tries.push(key); });
    for (const key of tries) {
      const rows = series[key] || [];
      if (rows.length >= 2) return { key: key, rows: rows };
    }
    return null;
  }

  function renderYT(yt) {
    const box = $("#marketYT");
    if (!box) return;
    const src = (yt && yt.source) || {};
    const modeText = state.yantaiMode === "live" ? "实时抓取" : state.yantaiMode === "cache" ? "缓存（6 小时内）" : "随包快照";
    const activeName = state.marketResolvedName || state.marketProduct || "";
    const picked = ytPickFruit(yt, activeName);

    if (picked) {
      const rows = picked.rows;
      const last = rows[rows.length - 1];
      const prev = rows.length > 1 ? rows[rows.length - 2] : null;
      const prices = rows.map((row) => Number(row.price));
      const min = Math.min.apply(null, prices);
      const max = Math.max.apply(null, prices);
      const pct = last.change_pct == null ? (prev ? ((last.price - prev.price) / prev.price) * 100 : null) : last.change_pct;
      const dir = pct == null ? "flat" : pct > 0 ? "up" : pct < 0 ? "down" : "flat";
      const span = ((prices[prices.length - 1] - prices[0]) / prices[0]) * 100;
      box.hidden = false;
      box.innerHTML = `
        <div class="sd-head">
          <h2>烟台官方零售价 · ${esc(picked.key)}</h2>
          <div class="yt-head-right">
            <span class="yt-mode ${esc(state.yantaiMode || "bundle")}">${esc(modeText)}</span>
            <span class="sd-time">采价 ${esc(last.date || "")} · 每周一期</span>
            <button type="button" class="yt-refresh" data-yt-refresh>抓取最新一期</button>
          </div>
        </div>
        <div class="yt-facts">
          <div class="yt-fact"><span>最新全市均价</span><b>${Number(last.price).toFixed(2)}</b><em>元/斤</em><i class="${dir}">${pct == null ? "—" : (pct > 0 ? "+" : "") + Number(pct).toFixed(2) + "%"} 较上周</i></div>
          <div class="yt-fact"><span>近 ${rows.length} 周区间</span><b>${min.toFixed(2)}–${max.toFixed(2)}</b><em>元/斤</em><i>${rows[0].date} 起 ${span > 0 ? "+" : ""}${span.toFixed(2)}%</i></div>
          <div class="yt-fact"><span>采集口径</span><b>${esc(String(activeName) === picked.key ? "同名品种" : "按「" + activeName + "」匹配")}</b><em>${esc(src.name || "市发改委")}</em><i>超市与农贸市场零售价</i></div>
        </div>
        ${ytChart(rows)}
        <p class="sd-note">${esc((yt && yt.fruit_note) || "")}</p>
        <p class="sd-src">数据来源：<a href="${esc(safeUrl(src.url) || "#")}" target="_blank" rel="noopener noreferrer">${esc(src.name || "烟台市发展和改革委员会 · 农产品价格")}</a> ${esc(src.note || "")}</p>`;
      return;
    }

    const items = (yt && (yt.latest_items || (yt.latest && yt.latest.items))) || [];
    const hit = items.find((row) => row && nameHit(row.name, activeName));
    if (!hit) {
      box.hidden = true;
      box.innerHTML = "";
      return;
    }
    box.hidden = false;
    box.innerHTML = `
      <div class="sd-head">
        <h2>烟台本周零售价 · ${esc(hit.name)}</h2>
        <div class="yt-head-right">
          <span class="yt-mode ${esc(state.yantaiMode || "bundle")}">${esc(modeText)}</span>
          <span class="sd-time">采价 ${esc((yt.stats || {}).latest_date || "")} · 每周一期</span>
        </div>
      </div>
      <div class="yt-facts">
        <div class="yt-fact"><span>全市零售均价</span><b>${number(hit.price, 2)} 元/斤</b><em>${hit.change_pct == null ? "—" : (hit.change_pct > 0 ? "+" : "") + Number(hit.change_pct).toFixed(2) + "%"} 较上周</em></div>
        <div class="yt-fact"><span>历史序列</span><b>暂无</b><em>该站本期只公布了 ${esc(hit.name)} 的当期价</em></div>
      </div>
      <p class="sd-note">数据来源：<a href="${esc(safeUrl(src.url) || "#")}" target="_blank" rel="noopener">${esc(src.name || "烟台市发展和改革委员会")}</a>；零售均价，不等于产地收购价。</p>`;
  }

function moaSpark(rows) {
    const pts = (rows || []).filter((row) => row && row.apple != null);
    if (pts.length < 2) return "";
    const values = pts.map((row) => Number(row.apple));
    const min = Math.min.apply(null, values);
    const max = Math.max.apply(null, values);
    const span = max - min || 1;
    const stepX = 220 / (values.length - 1);
    const y = (value) => 28 - ((value - min) / span) * 26;
    const path = values
      .map((value, index) => `${index === 0 ? "M" : "L"}${(index * stepX).toFixed(1)},${y(value).toFixed(1)}`)
      .join(" ");
    return `<svg class="moa-spark" viewBox="0 0 220 32" preserveAspectRatio="none" role="img" aria-label="富士苹果指数近 ${values.length} 个月走势">
      <path d="${path}" fill="none" stroke="#2a6d4d" stroke-width="1.6" stroke-linejoin="round" />
      <circle cx="220" cy="${y(values[values.length - 1]).toFixed(1)}" r="2.6" fill="#2a6d4d" />
    </svg>`;
  }

  function moaCityCells(cities) {
    return ["beijing", "shanghai", "guangzhou"]
      .map((key) => {
        const city = (cities || {})[key];
        if (!city || !city.latest) return "";
        const latest = city.latest;
        return `<div class="moa-city">
          <span class="moa-city-name">${esc(city.name || key)}</span>
          <b>${number(latest.wholesale, 2)}</b>
          <em>元/公斤 · ${esc(String(latest.date || "").slice(5))}</em>
        </div>`;
      })
      .join("");
  }

  function renderMoa(moa) {
    const box = $("#marketMOA");
    if (!box) return;
    if (!isAppleName(state.marketResolvedName || state.marketProduct)) {
      box.hidden = true;
      box.innerHTML = "";
      return;
    }
    const indices = (moa && moa.indices) || {};
    if (!moa || indices.apple == null) {
      box.hidden = true;
      box.innerHTML = "";
      return;
    }
    box.hidden = false;
    const src = moa.source || {};
    const monthly = moa.monthly || [];
    const prev = monthly.length > 1 ? monthly[monthly.length - 2] : null;
    const delta = prev && prev.apple ? ((indices.apple - prev.apple) / prev.apple) * 100 : null;
    const dir = delta == null ? "flat" : delta > 0 ? "up" : delta < 0 ? "down" : "flat";
    const mode = state.moaMode || "bundle";
    const modeText = mode === "live" ? "实时抓取" : mode === "cache" ? "缓存（6 小时内）" : "随包快照";
    box.innerHTML = `
      <div class="sd-head">
        <h2>农业农村部 · 苹果产业大数据（富士苹果指数）</h2>
        <div class="yt-head-right">
          <span class="yt-mode ${esc(mode)}">${esc(modeText)}</span>
          <span class="sd-time">${esc(String(moa.fetched_at || "").slice(0, 16).replace("T", " "))}</span>
          <button class="btn btn-ghost small" type="button" data-moa-refresh>抓取最新</button>
        </div>
      </div>
      <div class="moa-facts">
        <div class="moa-fact">
          <span class="moa-label">富士苹果指数</span>
          <b>${number(indices.apple, 2)}</b>
          <em class="${dir}">${delta == null ? "—" : (delta > 0 ? "+" : "") + delta.toFixed(2) + "%"} · ${esc(indices.month || "")}</em>
        </div>
        <div class="moa-fact">
          <span class="moa-label">水果指数</span>
          <b>${number(indices.fruit, 2)}</b>
          <em>同期</em>
        </div>
        <div class="moa-fact">
          <span class="moa-label">农产品 200 指数</span>
          <b>${number(indices.total, 2)}</b>
          <em>同期</em>
        </div>
        <div class="moa-fact moa-fact-spark">
          <span class="moa-label">近 ${monthly.length} 个月走势</span>
          ${moaSpark(monthly)}
        </div>
      </div>
      <div class="moa-cities">${moaCityCells(moa.cities)}</div>
      <p class="sd-note">指数与三城批发价为农业农村部公开口径（批发价单位 元/公斤）；主产区田头价接口当前返回空数据，山东栖霞未在该平台单列。来源：<a href="${safeUrl(src.url || "")}" target="_blank" rel="noopener">${esc(src.name || "")}</a></p>
    `;
  }

  async function loadMoa(force) {
    if (state.moa && !force) {
      renderMoa(state.moa);
      return;
    }
    try {
      const data = await api("/api/market/moa");
      state.moa = data.moa || {};
      state.moaMode = data.mode || "";
    } catch (error) {
      state.moa = {};
    }
    renderMoa(state.moa);
  }

    async function loadYT(force) {
    if (state.yantai && !force) {
      renderYT(state.yantai);
      return;
    }
    try {
      const data = await api("/api/market/yantai");
      state.yantai = data.yantai || {};
      state.yantaiMode = data.mode || "";
    } catch (error) {
      state.yantai = {};
    }
    renderYT(state.yantai);
  }

  function sdIndexChips(indices) {
    const rows = (indices || []).filter((it) => it && it.value != null);
    if (!rows.length) return "";
    const chip = (it) => {
      const pct = it.change_pct;
      const dir = pct == null ? "flat" : pct > 0 ? "up" : pct < 0 ? "down" : "flat";
      const txt = pct == null ? "—" : `${pct > 0 ? "+" : ""}${pct.toFixed(2)}%`;
      return `<span class="sd-chip ${dir}"><b>${esc(it.name)}</b><i>${it.value.toFixed(2)}</i><em>${txt}</em></span>`;
    };
    return `<div class="sd-indices">${rows.map(chip).join("")}</div>`;
  }

  function sdItemsTable(items) {
    const rows = (items || []).filter((it) => it && it.price != null).slice(0, 18);
    if (!rows.length) return "";
    const body = rows.map((it) => {
      const pct = it.change_pct;
      const dir = pct == null ? "flat" : pct > 0 ? "up" : pct < 0 ? "down" : "flat";
      const txt = pct == null ? "—" : `${pct > 0 ? "+" : ""}${pct.toFixed(2)}%`;
      return `<tr><td>${esc(it.name)}</td><td class="num">${it.price.toFixed(2)}</td><td class="num ${dir}">${txt}</td></tr>`;
    }).join("");
    return `<table class="sd-table"><thead><tr><th>品名</th><th class="num">均价（元/公斤）</th><th class="num">较上期</th></tr></thead><tbody>${body}</tbody></table>`;
  }

  function renderSD(sd) {
    const box = $("#marketSD");
    if (!box) return;
    if (!sd || ((sd.indices || []).length === 0 && (sd.items || []).length === 0)) {
      box.hidden = true;
      box.innerHTML = "";
      return;
    }
    const wantName = state.marketResolvedName || state.marketProduct || "";
    const matchedItem = (sd.items || []).find((row) => row && nameHit(row.name, wantName));
    if (!matchedItem) {
      box.hidden = true;
      box.innerHTML = "";
      return;
    }
    box.hidden = false;
    const markets = (sd.markets || []).map((m) => m.name).filter(Boolean);
    const src = sd.source || {};
    box.innerHTML = `
      <details class="sd-fold">
        <summary>
          <span class="sd-fold-title">山东省价格监测（省发改委）</span>
          <span class="sd-fold-meta">${(sd.indices || []).length} 项指数 · ${(sd.items || []).length} 个品类 · ${markets.length} 家监测市场</span>
          <span class="sd-fold-hint">该站<b>未发布苹果</b>，以下为蔬菜/粮油等省级参考数据，点击展开</span>
        </summary>
        <div class="sd-body">
          <div class="sd-head">
            <h2>山东官方价格（省发改委价格监测）</h2>
            <span class="sd-time">${esc((sd.fetched_at || "").slice(0, 16).replace("T", " "))}</span>
          </div>
          ${sdIndexChips(sd.indices)}
          <div class="sd-grid">
            ${sdItemsTable(sd.items)}
            <div class="sd-side">
              <p class="sd-label">监测市场（${markets.length} 家）</p>
              <p class="sd-markets">${markets.map((n) => `<span>${esc(n)}</span>`).join("")}</p>
              <p class="sd-note">该站发布蔬菜、粮油、猪肉等品类与省级价格指数，<strong>未发布苹果单品价格</strong>。</p>
              <p class="sd-src">数据来源：<a href="${esc(safeUrl(src.url) || "#")}" target="_blank" rel="noopener noreferrer">${esc(src.name || "山东省价格监测与价格指数发布网")}</a></p>
            </div>
          </div>
        </div>
      </details>`;
  }

  async function loadMarketSD(force) {
    if (state.shandong && !force) {
      renderSD(state.shandong);
      return;
    }
    try {
      const data = await api("/api/market/shandong");
      state.shandong = data.shandong || {};
    } catch (error) {
      state.shandong = {};
    }
    renderSD(state.shandong);
  }

  const MARKET_FRUIT = /(苹果|富士|梨|桃|李|杏|梅|橙|桔|橘|柑|柚|葡萄|草莓|樱桃|猕猴桃|枣|柿|菠萝|凤梨|香蕉|西瓜|哈密瓜|甜瓜|芒果|荔枝|龙眼|石榴|火龙果|柠檬|椰子|山楂|无花果|榴莲|杨梅|枇杷)/;
  const MARKET_VEG = /(菜|萝卜|土豆|马铃薯|番茄|西红柿|茄|黄瓜|冬瓜|丝瓜|苦瓜|南瓜|西葫芦|椒|葱|姜|蒜|豆|藕|薯|菌|菇|笋|芹|韭|菠菜|生菜|甘蓝|山药|芋|玉米|茭白|芦笋)/;
  function marketClass(name) {
    const text = String(name || "");
    if (MARKET_FRUIT.test(text)) return "fruit";
    if (MARKET_VEG.test(text)) return "veg";
    return "other";
  }

  function renderMarket(data) {
    if (!data) return;
    const weighInput = $("#marketWeight"), holdInput = $("#marketHold");
    if (weighInput && !weighInput.dataset.touched) weighInput.value = data.advice.weight_kg;
    if (holdInput && !holdInput.dataset.touched) holdInput.value = data.advice.hold_days;
    const PREFERRED = ["富士", "大白菜", "土豆", "黄瓜", "西红柿", "秋月梨", "鸭梨", "脐橙", "五常大米"];
    const all = (data.products || []).filter((p) => p.days >= 5);
    const names = (data.products || []).map((p) => p.name).filter(Boolean);
    const dl = $("#marketNames");
    if (dl) dl.innerHTML = names.map((n) => `<option value="${esc(n)}"></option>`).join("");
    all.sort((a, b) => {
      const ia = PREFERRED.indexOf(a.name), ib = PREFERRED.indexOf(b.name);
      if (ia !== ib) return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
      return b.days - a.days;
    });
    const currentName = String((data.stats || {}).product || "");
    const cls = marketClass(currentName);
    let pool = cls === "other" ? all.slice() : all.filter((p) => marketClass(p.name) === cls);
    if (pool.length < 5) pool = all.slice();
    if (currentName && !pool.some((p) => p.name === currentName)) {
      const self = all.find((p) => p.name === currentName);
      if (self) pool.unshift(self);
    }
    const tabs = pool.slice(0, 8);
    const tabHtml = tabs.map((p) => `<button type="button" class="m-tab ${p.name === data.stats.product ? "on" : ""}" data-market-product="${esc(p.name)}">${esc(p.name)}<em>${p.days} 天</em></button>`).join("");
    const tabsBox = $("#marketTabs");
    if (tabsBox) {
      const current = String(data.stats.product || "");
      const exists = tabs.some((p) => p.name === current);
      const mt = data.matched || {};
      const alias = mt.query && mt.name && mt.query !== mt.name ? `（按「${esc(mt.query)}」匹配）` : "";
      const head = `<span class="m-current">当前品种：<b>${esc(current)}</b>${esc(alias)}${state.marketDemo ? "（演示）" : ""}</span>`;
      tabsBox.innerHTML = head + (exists ? "" : `<span class="m-current-warn">该品种不在日报覆盖范围内</span>`);
    }
    const src = data.source || {};
    const ad = data.advice || {};
    $("#marketContent").innerHTML = `
      <div class="m-head">
        <div>
          <h2>${esc(data.stats.product)}<span class="m-sub">近 ${data.stats.days} 天 · ${data.stats.first_date} 至 ${data.stats.last_date} · ${number(data.stats.samples)} 条报价</span></h2>
          <p class="m-note">细线是当日均价，粗线是 7 日均线。同一品种不同规格、产地的报价价差很大，图顶部标注了区间。</p>
        </div>
        <div class="m-verdict ${ad.tone}"><span>建议</span><b>${esc(ad.action)}</b><em>${esc(MARKET_TONES[ad.tone] || "")}</em></div>
      </div>
      ${marketPriceChart(data.series)}
      <div class="m-stats">${marketStatCells(data.stats)}</div>
      <div class="m-cols">
        <section>
          <h3>为什么是这个建议</h3>
          <p class="m-reason">${esc(ad.reason)}</p>
          <ul class="m-rules">
            <li>近 7 天涨 ≥3% 且近 30 天不跌 → 持货等窗口</li>
            <li>近 7 天跌 ≥3% → 尽快出货</li>
            <li>周、月都在窄幅震荡 → 分批出货</li>
            <li>方向不一致 → 暂缓 7 天再算</li>
          </ul>
        </section>
        <section>
          <h3>现在卖 vs 入库 ${ad.hold_days} 天</h3>
          ${marketHoldTable(ad, ad.weight_kg)}
        </section>
      </div>
      <p class="m-source">数据来源：${esc(src.name || "北京新发地")} · 抓取于 ${esc((src.fetched_at || "").slice(0, 19))} · 原始接口 ${esc(src.url || "")}；${esc(data.notice || "")}</p>`;
  }

  function isAppleName(name) {
    return /(苹果|富士)/.test(String(name || ""));
  }

  function nameHit(a, b) {
    const x = String(a || "").replace(/[\s·（）()]/g, "");
    const y = String(b || "").replace(/[\s·（）()]/g, "");
    if (!x || !y) return false;
    return x.includes(y) || y.includes(x);
  }

  async function resolveMarketProduct() {
    if (state.marketPick) return state.marketPick;
    const current = state.currentBatch;
    const fromCurrent = current ? (current.name || (current.product || {}).name || "") : "";
    if (fromCurrent) return fromCurrent;
    if (!(state.batches || []).length) {
      try {
        const data = await api("/api/batches");
        state.batches = data.batches || data.items || [];
      } catch (error) {
        state.batches = [];
      }
    }
    const first = (state.batches || [])[0];
    if (first) return first.product_name || first.name || (first.product || {}).name || "";
    return "";
  }

  async function marketAlternatives(exclude) {
    try {
      const data = await api("/api/market/list");
      const names = (data.products || []).map((p) => p.name).filter((n) => n && n !== exclude);
      return names.slice(0, 8);
    } catch (error) {
      return [];
    }
  }

  function updateOtherVisibility() {
    const wrap = $("#marketOther");
    if (!wrap) return;
    const hasMoa = (() => { const el = $("#marketMOA"); return el && !el.hidden && el.innerHTML.trim() !== ""; })();
    const hasSd = (() => { const el = $("#marketSD"); return el && !el.hidden && el.innerHTML.trim() !== ""; })();
    wrap.hidden = !(hasMoa || hasSd);
  }

  async function loadOther() {
    await Promise.all([loadMoa(), loadMarketSD()]);
    updateOtherVisibility();
  }

  async function loadMarket(force) {
    if (state.market && !force) { renderMarket(state.market); loadYT(); loadOther(); return; }
    const box = $("#marketContent");
    if (box) box.innerHTML = `<div class="loading-block">正在读取行情…</div>`;
    const weight = Number($("#marketWeight")?.value || 500);
    const hold = Number($("#marketHold")?.value || 30);
    const wanted = await resolveMarketProduct();
    state.marketDemo = !wanted;
    state.marketProduct = wanted || "富士";
    try {
      const query = new URLSearchParams({ product: state.marketProduct, weight: String(weight), hold: String(hold) });
      const data = await api(`/api/market?${query.toString()}`);
      state.market = data;
      state.marketResolvedName = (data.stats && data.stats.product) || "";
      renderMarket(data);
      loadYT();
      loadOther();
    } catch (error) {
      state.market = null;
      const missing = String((error && error.message) || error).includes("暂无该产品");
      const moa = $("#marketMOA");
      if (moa) { moa.hidden = true; moa.innerHTML = ""; }
      loadYT();
      loadOther();
      if (box) {
        box.innerHTML = missing
          ? `<div class="empty-state">
               <strong>「${esc(state.marketProduct)}」没有公开的逐日行情。</strong>
               <p>北京新发地按品种日报，只覆盖部分农产品；烟台市发改委按周公布的水果品种也有限。该品种暂无数据，此处不显示其它品种的数据。</p>
             </div>`
          : `<div class="empty-state">行情读取失败：${esc(error.message || error)}</div>`;
      }
    }
  }

  const SEVERITY_LABELS = { blocker: "阻断", high: "高风险", medium: "需调整", low: "提示", notice: "说明" };

  function severityPill(value) {
    return `<span class="status-pill ${esc(value || "notice")}">${esc(SEVERITY_LABELS[value] || value || "说明")}</span>`;
  }

  function termChips(values, emptyText) {
    const items = (values || []).filter(Boolean);
    if (!items.length) return `<span class="chip-empty">${esc(emptyText)}</span>`;
    return items.map((item) => `<span class="term-chip">${esc(item)}</span>`).join("");
  }

  function ruleCard(rule) {
    return `<article class="rule-card ${esc(rule.severity || "notice")}">
      <div class="rule-head">
        <span class="rule-id">${esc(rule.id)}</span>
        <div class="rule-title"><strong>${esc(rule.name)}</strong><small>${esc(rule.category || "未分类")}</small></div>
        ${severityPill(rule.severity)}
      </div>
      <dl class="rule-fields">
        <div><dt>法规依据</dt><dd>${esc(rule.basis || "未注明")}</dd></div>
        <div><dt>触发表述</dt><dd class="chip-row">${termChips(rule.terms, "按语境判断，不靠关键词")}</dd></div>
        ${rule.context_note ? `<div><dt>语境提示</dt><dd>${esc(rule.context_note)}</dd></div>` : ""}
        <div><dt>整改建议</dt><dd>${esc(rule.advice || "删除该表述，或改为可核验的说法")}</dd></div>
      </dl>
    </article>`;
  }

  async function loadRules(force = false) {
    const content = $("#rulesContent");
    if (state.rules && !force) { renderRules(state.rules); return; }
    content.className = "loading-block";
    content.textContent = "正在读取规则库…";
    try {
      state.rules = await api("/api/rules");
      renderRules(state.rules);
    } catch (error) {
      content.innerHTML = emptyState(`规则库读取失败：${error.message}`);
    }
  }

  function renderRules(data) {
    const rules = data.rules || [];
    const sources = data.sources || [];
    $("#rulesViewLead").textContent = `规则库版本 ${data.version || "未标注"}，共 ${rules.length} 条规则，全部条目注明法规出处。`;
    $("#rulesCountPill").textContent = `${rules.length} 条规则`;
    $("#rulesSources").innerHTML = sources.map((source) => {
      const url = safeUrl(source.url);
      const label = esc(source.title || source.id || "来源");
      const note = esc(source.note || "");
      if (!url) return `<span class="source-chip" title="${note}">${label}</span>`;
      return `<a class="source-chip" href="${esc(url)}" target="_blank" rel="noopener noreferrer" title="${note}"><span>${label}</span><span class="chip-arrow" aria-hidden="true">↗</span></a>`;
    }).join("");
    const content = $("#rulesContent");
    content.className = "rule-grid";
    content.innerHTML = rules.length ? rules.map(ruleCard).join("") : emptyState("规则库为空");
  }

  function caseScenarioCard(item) {
    const meta = [item.id, item.product_id, item.prompt_version ? `提示词 ${item.prompt_version}` : ""].filter(Boolean);
    const rc = (label, value) => {
      if (!value) return "";
      if (Array.isArray(value)) {
        return `<div class="rc-block"><span class="rc-label">${esc(label)}</span><ol class="rc-steps">${value.map((s) => `<li>${esc(s)}</li>`).join("")}</ol></div>`;
      }
      return `<div class="rc-block"><span class="rc-label">${esc(label)}</span><p>${esc(String(value))}</p></div>`;
    };
    return `<article class="case-card run-case">
      <div class="case-head"><strong>${esc(item.title || "未命名用例")}</strong>${item.type ? `<span class="case-tag">${esc(item.type)}</span>` : ""}</div>
      ${item.why ? `<p class="case-why">${esc(item.why)}</p>` : ""}
      ${rc("输入", item.input)}
      ${rc("运行过程", item.process)}
      ${rc("最终输出", item.output)}
      ${rc("人工修改记录", item.manual_changes)}
      ${rc("验证结果", item.verification)}
      <div class="case-meta">${meta.map((value) => `<span>${esc(value)}</span>`).join("")}</div>
    </article>`;
  }

  function caseDocCard(item) {
    const url = safeUrl(item.url);
    const title = url
      ? `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(item.title || item.url)}</a>`
      : esc(item.title || "未命名快照");
    const meta = [item.host, item.product, item.fetched_at ? `抓取 ${dateText(item.fetched_at)}` : ""].filter(Boolean);
    const hash = item.sha256 ? `<span class="hash">SHA-256 ${esc(String(item.sha256).slice(0, 12))}…</span>` : "";
    return `<article class="case-card">
      <div class="case-head"><strong>${title}</strong>${item.source_level ? `<span class="case-tag">${esc(item.source_level)}</span>` : ""}</div>
      <p class="case-why">${esc(item.snippet || "暂无摘要")}</p>
      <div class="case-meta">${meta.map((value) => `<span>${esc(value)}</span>`).join("")}${hash}</div>
    </article>`;
  }

  async function loadCases(force = false) {
    if (!state.catalog || force) {
      $("#casesScenarios").innerHTML = `<div class="loading-block">正在读取案例库…</div>`;
      $("#casesDocs").innerHTML = "";
      try {
        state.catalog = await api("/api/cases");
      } catch (error) {
        $("#casesScenarios").innerHTML = emptyState(`案例库读取失败：${error.message}`);
        $("#casesViewLead").textContent = "案例库暂时不可用，请稍后刷新重试。";
        $("#casesCountPill").textContent = "读取失败";
        return;
      }
    }
    renderCases(state.catalog);
  }

  function renderCases(data) {
    const docs = data.documents || [];
    const scenarios = data.scenarios || [];
    $("#casesViewLead").textContent = `共 ${scenarios.length} 组运行案例（典型 / 复杂 / 边界）、${docs.length} 篇公开网页快照；案例可按五项复现，快照命中只作线索，引用前请复核原文。`;
    $("#casesCountPill").textContent = `${scenarios.length} 组案例`;
    $("#casesScenarios").innerHTML = scenarios.length ? scenarios.map(caseScenarioCard).join("") : emptyState("暂无典型场景用例");
    $("#casesDocs").innerHTML = docs.length ? docs.map(caseDocCard).join("") : emptyState("暂无公开网页快照");
  }
  async function loadBatch(id, targetView) {
    try {
      const result = await api(`/api/batches/${encodeURIComponent(id)}`);
      state.currentBatch = result.batch; state.currentDetail = result;
      const wantReport = targetView === "report" || ((result.batch.plans || []).length && !targetView);
      state.currentView = wantReport ? "report" : "batch";
      $$(".view").forEach((node) => { node.hidden = node.id !== `view-${state.currentView}`; });
      $$(".nav-item").forEach((button) => button.classList.toggle("active", button.dataset.view === state.currentView));
      if (wantReport) renderReport(result.batch); else renderBatch(result);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (error) { toast(error.message, "error"); }
  }
  function typeOptions(types, selected) {
    return Object.entries(types || {}).map(([key, item]) => `<option value="${esc(key)}" ${key === selected ? "selected" : ""}>${esc(item.label || key)}</option>`).join("");
  }
  function levelOptions(levels, selected) {
    return (levels || []).map((level) => `<option value="${esc(level)}" ${level === selected ? "selected" : ""}>${esc(level)}</option>`).join("");
  }
  function detailItem(label, value) {
    return `<div class="detail-item"><dt>${esc(label)}</dt><dd>${esc(value || "未填写")}</dd></div>`;
  }

  function evidenceCard(evidence) {
    const url = safeUrl(evidence.source_url);
    const attachment = safeUrl(evidence.attachment?.url || evidence.snapshot?.url || "");
    const hash = (evidence.snapshot && evidence.snapshot.sha256) || (evidence.attachment && evidence.attachment.sha256) || "";
    const status = evidence.status || "pending";
    return `
      <article class="evidence-card ${esc(status)}">
        <div class="evidence-head"><div><strong>${esc(evidence.label || evidence.type)}</strong><small>${esc(evidence.source_level || "未分级")} · ${esc(evidence.source_name || "未填写来源")}</small></div><span class="status-tag ${esc(status)}">${esc(EVIDENCE_STATUS[status] || status)}</span></div>
        <div class="evidence-body">
          <p>${esc((evidence.excerpt || evidence.detail || "暂无材料摘要").slice(0, 420))}</p>
          <div class="evidence-meta"><span>发布：${esc(evidence.published_at || "未填")}</span><span>抓取：${esc(dateText(evidence.fetched_at))}</span><span>有效期：${esc(evidence.expires_at || "未填")}</span><span>批次匹配：${evidence.matches_batch ? "是" : "待确认"}</span></div>
          ${url ? `<div class="evidence-meta"><a href="${esc(url)}" target="_blank" rel="noopener noreferrer">打开来源</a></div>` : ""}
          ${attachment ? `<div class="evidence-meta"><a href="${esc(attachment)}" target="_blank" rel="noopener noreferrer">查看附件</a></div>` : ""}
          ${hash ? `<div class="evidence-meta"><span class="hash">SHA-256 ${esc(hash)}</span></div>` : ""}
          ${evidence.verification_note ? `<p class="help">${esc(evidence.verification_note)}${evidence.verified_by ? ` · ${esc(evidence.verified_by)} ${esc(dateText(evidence.verified_at))}` : ""}</p>` : ""}
          <div class="evidence-actions">
            <button class="button small primary" type="button" data-verify="${esc(evidence.id)}" data-decision="verified">核验通过</button>
            <button class="button small ghost" type="button" data-verify="${esc(evidence.id)}" data-decision="conflict">标记冲突</button>
            <button class="button small ghost" type="button" data-verify="${esc(evidence.id)}" data-decision="rejected">驳回</button>
            ${evidence.origin !== "batch_form" ? `<button class="button small ghost" type="button" data-remove-evidence="${esc(evidence.id)}">移除</button>` : ""}
          </div>
        </div>
      </article>`;
  }

  function renderBatch(detail) {
    const batch = detail.batch || state.currentBatch;
    state.currentBatch = batch;
    const product = batch.product || {};
    const evidence = batch.evidence || [];
    const followups = detail.followups || [];
    const sources = batch.sources || [];
    const verified = evidence.filter((item) => item.status === "verified").length;
    const gates = batch.gate || {};
    $("#batchHeadingActions").innerHTML = `${modePill(batch.mode)}
      <button class="button ghost small" type="button" data-batch-action="switch-mode">切换模式</button>
      <button class="button primary small" type="button" data-batch-action="analyze">${(batch.plans || []).length ? "按当前模式重跑" : "生成方案"}</button>`;
    $("#batchContent").innerHTML = `
      <div class="batch-banner"><div><h2>${esc(product.name || "未命名批次")}</h2><p>${esc(batch.batch_code || batch.id)} · ${esc(product.organization || "")} · ${number(product.batch_weight_kg)} kg</p></div><div class="button-row">${statusPill(batch.status)}<button class="button ghost small" type="button" data-batch-action="report" ${(batch.plans || []).length ? "" : "disabled"}>查看报告</button></div></div>
      <div class="batch-layout"><div class="batch-main">
        <section class="card panel"><div class="panel-head"><div><h3>本批档案</h3><p>档案是本批事实边界，不等于第三方证书。</p></div><button class="text-button" type="button" data-batch-action="edit-product">修改档案</button></div>
          <dl class="detail-grid">
            ${detailItem("产品名", product.name)}${detailItem("品种 / 规格", [product.variety, product.spec].filter(Boolean).join(" · "))}
            ${detailItem("来源地址", product.origin_address)}${detailItem("提交单位", product.organization)}
            ${detailItem("本批重量", `${number(product.batch_weight_kg)} kg`)}${detailItem("期望售价", money(product.unit_price_yuan_per_kg) + "/kg")}
            ${detailItem("综合成本", money(product.unit_cost_yuan_per_kg) + "/kg")}${detailItem("运输工具", product.transport)}
            ${detailItem("储存条件", product.storage)}${detailItem("采摘 / 包装", [product.harvest_date, product.package_date].filter(Boolean).join(" / "))}
          </dl>
          ${(batch.photos || []).length ? `<div class="photo-preview" style="margin-top:12px">${batch.photos.map((photo) => `<div class="photo-thumb"><img src="${esc(photo.url)}" alt="${esc(photo.caption || "产品照片")}"></div>`).join("")}</div>` : ""}
        </section>
        <section class="card panel"><div class="panel-head"><div><h3>Agent 补问</h3><p>先补最影响证据门禁和渠道测算的信息。</p></div><span class="status-pill">${followups.length} 项待补充</span></div>
          ${followups.length ? `<ol class="followup-list">${followups.map((item, index) => `<li class="followup-item"><span class="num">${index + 1}</span><div><strong>${esc(item.question)}</strong><small>${esc(item.why)}</small></div><button class="button small ghost" type="button" data-followup="${esc(item.field)}" data-type="${esc(item.field)}">去补充</button></li>`).join("")}</ol>` : '<div class="hint-box">当前关键字段和证据类型已齐备，可继续核验证据或生成方案。</div>'}
        </section>
        <section class="card panel"><div class="panel-head"><div><h3>证据清单</h3><p>公开搜索只提供线索；核验必须对应主体、批次和有效期。</p></div><div class="summary-strip"><div class="summary-stat"><span>证据</span><strong>${evidence.length}</strong></div><div class="summary-stat"><span>已核验</span><strong>${verified}</strong></div><div class="summary-stat"><span>事实通过</span><strong>${number(gates.passed, 0)}</strong></div><div class="summary-stat"><span>被拦截</span><strong>${number(gates.blocked, 0)}</strong></div></div></div>
          <div class="button-row" style="margin-bottom:13px"><button class="button primary small" type="button" data-batch-action="add-evidence">手工补证</button><button class="button ghost small" type="button" data-batch-action="extract-url">提取网页</button></div>
          <div class="evidence-list">${evidence.map(evidenceCard).join("")}</div>
        </section>
        <section class="card panel"><div class="panel-head"><div><h3>公开来源线索</h3><p>搜索命中不等于事实通过；选择来源后仍需人工核验。</p></div></div>
          <div class="collection-box"><label class="field"><span>搜索关键词</span><input id="collectQuery" maxlength="200" value="${esc(product.name || "")}"></label><div class="button-row"><button class="button primary small" type="button" data-batch-action="collect">联网采集</button><span class="help">联网模式无需 API；结果会保存快照摘要与来源。</span></div></div>
          <p id="collectStatus" class="help" role="status"></p>
          <div class="source-list">${sources.length ? sources.slice().reverse().map((source) => {
            const sourceUrl = safeUrl(source.url);
            return `<article class="source-item"><div class="source-item-head"><div><strong>${esc(source.title || "未命名来源")}</strong><small>${esc(source.source_level || "")} · 建议类型 ${esc(source.suggested_type || "待选择")}${source.origin === "case_db" ? " · 案例库缓存" : ""}</small></div><button class="button small ghost" type="button" data-source-id="${esc(source.id)}" data-source-type="${esc(source.suggested_type || "ORIGIN_PROOF")}">加入证据</button></div><p>${esc((source.snippet || "").slice(0, 300))}</p>${sourceUrl ? `<a class="source-url" href="${esc(sourceUrl)}" target="_blank" rel="noopener noreferrer">${esc(sourceUrl)}</a>` : ""}</article>`;
          }).join("") : '<div class="empty-state">还没有公开来源。可以联网采集，也可以直接手工补证。</div>'}</div>
        </section>
      </div><aside class="batch-side">
        <section class="card panel"><div class="panel-head"><div><h3>当前分析模式</h3><p>切换后旧结果暂停，需按新模式重新分析。</p></div></div>${modePill(batch.mode)}<p class="help">${batch.mode === "agent" ? "Agent 只做语言与长尾辅助，证据门禁、渠道计算和合规规则仍在本地执行。" : "联网模式完全不调用模型 API，先查本地案例库再检索公开网页，由本地规则和模板完成分析。"}</p><button class="button ghost small" type="button" data-batch-action="switch-mode">切换为${batch.mode === "agent" ? "联网模式" : "Agent 模式"}</button></section>
        <section class="card panel"><div class="panel-head"><div><h3>证据缺口</h3><p>缺口会直接阻断相关宣传语句。</p></div></div><div class="gap-list">${(gates.gaps || []).length ? gates.gaps.map((gap) => `<span class="status-tag pending">${esc(gap.label)} (${number(gap.blocked_claims, 0)})</span>`).join("") : '<span class="status-tag pass">暂无汇总缺口</span>'}</div></section>
        <section class="card panel"><div class="panel-head"><div><h3>操作时间线</h3><p>关键行为留痕。</p></div></div><ol class="timeline">${(batch.timeline || []).slice().reverse().slice(0, 12).map((item) => `<li><strong>${esc(item.action)}</strong><small>${esc(dateText(item.at))} · ${esc(item.detail || "")}</small></li>`).join("")}</ol></section>
      </aside></div>`;
  }

  function openEditProduct() {
    const p = (state.currentBatch && state.currentBatch.product) || {};
    openModal("修改本批档案", "保存后请按当前模式重新分析", `
      <form id="editProductForm" class="form-stack"><div class="form-2">
        <label class="field"><span>产品名</span><input name="name" required maxlength="80" value="${esc(p.name || "")}"></label>
        <label class="field"><span>来源地址</span><input name="origin_address" required maxlength="240" value="${esc(p.origin_address || "")}"></label>
        <label class="field"><span>公司或单位</span><input name="organization" required maxlength="120" value="${esc(p.organization || "")}"></label>
        <label class="field"><span>本批重量（kg）</span><input name="batch_weight_kg" type="number" min=".01" step=".01" required value="${esc(p.batch_weight_kg || "")}"></label>
        <label class="field"><span>品种</span><input name="variety" value="${esc(p.variety || "")}"></label>
        <label class="field"><span>等级 / 规格</span><input name="spec" value="${esc(p.spec || "")}"></label>
        <label class="field"><span>期望售价（元/kg）</span><input name="unit_price_yuan_per_kg" type="number" min="0" step=".01" value="${esc(p.unit_price_yuan_per_kg ?? "")}"></label>
        <label class="field"><span>综合成本（元/kg）</span><input name="unit_cost_yuan_per_kg" type="number" min="0" step=".01" value="${esc(p.unit_cost_yuan_per_kg ?? "")}"></label>
        <label class="field"><span>运输工具</span><input name="transport" value="${esc(p.transport || "")}"></label>
        <label class="field"><span>储存条件</span><input name="storage" value="${esc(p.storage || "")}"></label>
        <label class="field"><span>运输能力（kg/次）</span><input name="transport_capacity_kg" type="number" min="0" step=".01" value="${esc(p.transport_capacity_kg ?? "")}"></label>
        <label class="field"><span>日发货能力（kg）</span><input name="daily_capacity_kg" type="number" min="0" step=".01" value="${esc(p.daily_capacity_kg ?? "")}"></label>
      </div><div id="modalError" class="danger-box" hidden></div><div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">保存档案</button></div></form>`);
    $("#editProductForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true);
      try {
        const form = event.currentTarget; const product = {};
        for (const element of form.elements) {
          if (!element.name) continue;
          product[element.name] = element.type === "number" && element.value === "" ? null : (element.type === "number" ? Number(element.value) : element.value.trim());
        }
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}`, { method: "POST", body: { product } });
        closeModal(); state.currentBatch = result.batch;
        await loadBatch(result.batch.id, "batch"); toast("档案已保存，请重新分析");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }
  function openEvidenceModal(prefill = {}) {
    const detail = state.currentDetail || {};
    const types = detail.evidence_types || {};
    const levels = detail.source_levels || ["政府/主管部门", "标准/行业机构", "检测/认证机构", "平台公开数据", "企业/合作社自述", "其他公开来源"];
    openModal("手工补充证据", "材料会保存哈希；提交后仍需人工核验", `
      <form id="evidenceForm" class="form-stack"><div class="form-2">
        <label class="field"><span>证据类型</span><select name="type" required>${typeOptions(types, prefill.type || "ORIGIN_PROOF")}</select></label>
        <label class="field"><span>来源等级</span><select name="source_level">${levelOptions(levels, prefill.source_level || "企业/合作社自述")}</select></label>
        <label class="field"><span>出具单位 / 来源名称</span><input name="source_name" required maxlength="180" value="${esc(prefill.source_name || "")}"></label>
        <label class="field"><span>来源链接</span><input name="source_url" type="url" maxlength="2048" value="${esc(prefill.source_url || "")}" placeholder="https://..."></label>
        <label class="field"><span>发布日期</span><input name="published_at" type="date" value="${esc(prefill.published_at || "")}"></label>
        <label class="field"><span>有效期至</span><input name="expires_at" type="date" value="${esc(prefill.expires_at || "")}"></label>
      </div><label class="field"><span>材料内容摘要</span><textarea name="detail" required maxlength="4000" rows="5" placeholder="写明证书编号、检测结论、适用主体和批次等">${esc(prefill.detail || "")}</textarea></label>
      <label class="checkbox-row"><input name="matches_batch" type="checkbox" ${prefill.matches_batch ? "checked" : ""}> 我已确认该材料对应本批次（仍须人工复核）</label>
      <label class="field"><span>原件附件（JPG / PNG / WebP / PDF，≤4MB）</span><input id="evidenceFile" type="file" accept="image/jpeg,image/png,image/webp,application/pdf"></label>
      <div id="modalError" class="danger-box" hidden></div><div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">保存为待核验证据</button></div></form>`);
    $("#evidenceForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const form = event.currentTarget; const button = event.submitter; setBusy(button, true);
      try {
        const body = {};
        for (const element of form.elements) if (element.name && element.type !== "file" && element.type !== "checkbox") body[element.name] = element.value;
        body.matches_batch = form.elements.matches_batch.checked;
        const file = $("#evidenceFile").files[0];
        if (file) {
          if (file.size > 4 * 1024 * 1024) throw new Error("附件不能超过 4MB");
          body.attachment = await readFileAsDataUrl(file); body.attachment_name = file.name;
        }
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/evidence`, { method: "POST", body });
        closeModal(); state.currentBatch = result.batch;
        await loadBatch(result.batch.id, "batch"); toast("证据已保存，请完成核验");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }
  function planCard(plan) {
    const economics = plan.economics || {};
    const assumptions = plan.assumptions || [];
    return `
      <article class="plan-card ${plan.is_best ? "best" : "alt"}">
        <div class="plan-rank"><span>${plan.is_best ? "最优方案" : "次优方案"} · 第 ${number(plan.rank, 0)} 名</span><strong>${number(plan.score, 1)} 分</strong></div>
        <h3>${esc(plan.channel_name || "未命名渠道")}</h3>
        <p class="plan-buyer">${esc(plan.buyer || "")}</p>
        <div class="plan-number">
          <div><span>预计收入</span><strong>${money(economics.revenue)}</strong></div>
          <div><span>情景利润</span><strong>${money(economics.profit)}</strong></div>
          <div><span>利润率</span><strong>${number(economics.margin, 1)}%</strong></div>
          <div><span>能力匹配</span><strong>${number(plan.capability_match, 0)}%</strong></div>
        </div>
        <ul class="plan-list">
          <li>利润区间 ${money(economics.profit_low)}–${money(economics.profit_high)}</li>
          <li>沟通方式：${esc(plan.communication || "待补充")}</li>
          <li>证据缺口：${(plan.evidence_missing || []).length ? esc(evidenceNames(plan.evidence_missing)) : "当前未见汇总缺口"}</li>
        </ul>
        <details class="plan-details"><summary>展开执行步骤与风险</summary><div>
          <h4>执行步骤</h4><ol class="plan-list">${(plan.execution_steps || []).map((step) => `<li>${esc(step)}</li>`).join("")}</ol>
          <h4>风险与边界</h4><ul class="plan-list">${[...(plan.risk_notes || []), ...assumptions].map((item) => `<li>${esc(item)}</li>`).join("")}</ul>
        </div></details>
      </article>`;
  }

  function claimRow(claim) {
    const passed = claim.gate === "PASS";
    return `<div class="claim-item ${passed ? "pass" : "block"}"><p>${esc(claim.claim || "")}</p><small>${passed ? "已通过证据门禁" : `被拦截：${esc(evidenceNames(claim.missing_evidence) || "证据不足")}`}</small></div>`;
  }

  const AUDIT_ACTIONS = {
    "auth.login": "登录",
    "auth.logout": "退出登录",
    "auth.register": "注册账号",
    "auth.password_change": "修改密码",
    "admin.password_reset": "管理员重置密码",
    "admin.user_update": "管理员修改账号",
    "admin.settings_update": "管理员修改平台设置",
    "api.user_config": "保存模型 API 配置",
    "batch.create": "新建批次",
    "batch.update": "更新批次",
    "batch.export": "导出批次",
    "analysis.complete": "生成方案与内容",
    "compliance.review_requested": "发起合规审查",
    "evidence.add": "新增证据",
    "evidence.remove": "删除证据",
    "evidence.verify": "核验证据",
    "photo.add": "上传产品照片"
  };

  function auditAction(action) {
    const raw = String(action || "");
    return AUDIT_ACTIONS[raw] || raw.replace(/\./g, " · ");
  }

  function hitSamples(hit) {
    const term = hit.matched || "";
    const raw = (hit.samples || []).slice(0, 4);
    if (!raw.length) return "";
    let shown = 0;
    const rows = raw.map((item) => {
      const text = typeof item === "string" ? item : (item && item.text) || "";
      const dup = typeof item === "string" ? 1 : Math.max(1, Number((item && item.count) || 1));
      shown += dup;
      const safe = esc(text);
      const marked = term ? safe.split(esc(term)).join(`<mark>${esc(term)}</mark>`) : safe;
      const tail = dup > 1 ? ` <em class="hit-dup">×${dup}</em>` : "";
      return `<li>${marked}${tail}</li>`;
    }).join("");
    const rest = Math.max(0, Number(hit.occurrences || 0) - shown);
    const more = rest > 0 ? `<li class="more">另有 ${rest} 处未展开</li>` : "";
    return `<ol class="hit-samples">${rows}${more}</ol>`;
  }

  function hitRow(hit) {
    const count = hit.occurrences > 1 ? `${hit.occurrences} 处` : "1 处";
    return `<details class="hit"><summary><strong>[${esc(LEVEL_LABELS[hit.severity] || hit.severity || "提示")}] ${esc(hit.rule_name || "合规风险")}</strong> · “${esc(hit.matched || "")}”${hit.occurrences > 1 ? ` <em class="hit-count">文中 ${hit.occurrences} 处</em>` : ""}</summary>
        <div class="hit-body">
          <div class="hit-kv"><span>规则</span><b>${esc(hit.rule_id || "")} · ${esc(hit.rule_name || "")}${hit.category ? ` · ${esc(hit.category)}` : ""}</b></div>
          <div class="hit-kv"><span>依据</span><b>${esc(hit.basis || "本地规则")}</b></div>
          <div class="hit-kv"><span>命中</span><b>“${esc(hit.matched || "")}” 共 ${esc(count)}</b></div>
          ${hit.evidence_note ? `<div class="hit-kv"><span>证据</span><b>${esc(hit.evidence_note)}</b></div>` : ""}
          ${hitSamples(hit)}
          <div class="hit-kv"><span>建议</span><b>${esc(hit.advice || hit.why || "请调整该表述。")}</b></div>
          ${hit.context_note ? `<div class="hit-kv"><span>语境</span><b>${esc(hit.context_note)}</b></div>` : ""}
        </div></details>`;
  }

  function complianceBlock(batch) {
    const review = batch.compliance || {};
    const level = review.level || "pass";
    const override = review.manual_override;
    return `
      <section class="compliance-card ${esc(level)}">
        <div class="compliance-head"><div><h3>合规审查 · ${esc(review.level_text || LEVEL_LABELS[level] || "待审查")}</h3><p>本地规则版本 ${esc(review.ruleset_version || "未记录")}，评分 ${number(review.score, 0)} / 100</p></div><span class="status-tag ${level === "pass" ? "pass" : level === "medium" ? "pending" : "rejected"}">${esc(LEVEL_LABELS[level] || level)}</span></div>
        ${(review.hits || []).length ? `<div class="hit-list">${review.hits.map(hitRow).join("")}</div>` : '<div class="hint-box">本地规则未发现命中项。仍须由发布责任人完成事实与场景复核。</div>'}
        ${review.agent_review ? `<p class="help">Agent 长尾复核：${review.agent_review.ok ? `完成 · ${esc(review.agent_review.model || "")}` : `未完成 · ${esc(review.agent_review.error || "可切换联网模式重试")}`}</p>` : ""}
        ${override ? `<div class="override-note">已由 ${esc(override.by || "")} 于 ${esc(dateText(override.at))} 强制放行。理由：${esc(override.reason || "")}</div>` : ""}
        ${["blocker", "high"].includes(level) && !override && !isGuest() && state.me?.features?.manual_override_enabled ? `<div class="button-row report-gap"><button class="button small ghost" type="button" data-report-action="override">提交复核说明（保持拦截）</button></div>` : ""}
      </section>`;
  }

  function benchSources(plans) {
    const seen = {};
    const items = [];
    plans.forEach((plan) => {
      const list = (plan.benchmark || {}).sources || [];
      list.forEach((src) => {
        const key = (src.url || "") + (src.title || "");
        if (!src.title || seen[key]) return;
        seen[key] = true;
        items.push(`<li>${src.url ? `<a href="${safeUrl(src.url)}" target="_blank" rel="noreferrer">${esc(src.title)}</a>` : esc(src.title)}${src.publisher ? ` · ${esc(src.publisher)}` : ""}${src.year ? ` · ${esc(src.year)}` : ""}</li>`);
      });
    });
    if (!items.length) return "";
    return `<details class="bench-src"><summary>数据来源（${items.length}）</summary><ul>${items.join("")}</ul></details>`;
  }


  function claimHeadline(batch, claim) {
    const p = batch.product || {};
    const text = (claim && claim.claim) || "";
    const origin = (p.origin || "").trim();
    const variety = (p.variety || "").trim();
    const spec = (p.spec || "").trim();
    const storage = (p.storage || "").trim();
    if (/地理标志|产地|原产|行政区域|栖霞|烟台/.test(text)) {
      return `${origin || "产地"}可查 · 地理标志可引`;
    }
    if (/品种|规格|果径|等级|分级/.test(text)) {
      return [variety || "品种", spec || "标准化分级"].join(" · ");
    }
    if (/储存|冷藏|冷链|运输|库存/.test(text)) {
      return `冷链可追 · ${storage || "温控与仓储有记录"}`;
    }
    if (/重量|批次|合作社|档案|提交/.test(text)) {
      const kg = number(p.batch_weight_kg || batch.batch_weight_kg, 0);
      return kg && kg !== "0" ? `${kg} kg 一批 · 档案可查` : "一批一档 · 来源可查";
    }
    return text.length > 18 ? `${text.slice(0, 18)}…` : text;
  }

  function boardClaimRow(batch, claim, seen) {
    const passed = claim.gate === "PASS";
    const missing = evidenceNames(claim.missing_evidence);
    const raw = (claim.claim || "").trim();
    let headline = batch ? claimHeadline(batch, claim) : raw;
    if (seen && seen[headline]) headline = `${raw.slice(0, 22)}…`;
    if (seen) seen[headline] = true;
    return `<div class="b-claim ${passed ? "ok" : "gap"}">
      <div class="t">${esc(headline)}</div>
      ${(raw && headline.trim() !== raw && !headline.trim().startsWith(raw.slice(0, 10))) ? `<div class="d">${esc(raw)}</div>` : ""}
      <div class="d2">${passed ? "已通过事实门禁，可进入对外正文" : `缺证据：${esc(missing || "待补充材料")}`}</div>
      <div class="e"><div class="bar"><i style="width:${passed ? 100 : 32}%"></i></div><span>${passed ? "证据完整" : "证据待补"}</span>${claim.risk ? `<span>· ${esc(claim.risk)}</span>` : ""}</div>
    </div>`;
  }

  function decisionBoard(batch, selected, plans) {
    const eco = selected.economics || {};
    const costs = selected.costs || {};
    const claims = batch.claims || [];
    const evidence = batch.evidence || [];
    const review = batch.compliance || {};
    const hits = review.hits || [];
    const needFix = hits.filter((hit) => ["blocker", "high"].includes(hit.severity));
    const passed = claims.filter((claim) => claim.gate === "PASS");
    const mainClaim = passed[0] || claims[0] || null;
    const verified = evidence.filter((item) => item.status === "VERIFIED" || item.verified_at);
    const roi = costs.total && eco.profit !== undefined ? (Number(eco.profit) / Number(costs.total)) : null;
    const product = batch.product || {};
    const showEvidence = evidence.slice(0, 4);
    const sortKey = state.channelSort || "profit";
    const ranked = plans.slice().sort((a, b) => {
      const ea = a.economics || {}; const eb = b.economics || {};
      if (sortKey === "margin") return (Number(eb.margin) || 0) - (Number(ea.margin) || 0);
      if (sortKey === "gate") return ((a.evidence_missing || []).length - (b.evidence_missing || []).length) || ((Number(eb.profit) || 0) - (Number(ea.profit) || 0));
      return (Number(eb.profit) || 0) - (Number(ea.profit) || 0);
    });
    const guardText = needFix.length ? `发布前护栏 · ${needFix.length} 处需改` : "发布前护栏 · 未见高风险表述";
    const nextStep = (batch.gate || {}).blocked ? "补证" : ((batch.compliance || {}).level === "pass" ? "出稿" : "复核");
    const __seen = {};
    return `
      <section class="board">
        <div class="answer-row">
          <div>
            <div class="lab">建议主打卖点</div>
            <div class="val">${mainClaim ? esc(claimHeadline(batch, mainClaim)) : "待补充主张"}${mainClaim && mainClaim.gate === "PASS" ? '<span class="tag ok">证据充分</span>' : '<span class="tag warn">证据待补</span>'}</div>
            <div class="note">${number(gate0(batch), 0)} 条主张通过门禁 · 证据已核验 ${number(verified.length, 0)} / ${number(evidence.length, 0)}</div>
          </div>
          <div>
            <div class="lab">主战场</div>
            <div class="val">${esc(selected.channel_name || "待测算")}</div>
            <div class="note">${esc(selected.buyer || "目标买家待补充")} · 能力匹配 ${number(selected.capability_match, 0)}%</div>
          </div>
          <div>
            <div class="lab">测算 ROI · 总成本 ${money(costs.total)}</div>
            <div class="val big">${roi === null ? "—" : number(roi, 1)}<span>倍</span></div>
            <div class="note">情景利润 ${money(eco.profit)}（${money(eco.profit_low)}–${money(eco.profit_high)}）· 模型假设，非承诺</div>
          </div>
        </div>

        <div class="board-cols">
          <section>
            <div class="colhead"><div class="lab">01 · 说什么</div><div class="hint">${number(passed.length, 0)} / ${number(claims.length, 0)} 可用</div></div>
            ${claims.length ? claims.map((claim) => boardClaimRow(batch, claim, __seen)).join("") : emptyState("暂无主张记录")}
          </section>

          <section>
            <div class="colhead"><div class="lab">02 · 在哪说</div><div class="ch-sort"><button type="button" data-chsort="profit" class="${state.channelSort === "profit" ? "on" : ""}">按利润</button><button type="button" data-chsort="margin" class="${state.channelSort === "margin" ? "on" : ""}">按利润率</button><button type="button" data-chsort="gate" class="${state.channelSort === "gate" ? "on" : ""}">按门槛</button></div></div>
            <div class="ch-list">
            ${ranked.map((plan, index) => { const e2 = plan.economics || {}; const req = (plan.requirements || []).join("、"); const ev = evidenceNames(plan.evidence_required || []); const steps = (plan.execution_steps || []).slice(0, 3); return `<details class="ch${plan.is_best ? " rec" : ""}">
              <summary><span class="rk">${index + 1}</span><span class="nm">${esc(plan.channel_name || "")}${plan.is_best ? '<span class="mini">最优</span>' : (plan.is_alternative ? '<span class="mini alt">次优</span>' : "")}</span><span class="pv">${money(e2.unit_price)}</span><span class="pf">${money(e2.profit)}</span><span class="pm">${number(e2.margin, 1)}%</span></summary>
              <div class="ch-body">
                <div class="kv"><span>买家</span><b>${esc(plan.buyer || "—")}</b></div>
                <div class="kv"><span>门槛</span><b>${esc(req || "无特殊门槛")}</b></div>
                <div class="kv"><span>要有证据</span><b>${esc(ev || "本批现有证据即可")}</b></div>
                <div class="kv"><span>沟通</span><b>${esc(plan.communication || "—")}</b></div>
                ${steps.length ? `<div class="kv"><span>步骤</span><b>${steps.map((step, i2) => `${i2 + 1}. ${esc(String(step))}`).join("<br>")}</b></div>` : ""}
              </div>
            </details>`; }).join("")}
            </div>
            <div class="board-foot">售价 / 利润 / 利润率：情景测算，不构成销量或收益承诺</div>
          </section>

          <section>
            <div class="colhead"><div class="lab">03 · 凭什么</div><div class="hint">证据 ${number(evidence.length, 0)} 条</div></div>
            <div class="board-metrics">
              <div><span>售价</span><b>${money(eco.unit_price)}<em>/kg</em></b></div>
              <div><span>总成本</span><b>${money(costs.total)}</b></div>
              <div><span>本批重量</span><b>${number(product.batch_weight_kg || batch.batch_weight_kg, 0)}<em>kg</em></b></div>
              <div><span>利润率</span><b>${number(eco.margin, 1)}<em>%</em></b></div>
            </div>
            <div class="board-ev">
              ${showEvidence.map((item) => `<div class="row"><span class="s">${esc((item.source_level || "证").slice(0, 1))}</span><span><span class="tt">${esc(item.label || item.source_name || "证据")}</span><span class="mm">${esc(item.source_level || "来源待补")} · ${item.status === "VERIFIED" ? "已核验" : "待核验"}</span></span></div>`).join("") || emptyState("暂无证据材料")}
              ${(selected.evidence_missing || []).length ? `<div class="row miss"><span class="s">!</span><span><span class="tt">缺证据：${esc(evidenceNames(selected.evidence_missing))}</span><span class="mm">补齐后相关主张才能进入正文</span></span></div>` : ""}
            </div>
          </section>
        </div>

        <section class="guard-row">
          <span class="flag ${needFix.length ? "bad" : "ok"}">${guardText}</span>
          ${needFix.slice(0, 2).map((hit) => `<span class="item"><b>「${esc(hit.matched || hit.rule_name || "")}」</b><code>${esc(hit.rule_name || "")} · ${esc(hit.basis || "本地规则")}</code></span>`).join("")}
          <span class="ok">下一步：${esc(nextStep)}</span>
        </section>
      </section>`;
  }

  function gate0(batch) {
    return (batch.gate || {}).passed || 0;
  }

  function rhythmBlock(batch) {
    const created = new Date(batch.created_at || Date.now());
    const month = created.getMonth() + 1;
    const phases = [
      { d: "第 1–2 周", n: "预热 · 产地实拍", x: "拍产地、挂树、采摘与分级过程；先积累同城流量，不急着报价。" },
      { d: "第 3–5 周", n: "爆发 · 主渠道放量", x: "主战场集中投放与上架，把已核验的证据做成详情页与口播。" },
      { d: "第 6–8 周", n: "复购 · 社群与礼盒", x: "老客社群发复购券，节庆档期做礼盒装，主打地理标志与批次可查。" },
    ];
    const note = month >= 9 && month <= 11 ? "当前处于产季爆发期，预热可压缩到 1 周。" : (month >= 12 || month <= 2 ? "处于节庆档期，礼盒与团购优先。" : "处于淡季蓄水期，重点做内容与证据沉淀。");
    return `
      <section class="rhythm-row">
        <div class="rhythm-label">
          <div class="lab">04 · 什么时候说</div>
          <div class="rhythm-note">${esc(note)}</div>
        </div>
        <div class="rhythm-steps">
          ${phases.map((phase, index) => `<div class="rhythm-step ${index === 0 ? "now" : ""}"><div class="d">${esc(phase.d)}</div><div class="n">${esc(phase.n)}</div><div class="x">${esc(phase.x)}</div></div>`).join("")}
        </div>
      </section>`;
  }

  function decisionHead(batch) {
    const product = batch.product || {};
    const meta = [product.spec, product.variety, product.batch_weight_kg ? `${number(product.batch_weight_kg, 0)} kg` : "", product.unit_cost_yuan_per_kg ? `成本 ${money(product.unit_cost_yuan_per_kg)}/kg` : "", product.unit_price_yuan_per_kg ? `期望售价 ${money(product.unit_price_yuan_per_kg)}/kg` : ""].filter(Boolean);
    return `
      <header class="decision-head">
        <div class="crumb"><span>传播任务</span><span class="sep">/</span><span>${esc(product.name || "未命名产品")}</span><span class="tag">决策中</span></div>
        <div class="decision-title">
          <div>
            <h1>${esc(product.name || "未命名产品")}${product.variety ? ` · ${esc(product.variety)}` : ""}</h1>
            <p class="decision-meta">${meta.length ? meta.map((item) => `<span>${esc(item)}</span>`).join('<i>·</i>') : "档案信息待补充"}</p>
          </div>
          <div class="decision-actions">
            <button class="button ghost small" type="button" data-trace-open="${esc(batch.id)}">公开溯源页</button>
            <button class="button ghost small" type="button" data-copy-content="detail_page">复制方案</button>
            <button class="button ghost small" type="button" data-report-action="export-md">导出</button>
            <button class="button primary small" type="button" data-report-action="export-json">生成内容包</button>
          </div>
        </div>
      </header>`;
  }

  function renderReport(batch) {
    if (!batch || !(batch.plans || []).length) {
      $("#reportHeadingActions").innerHTML = "";
      $("#reportContent").innerHTML = emptyState("这个批次还没有生成方案。请先回到批次任务，在补问和证据处理后生成方案。");
      return;
    }
    state.currentBatch = batch;
    const plans = batch.plans || [];
    const selected = plans.find((plan) => plan.id === batch.selected_plan_id) || plans.find((plan) => plan.is_best) || plans[0];
    const alternatives = plans.filter((plan) => plan.is_alternative).slice(0, 2);
    const analysis = batch.channel_analysis || {};
    const gate = batch.gate || {};
    const claims = batch.claims || [];
    const content = batch.content || {};
    const feedback = batch.feedback || {};
    const factGuard = batch.fact_guard || content.fact_guard || {};
    $("#reportHeadingActions").innerHTML = `${modePill(batch.mode)}
      <button class="button ghost small" type="button" data-report-action="back-batch">返回批次任务</button>
      <button class="button ghost small" type="button" data-report-action="rerun">按当前模式重跑</button>
      <button class="button primary small" type="button" data-report-action="export-md" ${feature("export_enabled") ? "" : "disabled"}>导出 Markdown</button>`;
    $("#reportContent").innerHTML = `
      ${decisionHead(batch)}
      ${decisionBoard(batch, selected, plans)}
      ${rhythmBlock(batch)}
      <h2 class="detail-title">详细分析 · 数据与过程</h2>
      <div class="report-grid">
        

        <section class="card panel"><div class="panel-head"><div><h3>推荐方案</h3><p>${esc(analysis.selection_note || "按净利润、证据完整度、能力匹配与执行复杂度综合排序。")}</p></div><span class="mode-pill">共测算 ${plans.length} 条渠道</span></div>
          <div class="plan-stack">${[selected, ...alternatives].filter(Boolean).map(planCard).join("")}</div>
        </section>

        <section class="card panel"><div class="panel-head"><div><h3>全部渠道明细</h3><p>渠道系数为演示模型假设，非实时市场报价；展示收入、成本、利润区间、证据缺口和能力匹配。</p></div></div>
          <div class="channel-table-wrap"><table class="channel-table"><thead><tr><th>排名 / 渠道</th><th>售价</th><th>收入</th><th>总成本</th><th>情景利润</th><th>利润率</th><th>证据缺口</th><th>能力匹配</th></tr></thead><tbody>
          ${plans.map((plan) => { const eco = plan.economics || {}; const costs = plan.costs || {}; return `<tr class="${plan.is_best ? "best-row" : ""}"><td><strong>${number(plan.rank, 0)}. ${esc(plan.channel_name)}</strong><small>${esc(plan.buyer || "")}</small></td><td>${money(eco.unit_price)}/kg</td><td>${money(eco.revenue)}</td><td>${money(costs.total)}</td><td>${money(eco.profit)}<small>${money(eco.profit_low)}–${money(eco.profit_high)}</small></td><td>${number(eco.margin, 1)}%</td><td>${esc(evidenceNames(plan.evidence_missing) || "无汇总缺口")}</td><td>${number(plan.capability_match, 0)}%</td></tr>`; }).join("")}
          </tbody></table></div>
        </section>

        <section class="card panel"><div class="panel-head"><div><h3>事实门禁</h3><p>只有通过门禁的事实才能进入对外正文；证据不足时会阻断相关主张。</p></div><span class="status-pill">${number(gate.passed, 0)} 条可发布</span></div>
          <div class="gate-grid"><div class="gate-summary"><span>事实通过率</span><strong>${number((gate.summary || {}).pass_rate, 0)}%</strong><p>共检查 ${number((gate.summary || {}).total, 0)} 条主张。缺口会同时影响渠道证据建议。</p></div><div class="claim-list">${claims.length ? claims.map(claimRow).join("") : emptyState("暂无主张记录，请重新分析。")}</div></div>
          ${factGuard.issues && factGuard.issues.length ? `<div class="warning-box report-gap">事实约束发现 ${factGuard.issues.length} 个潜在新增信息，已保留供人工复核。</div>` : ""}
        </section>

        <section class="card panel"><div class="panel-head"><div><h3>传播文案编辑</h3><p>可人工调整。保存后会立即重新执行本地事实门禁与合规审查。</p></div><span class="status-pill">${esc(content.source === "agent" ? content.model || "Agent" : "本地合规模板")}</span></div>
          <form id="contentForm" class="content-editor">
            <label><span>商品详情页 <small>${number((content.detail_page || "").length, 0)} 字</small></span><textarea class="tall" name="detail_page" maxlength="8000" required>${esc(content.detail_page || "")}</textarea></label>
            <label><span>口播稿 <small>${number((content.oral_script || "").length, 0)} 字</small></span><textarea name="oral_script" maxlength="8000" required>${esc(content.oral_script || "")}</textarea></label>
            <label><span>社群图文 <small>${number((content.social_post || "").length, 0)} 字</small></span><textarea name="social_post" maxlength="8000" required>${esc(content.social_post || "")}</textarea></label>
            <div class="button-row"><button class="button primary small" type="submit">保存并重新审查</button><button class="button ghost small" type="button" data-copy-content="detail_page">复制商品页</button><button class="button ghost small" type="button" data-copy-content="oral_script">复制口播</button><button class="button ghost small" type="button" data-copy-content="social_post">复制社群文案</button></div>
          </form>
        </section>

        ${complianceBlock(batch)}

        <section class="card panel"><div class="panel-head"><div><h3>销售结果回填</h3><p>用于复盘推荐是否成立；不会改写本批历史测算。</p></div></div>
          <form id="feedbackForm" class="feedback-grid">
            <label class="field"><span>实际渠道</span><select name="channel_code">${plans.map((plan) => `<option value="${esc(plan.channel_code)}" ${feedback.channel_code === plan.channel_code ? "selected" : ""}>${esc(plan.channel_name)}</option>`).join("")}</select></label>
            <label class="field"><span>售出（kg）</span><input name="sold_kg" type="number" min="0" step=".01" value="${esc(feedback.sold_kg ?? "")}"></label>
            <label class="field"><span>收入（元）</span><input name="revenue_yuan" type="number" min="0" step=".01" value="${esc(feedback.revenue_yuan ?? "")}"></label>
            <label class="field"><span>退货（kg）</span><input name="returns_kg" type="number" min="0" step=".01" value="${esc(feedback.returns_kg ?? "")}"></label>
            <label class="field"><span>利润（元）</span><input name="profit_yuan" type="number" step=".01" value="${esc(feedback.profit_yuan ?? "")}"></label>
            <label class="field span-2"><span>复盘备注</span><textarea name="notes" maxlength="1000" rows="2" placeholder="实际询价、退货原因、履约问题等">${esc(feedback.notes || "")}</textarea></label>
            <div class="feedback-submit"><button class="button primary small" type="submit">保存销售反馈</button></div>
          </form>
        </section>

        <div class="report-footer"><span>${esc(analysis.disclaimer || "平台不承诺销量、成交、最高利润或法律绝对合规。")}</span><div class="button-row"><button class="button ghost small" type="button" data-report-action="export-json" ${feature("export_enabled") ? "" : "disabled"}>导出 JSON</button><button class="button ghost small" type="button" data-report-action="back-batch">检查证据</button></div></div>
      </div>`;
  }

  function openSwitchMode() {
    const batch = state.currentBatch;
    if (!batch) return;
    openModal("切换分析模式", "旧结果会暂停，但档案、证据和人工操作记录会保留", `
      <form id="switchModeForm" class="form-stack">
        <label class="field"><span>选择新分析模式</span><select name="mode"><option value="web" ${batch.mode === "web" ? "selected" : ""}>联网模式 · 不调用模型 API</option><option value="agent" ${batch.mode === "agent" ? "selected" : ""}>Agent 模式 · 调用兼容 API</option></select></label>
        <div class="info-box">Agent 只负责主张提取、补问和长尾复核；事实门禁、渠道计算、本地合规规则始终由确定性引擎执行。</div>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">切换并暂停旧结果</button></div>
      </form>`);
    $("#switchModeForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true);
      try {
        const mode = event.currentTarget.elements.mode.value;
        if (mode === batch.mode) throw new Error("当前已经是该模式");
        const result = await api(`/api/batches/${encodeURIComponent(batch.id)}`, { method: "POST", body: { mode } });
        closeModal(); state.currentBatch = result.batch;
        await loadBatch(batch.id, "batch");
        toast("模式已切换，请按当前模式重新分析", "warning");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  function openVerify(evidenceId, decision) {
    const evidence = (state.currentBatch?.evidence || []).find((item) => item.id === evidenceId);
    if (!evidence) return;
    const labels = { verified: "核验通过", conflict: "标记冲突", rejected: "驳回证据" };
    const required = decision !== "verified";
    openModal(labels[decision] || "证据核验", `${evidence.label || evidence.type} · ${evidence.source_name || "未填写来源"}`, `
      <form id="verifyForm" class="form-stack">
        <div class="info-box">${decision === "verified" ? "通过后，该证据才可支撑相关宣传语句。系统会记录核验人和时间。" : "该结论会阻断依赖此证据的宣传语句，请写明原因。"}</div>
        <label class="field"><span>核验说明 ${required ? "<b>*</b>" : "（可选）"}</span><textarea name="reason" rows="4" maxlength="1000" ${required ? "required minlength=4" : ""} placeholder="${decision === "verified" ? "可写明已核对的主体、批次和有效期" : "至少 4 个字，说明冲突或驳回原因"}"></textarea></label>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button ${decision === "verified" ? "primary" : "ghost"}" type="submit">${esc(labels[decision] || "保存")}</button></div>
      </form>`);
    $("#verifyForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true);
      try {
        const reason = event.currentTarget.elements.reason.value.trim();
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/verify`, { method: "POST", body: { evidence_id: evidenceId, decision, reason } });
        closeModal(); state.currentBatch = result.batch;
        await loadBatch(result.batch.id, "batch"); toast("证据核验结论已留痕");
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  function openWebEvidence(sourceId) {
    const source = (state.currentBatch?.sources || []).find((item) => item.id === sourceId);
    if (!source) return;
    const detail = state.currentDetail || {};
    openModal("把公开来源加入证据", "系统会重新读取网页快照并计算哈希，但仍需人工核验主体和批次", `
      <form id="webEvidenceForm" class="form-stack">
        <div class="info-box"><strong>${esc(source.title || "未命名来源")}</strong><br>${esc(source.source_level || "")} · ${esc(source.url || "")}</div>
        <label class="field"><span>这份材料拟证明什么？</span><select name="type" required>${typeOptions(detail.evidence_types || {}, source.suggested_type || "ORIGIN_PROOF")}</select></label>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">读取快照并保存证据</button></div>
      </form>`);
    $("#webEvidenceForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true, "读取网页…");
      try {
        const type = event.currentTarget.elements.type.value;
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/evidence`, { method: "POST", body: { provider: "web", source_id: sourceId, type } });
        closeModal(); state.currentBatch = result.batch;
        await loadBatch(result.batch.id, "batch"); toast(result.notice || "证据已保存，请人工核验", "info", 6200);
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  function openExtract() {
    openModal("提取公开网页", "只接受互联网公开 HTTP(S) 页面，不访问本机或内网地址", `
      <form id="extractForm" class="form-stack">
        <label class="field"><span>网页地址</span><input name="url" type="url" required maxlength="2048" placeholder="https://..."></label>
        <div id="extractResult"></div>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">读取网页正文</button></div>
      </form>`);
    $("#extractForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true, "提取中…");
      try {
        const url = event.currentTarget.elements.url.value.trim();
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/extract`, { method: "POST", body: { url } });
        $("#extractResult").innerHTML = `<div class="info-box"><strong>${esc(result.title || "网页正文")}</strong><p>${esc((result.excerpt || "").slice(0, 700))}</p><small>${esc(result.notice || "")}</small></div><div class="button-row report-gap"><button class="button small primary" type="button" data-add-extracted="${esc(result.url)}" data-suggested-type="${esc(result.suggested_type || "ORIGIN_PROOF")}">加入为待核验证据</button></div>`;
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  async function addExtractedEvidence(url, type, button) {
    setBusy(button, true, "保存快照…");
    try {
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/evidence`, { method: "POST", body: { provider: "web", url, type } });
      closeModal(); state.currentBatch = result.batch;
      await loadBatch(result.batch.id, "batch"); toast("网页快照已保存，请人工核验", "info", 6200);
    } catch (error) { toast(error.message, "error", 7000); }
    finally { setBusy(button, false); }
  }

  async function collectSources(button) {
    const input = $("#collectQuery");
    const query = input ? input.value.trim() : "";
    setBusy(button, true, "联网采集中…");
    if ($("#collectStatus")) $("#collectStatus").textContent = "正在检索公开来源并读取正文，请稍候…";
    try {
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/collect`, { method: "POST", body: { query } });
      state.currentBatch = result.batch;
      await loadBatch(result.batch.id, "batch");
      const dbHits = number(result.database_hits, 0);
      const livePages = number(result.live_pages, 0);
      toast(`${result.notice || "采集完成"} 案例库 ${dbHits} 条 · 联网 ${livePages} 页`, "info", 7000);
      if ($("#collectStatus")) $("#collectStatus").textContent = `案例库命中 ${dbHits} 条，联网读取 ${livePages} 页，仍须核验主体与批次。${(result.errors || []).slice(0, 2).join("；")}`;
      if ((result.errors || []).length) toast(`部分来源读取失败：${result.errors.slice(0, 2).join("；")}`, "warning", 8000);
    } catch (error) {
      if ($("#collectStatus")) $("#collectStatus").textContent = error.message;
      toast(error.message, "error", 9000);
    }
    finally { setBusy(button, false); }
  }

  async function analyzeCurrent(button) {
    if (!state.currentBatch) return;
    setBusy(button, true, state.currentBatch.mode === "agent" ? "Agent 分析中…" : "正在测算…");
    try {
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/analyze`, {
        method: "POST", body: { mode: state.currentBatch.mode, api_source: $("#apiSourceSelect")?.value || "auto" }
      });
      state.currentBatch = result.batch;
      showView("report"); renderReport(result.batch); toast(result.notice || "分析完成", "success", 6500);
    } catch (error) { toast(error.message, "error", 10000); }
    finally { setBusy(button, false); }
  }

  async function saveContentForm(form, button) {
    setBusy(button, true, "审查中…");
    try {
      const content = Object.fromEntries(new FormData(form));
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/content`, {
        method: "POST", body: { content, mode: state.currentBatch.mode, api_source: $("#apiSourceSelect")?.value || "auto" }
      });
      state.currentBatch = result.batch;
      renderReport(result.batch); toast("文案已保存并重新审查", "success");
      const level = (result.compliance || {}).level;
      if (["blocker", "high"].includes(level)) toast("当前文案仍存在高风险，导出已被阻止", "warning", 6500);
    } catch (error) { toast(error.message, "error", 8500); }
    finally { setBusy(button, false); }
  }

  function openOverride() {
    if (isGuest()) { toast("游客不能强制放行，请先注册或登录", "warning"); return; }
    openModal("提交复核说明", "记录问题与补证计划，仍需整改并通过审查才能导出", `
      <form id="overrideForm" class="form-stack">
        <div class="warning-box">提交复核说明不会解除拦截。请先修改风险文案或补充证据，再重新分析；说明将写入审计记录。</div>
        <label class="field"><span>复核说明与补证计划（至少 10 个字）</span><textarea name="reason" rows="5" maxlength="1000" required minlength="10" placeholder="例如：已与合作社确认本周补交产地证明，先用于内部审稿，不对外发布。"></textarea></label>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button ghost" type="submit">提交说明</button></div>
      </form>`);
    $("#overrideForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true);
      try {
        const reason = event.currentTarget.elements.reason.value.trim();
        const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/override`, { method: "POST", body: { reason } });
        closeModal(); state.currentBatch = result.batch; renderReport(result.batch); toast(result.notice || "已记录强制放行", "warning", 7000);
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  async function exportCurrent(format, button) {
    setBusy(button, true, "生成文件…");
    try {
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/export`, { method: "POST", body: { format } });
      downloadText(result.filename, result.text, result.mime);
      state.currentBatch = result.batch; renderReport(result.batch); toast("报告已导出并留痕");
    } catch (error) { toast(error.message, "error", 9000); }
    finally { setBusy(button, false); }
  }

  async function saveFeedbackForm(form, button) {
    setBusy(button, true, "保存中…");
    try {
      const raw = Object.fromEntries(new FormData(form));
      const body = { channel_code: raw.channel_code, notes: raw.notes };
      for (const name of ["sold_kg", "revenue_yuan", "returns_kg", "profit_yuan"]) body[name] = raw[name] === "" ? null : Number(raw[name]);
      const allEmpty = ["sold_kg", "revenue_yuan", "returns_kg", "profit_yuan"].every((name) => body[name] === null) && !body.notes;
      if (allEmpty) throw new Error("请至少填写一项真实销售结果或复盘备注");
      const result = await api(`/api/batches/${encodeURIComponent(state.currentBatch.id)}/feedback`, { method: "POST", body });
      state.currentBatch = result.batch; renderReport(result.batch); toast(result.notice || "销售反馈已保存", "success", 6500);
    } catch (error) { toast(error.message, "error", 7000); }
    finally { setBusy(button, false); }
  }


  function featureSwitch(key, checked) {
    const label = FEATURE_LABELS[key] || key;
    return `<label class="switch-row"><span>${esc(label)}</span><span class="switch"><input type="checkbox" name="${esc(key)}" ${checked ? "checked" : ""}><i></i></span></label>`;
  }

  function renderAdmin() {
    const root = $("#adminContent");
    const data = state.admin;
    if (!data) {
      root.innerHTML = emptyState("管理中心数据尚未加载。");
      return;
    }
    const users = data.users || [];
    const stats = data.stats || {};
    const batches = data.batches || [];
    const settings = data.settings || {};
    const features = settings.features || {};
    const platform = settings.platform_api || {};
    const sources = settings.data_sources || {};
    const audit = data.audit || {};
    const verification = audit.verification || {};
    const rules = data.rules || {};
    const prompts = data.prompts || [];
    const configuredOrder = sources.search_order || [];
    const knownSources = ["必应 RSS", "必应网页", "搜狗", "360", "DuckDuckGo"];
    const sourceNames = [...configuredOrder.filter((name) => knownSources.includes(name)), ...knownSources.filter((name) => !configuredOrder.includes(name))];
    root.innerHTML = `
      <div class="admin-grid">
        <section class="card panel admin-wide">
          <div class="panel-head"><div><h3>平台概览</h3><p>用户、批次、证据链与当前管理员身份。</p></div><span class="status-pill">${esc((data.acting_admin || {}).username || "")}</span></div>
          <div class="admin-stats">
            <div class="admin-stat"><span>注册用户</span><strong>${number(stats.users, 0)}</strong></div>
            <div class="admin-stat"><span>启用账号</span><strong>${number(stats.active_users, 0)}</strong></div>
            <div class="admin-stat"><span>批次总数</span><strong>${number(stats.batches, 0)}</strong></div>
            <div class="admin-stat"><span>审计记录</span><strong>${number(verification.total, 0)}</strong></div>
          </div>
        </section>

        <section class="card panel admin-wide">
          <div class="panel-head"><div><h3>用户与权限</h3><p>管理员可停用账号、调整角色或重置密码；当前管理员不能停用或降级自己。</p></div><span class="status-pill">${users.length} 个账号</span></div>
          <div class="table-wrap"><table class="data-table"><thead><tr><th>用户</th><th>角色</th><th>状态</th><th>最近登录</th><th>密码状态</th><th>操作</th></tr></thead><tbody>
          ${users.map((user) => `<tr><td><strong>${esc(user.username)}</strong><small>${esc(user.id)}</small></td><td>${user.role === "admin" ? "管理员" : "普通用户"}</td><td>${user.active ? '<span class="status-tag pass">启用</span>' : '<span class="status-tag rejected">停用</span>'}</td><td>${esc(dateText(user.last_login_at))}</td><td>${user.must_change_password ? "首次登录须改密" : "正常"}</td><td><div class="user-actions"><button class="button small ghost" type="button" data-admin-user="${esc(user.id)}" data-admin-action="toggle-active" data-active="${user.active ? "true" : "false"}">${user.active ? "停用" : "启用"}</button><button class="button small ghost" type="button" data-admin-user="${esc(user.id)}" data-admin-action="toggle-role" data-role="${esc(user.role)}">${user.role === "admin" ? "设为用户" : "设为管理员"}</button><button class="button small ghost" type="button" data-admin-user="${esc(user.id)}" data-admin-action="reset-password">重置密码</button><button class="button small ghost" type="button" data-admin-user="${esc(user.id)}" data-admin-action="must-change" data-change="${user.must_change_password ? "false" : "true"}">${user.must_change_password ? "取消改密要求" : "要求改密"}</button></div></td></tr>`).join("")}
          </tbody></table></div>
        </section>

        <section class="card panel admin-wide">
          <div class="panel-head"><div><h3>全部批次</h3><p>只读查看产品档案、证据状态、核验结果和审计记录，不代替用户操作。</p></div><span class="status-pill">${batches.length} 个批次</span></div>
          <div class="table-wrap"><table class="data-table"><thead><tr><th>批次 / 产品</th><th>所有者</th><th>来源</th><th>状态</th><th>证据</th><th>门禁</th><th>合规</th><th>最优渠道</th><th>操作</th></tr></thead><tbody>
          ${batches.length ? batches.map((batch) => `<tr><td><strong>${esc(batch.product_name || "未命名")}</strong><small>${esc(batch.batch_code || batch.id)}</small></td><td>${esc(batch.owner_username || "游客")}</td><td>${esc(batch.origin || "")}</td><td>${statusPill(batch.status)}</td><td>${number(batch.evidence_verified, 0)} / ${number(batch.evidence_total, 0)} 已核验</td><td>${number(batch.claims_passed, 0)} 通过 · ${number(batch.claims_blocked, 0)} 拦截</td><td>${esc(LEVEL_LABELS[batch.compliance_level] || batch.compliance_level || "待审查")}</td><td>${esc(batch.best_plan || "尚未测算")}</td><td><button class="button small ghost" type="button" data-admin-batch="${esc(batch.id)}">只读查看</button></td></tr>`).join("") : `<tr><td colspan="9">${emptyState("暂无批次")}</td></tr>`}
          </tbody></table></div>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>平台功能开关</h3><p>关闭后立即影响游客、注册、采集、导出与 API 可用性。</p></div></div>
          <form id="adminFeatureForm" class="settings-form">
            <div class="switch-grid">${Object.keys(FEATURE_LABELS).map((key) => featureSwitch(key, !!features[key])).join("")}</div>
            <div class="button-row"><button class="button primary small" type="submit">保存功能开关</button></div>
          </form>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>平台 Agent API</h3><p>仅支持 HTTPS 兼容 Chat Completions 服务；密钥加密保存，界面只显示掩码。</p></div><span class="status-pill">${platform.configured ? "已配置" : "未配置"}</span></div>
          <form id="adminApiForm" class="settings-form">
            <label>Base URL<input name="base_url" type="url" value="${esc(platform.base_url || "https://api.deepseek.com")}" required></label>
            <label>模型名称<input name="model" value="${esc(platform.model || "deepseek-chat")}" required></label>
            <label>API Key（留空保持原值）<input name="api_key" type="password" autocomplete="off" placeholder="${esc(platform.key_masked || "填写服务密钥")}"></label>
            <label class="checkbox-row"><input name="enabled" type="checkbox" ${platform.enabled ? "checked" : ""}> 启用平台 API</label>
            <label class="checkbox-row"><input name="clear_key" type="checkbox"> 清除已保存密钥</label>
            <p class="help">最近测试：${esc((platform.last_test || {}).message || "尚未测试")}</p>
            <div class="button-row"><button class="button ghost small" type="button" id="adminTestApi">测试已保存配置</button><button class="button primary small" type="submit">保存平台 API</button></div>
          </form>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>联网数据源</h3><p>联网模式不调用模型 API；勾选允许使用的公开搜索源，并保持固定顺序。</p></div></div>
          <form id="adminSourceForm" class="settings-form">
            <div class="source-order">${sourceNames.map((name) => `<label><input type="checkbox" name="search_order" value="${esc(name)}" ${configuredOrder.includes(name) ? "checked" : ""}> ${esc(name)}</label>`).join("")}</div>
            <label>单次最多读取网页数<input name="max_pages_per_collect" type="number" min="1" max="5" step="1" value="${esc(sources.max_pages_per_collect || 3)}" required></label>
            <div class="button-row"><button class="button primary small" type="submit">保存数据源设置</button></div>
          </form>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>审计链完整性</h3><p>校验现存记录的哈希与前后关联。完整性校验不等同于权威认证，仍需备份与外部存证。</p></div><span class="status-tag ${verification.ok ? "pass" : "rejected"}">${verification.ok ? "链完整" : "需要检查"}</span></div>
          <p class="help">共 ${number(verification.total, 0)} 条记录；异常 ${number((verification.broken || []).length, 0)} 条。最后哈希：<span class="hash">${esc(verification.last_hash || "无")}</span></p>
          <div class="button-row"><button class="button ghost small" type="button" id="verifyAudit">重新校验审计链</button></div>
          <div class="audit-list report-gap">${(audit.entries || []).slice(0, 30).map((entry) => {
            const pairs = Object.entries(entry.detail || {}).map(([k, v]) => `${k}=${v && typeof v === "object" ? JSON.stringify(v) : v}`).join(" · ");
            return `<div class="audit-row"><span class="at">${esc(dateText(entry.at))}</span><span class="ac"><strong>${esc(auditAction(entry.action))}</strong><em>${esc(entry.actor_username || "系统")}</em></span><code>${esc((entry.resource_type || "") + (entry.resource_id ? ":" + entry.resource_id : ""))}${pairs ? " · " + esc(pairs.slice(0, 120)) : ""}</code></div>`;
          }).join("") || emptyState("暂无审计记录")}</div>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>合规规则版本</h3><p>当前规则集 ${esc(rules.version || "未加载")}，共 ${number((rules.rules || []).length, 0)} 条。</p></div></div>
          <div class="rule-grid">${(rules.rules || []).map((rule) => `<div class="rule-chip"><strong>${esc(rule.id)} · ${esc(rule.name)}</strong><span>${esc(rule.severity)} · ${esc(rule.basis || "")}</span></div>`).join("") || emptyState("暂无规则")}</div>
          <p class="help report-gap">来源：${esc((rules.sources || []).join("；") || "未记录")}</p>
        </section>

        <section class="card panel">
          <div class="panel-head"><div><h3>提示词版本</h3><p>关键提示词可追溯，展示当前版本和历史变更。</p></div><span class="status-pill">${prompts.length} 组</span></div>
          ${prompts.length ? prompts.map((prompt) => `<details class="hit"><summary><strong>${esc(prompt.name || prompt.id)}</strong> · 当前 ${esc(prompt.current || "未标版本")}</summary>${(prompt.versions || []).map((item) => `<p><strong>${esc(item.version)}</strong> · ${esc(item.changelog || "无变更说明")}${item.retired ? " · 已退役" : " · 当前"}</p>`).join("")}<small>${esc(prompt.versions?.length || 0)} 个版本已留档</small></details>`).join("") : emptyState("暂无提示词记录")}
        </section>
      </div>`;
  }

  async function loadAdmin() {
    if (!isAdmin()) {
      $("#adminContent").innerHTML = emptyState("仅管理员可访问管理中心。");
      return;
    }
    $("#adminContent").innerHTML = '<div class="loading-block">正在读取用户、批次、规则和审计链…</div>';
    try {
      const [users, batches, settings, audit, rules, prompts] = await Promise.all([
        api("/api/admin/users"),
        api("/api/admin/batches"),
        api("/api/admin/settings"),
        api("/api/admin/audit?limit=200"),
        api("/api/admin/rules"),
        api("/api/admin/prompts")
      ]);
      state.admin = {
        users: users.users || [], stats: users.stats || {}, acting_admin: users.acting_admin || {},
        batches: batches.batches || [], settings: settings.settings || {},
        audit, rules, prompts: prompts.prompts || []
      };
      renderAdmin();
    } catch (error) {
      $("#adminContent").innerHTML = emptyState(`管理中心加载失败：${error.message}`);
      toast(error.message, "error", 7000);
    }
  }

  async function updateAdminUser(userId, action, trigger) {
    let patch = null;
    if (action === "toggle-active") patch = { active: trigger.dataset.active !== "true" };
    if (action === "toggle-role") patch = { role: trigger.dataset.role === "admin" ? "user" : "admin" };
    if (action === "must-change") patch = { must_change_password: trigger.dataset.change === "true" };
    if (!patch) return;
    if (action === "toggle-role" && !window.confirm("确认调整该用户的平台角色？角色变化会立即生效。")) return;
    setBusy(trigger, true);
    try {
      await api(`/api/admin/users/${encodeURIComponent(userId)}`, { method: "POST", body: patch });
      await loadAdmin();
      toast("账号权限已更新");
    } catch (error) {
      toast(error.message, "error", 7000);
    } finally {
      setBusy(trigger, false);
    }
  }

  function openResetPassword(userId) {
    const user = (state.admin?.users || []).find((item) => item.id === userId);
    openModal("重置用户密码", user ? `${user.username} · ${user.id}` : userId, `
      <form id="resetPasswordForm" class="form-stack">
        <div class="warning-box">重置后旧密码立即失效，该用户下次登录必须修改密码。新密码至少 8 位，并同时包含字母和数字。</div>
        <label class="field"><span>新密码</span><input name="new_password" type="password" minlength="8" maxlength="128" required autocomplete="new-password"></label>
        <div id="modalError" class="danger-box" hidden></div>
        <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">取消</button><button class="button primary" type="submit">确认重置</button></div>
      </form>`);
    $("#resetPasswordForm").addEventListener("submit", async (event) => {
      event.preventDefault(); const button = event.submitter; setBusy(button, true, "重置中…");
      try {
        const result = await api(`/api/admin/users/${encodeURIComponent(userId)}/reset-password`, {
          method: "POST", body: { new_password: event.currentTarget.elements.new_password.value }
        });
        closeModal(); toast(result.notice || "密码已重置", "warning", 6500); await loadAdmin();
      } catch (error) { modalError(error.message); }
      finally { setBusy(button, false); }
    });
  }

  async function openAdminBatch(batchId) {
    try {
      const result = await api(`/api/admin/batch/${encodeURIComponent(batchId)}`);
      const batch = result.batch || {};
      const product = batch.product || {};
      const evidence = batch.evidence || [];
      const claims = batch.claims || [];
      const audit = result.audit || [];
      openModal("批次只读审查", `${batch.batch_code || batch.id} · 管理员不能代替所有者修改、核验或放行`, `
        <div class="form-stack">
          <div class="warning-box">以下内容仅供管理员查看证据来源与核验结果。任何修改、证据核验和强制放行都必须由批次所有者完成并留痕。</div>
          <dl class="detail-grid">
            ${detailItem("产品", product.name)}${detailItem("所有者", batch.owner_username)}
            ${detailItem("来源地址", product.origin_address)}${detailItem("提交单位", product.organization)}
            ${detailItem("本批重量", `${number(product.batch_weight_kg)} kg`)}${detailItem("分析模式", batch.mode === "agent" ? "Agent 模式" : "联网模式")}
            ${detailItem("事实门禁", `${number((batch.gate || {}).passed, 0)} 通过 / ${number((batch.gate || {}).blocked, 0)} 拦截`)}${detailItem("合规结论", LEVEL_LABELS[(batch.compliance || {}).level] || (batch.compliance || {}).level || "待审查")}
          </dl>
          <section><h3>证据与核验结果</h3><div class="evidence-list report-gap">${evidence.length ? evidence.map((item) => {
            const sourceUrl = safeUrl(item.source_url);
            const attachment = safeUrl(item.attachment?.url || item.snapshot?.url || "");
            const hash = item.snapshot?.sha256 || item.attachment?.sha256 || "";
            return `<article class="evidence-card ${esc(item.status || "pending")}"><div class="evidence-head"><div><strong>${esc(item.label || item.type)}</strong><small>${esc(item.source_level || "")} · ${esc(item.source_name || "")}</small></div><span class="status-tag ${esc(item.status || "pending")}">${esc(EVIDENCE_STATUS[item.status] || item.status || "待核验")}</span></div><div class="evidence-body"><p>${esc((item.excerpt || item.detail || "暂无摘要").slice(0, 500))}</p><div class="evidence-meta"><span>发布：${esc(item.published_at || "未填")}</span><span>抓取：${esc(dateText(item.fetched_at))}</span><span>有效期：${esc(item.expires_at || "未填")}</span><span>批次匹配：${item.matches_batch ? "是" : "待确认"}</span></div>${item.verification_note ? `<p class="help">核验说明：${esc(item.verification_note)} · ${esc(item.verified_by || "")} ${esc(dateText(item.verified_at))}</p>` : ""}${sourceUrl ? `<a class="source-url" href="${esc(sourceUrl)}" target="_blank" rel="noopener noreferrer">${esc(sourceUrl)}</a>` : ""}${attachment ? `<a class="source-url" href="${esc(attachment)}" target="_blank" rel="noopener noreferrer">查看原始附件</a>` : ""}${hash ? `<span class="hash">SHA-256 ${esc(hash)}</span>` : ""}</div></article>`;
          }).join("") : emptyState("暂无证据")}</div></section>
          <section><h3>事实门禁结果</h3><div class="claim-list report-gap">${claims.length ? claims.map(claimRow).join("") : emptyState("尚无主张记录")}</div></section>
          <section><h3>批次审计记录</h3><div>${audit.length ? audit.map((entry) => `<div class="audit-row"><span>${esc(dateText(entry.at))}</span><strong>${esc(entry.action)} · ${esc(entry.actor_username || "")}</strong><code>${esc(JSON.stringify(entry.detail || {}).slice(0, 180))}</code></div>`).join("") : emptyState("暂无批次审计记录")}</div></section>
          <div class="modal-actions"><button class="button ghost" type="button" data-modal-close="button">关闭</button></div>
        </div>`, { large: true });
    } catch (error) { toast(error.message, "error", 7000); }
  }

  async function saveAdminSettings(body, button, message) {
    setBusy(button, true, "保存中…");
    try {
      const result = await api("/api/admin/settings", { method: "POST", body });
      state.admin.settings = result.settings || state.admin.settings;
      if (state.admin.settings?.features) state.me.features = state.admin.settings.features;
      renderAdmin();
      toast(message || "平台设置已保存");
    } catch (error) {
      toast(error.message, "error", 8000);
    } finally {
      setBusy(button, false);
    }
  }

  async function adminFeaturesSubmit(form, button) {
    const features = Object.fromEntries(Object.keys(FEATURE_LABELS).map((key) => [key, false]));
    for (const key of Object.keys(FEATURE_LABELS)) features[key] = !!form.elements[key]?.checked;
    await saveAdminSettings({ features }, button, "功能开关已保存");
  }

  async function adminApiSubmit(form, button) {
    const values = Object.fromEntries(new FormData(form));
    const body = {
      base_url: values.base_url, model: values.model, enabled: form.elements.enabled.checked,
      clear_key: form.elements.clear_key.checked, api_key: String(values.api_key || "")
    };
    await saveAdminSettings({ platform_api: body }, button, "平台 API 设置已保存");
  }

  async function adminSourcesSubmit(form, button) {
    const order = new FormData(form).getAll("search_order").filter((name) => ["必应 RSS", "必应网页", "搜狗", "360", "DuckDuckGo"].includes(name));
    if (!order.length) { toast("至少保留一个联网搜索源", "warning"); return; }
    const value = Number(form.elements.max_pages_per_collect.value);
    if (!Number.isInteger(value) || value < 1 || value > 5) { toast("单次采集页数须为 1–5 的整数", "warning"); return; }
    await saveAdminSettings({ data_sources: { search_order: order, max_pages_per_collect: value } }, button, "数据源设置已保存");
  }

  async function testAdminApi(button) {
    setBusy(button, true, "测试中…");
    try {
      const result = await api("/api/admin/settings", { method: "POST", body: { action: "test_api" } });
      if (state.admin) state.admin.settings = result.settings || state.admin.settings;
      renderAdmin();
      toast(result.test?.message || "平台 API 连接成功");
    } catch (error) {
      toast(error.message, "error", 9000);
    } finally {
      setBusy(button, false);
    }
  }

  document.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;

    const sortButton = target.closest("[data-chsort]");
    if (sortButton) {
      const key = sortButton.dataset.chsort;
      if (key && key !== state.channelSort) {
        state.channelSort = key;
        if (state.currentBatch) renderReport(state.currentBatch);
      }
      return;
    }

    const traceButton = target.closest("[data-trace-open]");
  if (traceButton) {
    const batchId = traceButton.getAttribute("data-trace-open");
    traceButton.disabled = true;
    api(`/api/batches/${encodeURIComponent(batchId)}`)
      .then((data) => {
        const code = (data && data.trace_code) || "";
        window.open(`/t/${encodeURIComponent(batchId)}?k=${encodeURIComponent(code)}`, "_blank", "noopener");
      })
      .catch((error) => showToast(error.message || "打不开溯源页", "warn"))
      .finally(() => { traceButton.disabled = false; });
    return;
  }

  const viewButton = target.closest("[data-view]");
    if (viewButton) { void showView(viewButton.dataset.view); return; }

    const authButton = target.closest("[data-auth]");
    if (authButton) {
      const action = authButton.dataset.auth;
      if (action === "login" || action === "register") openAuth(action);
      else if (action === "password") openPasswordModal(false);
      else if (action === "api") openApiConfig();
      else if (action === "logout") void logout();
      return;
    }

    const modeButton = target.closest("[data-mode]");
    if (modeButton) { setMode(modeButton.dataset.mode); return; }

    const removePhoto = target.closest("[data-remove-photo]");
    if (removePhoto) {
      state.photos.splice(Number(removePhoto.dataset.removePhoto), 1);
      renderPhotoPreview();
      return;
    }

    const recent = target.closest("[data-open-batch]");
    if (recent) { void loadBatch(recent.dataset.openBatch); return; }

    const followup = target.closest("[data-followup]");
    if (followup) {
      const field = followup.dataset.followup;
      if (["unit_price_yuan_per_kg", "unit_cost_yuan_per_kg", "transport", "storage"].includes(field)) {
        openEditProduct();
        setTimeout(() => $(`#editProductForm [name="${field}"]`)?.focus(), 80);
      } else {
        openEvidenceModal({ type: field });
      }
      return;
    }

    const verify = target.closest("[data-verify]");
    if (verify) { openVerify(verify.dataset.verify, verify.dataset.decision); return; }

    const removeEvidence = target.closest("[data-remove-evidence]");
    if (removeEvidence) {
      const button = removeEvidence;
      if (!window.confirm("确认移除这条证据？核验结论和关联事实将重新计算。")) return;
      setBusy(button, true);
      (async () => {
        try {
          const batchId = state.currentBatch.id;
          await api(`/api/batches/${encodeURIComponent(batchId)}/evidence/remove`, {
            method: "POST", body: { evidence_id: button.dataset.removeEvidence }
          });
          await loadBatch(batchId, "batch"); toast("证据已移除并重新计算门禁");
        } catch (error) { toast(error.message, "error", 7000); }
        finally { setBusy(button, false); }
      })();
      return;
    }

    const sourceButton = target.closest("[data-source-id]");
    if (sourceButton) {
      const source = (state.currentBatch?.sources || []).find((item) => item.id === sourceButton.dataset.sourceId);
      if (!source) { toast("来源记录不存在，请刷新批次", "warning"); return; }
      openEvidenceModal({
        type: source.suggested_type || sourceButton.dataset.sourceType || "ORIGIN_PROOF",
        source_level: source.source_level || "公开网页",
        source_name: source.title || "公开来源",
        source_url: source.url || "",
        detail: source.snippet || source.title || "",
        published_at: source.published_at || "",
        fetched_at: source.fetched_at || ""
      });
      return;
    }

    const batchAction = target.closest("[data-batch-action]");
    if (batchAction) {
      const action = batchAction.dataset.batchAction;
      if (action === "edit-product") openEditProduct();
      else if (action === "add-evidence") openEvidenceModal();
      else if (action === "extract-url") openExtract();
      else if (action === "collect") void collectSources(batchAction);
      else if (action === "switch-mode") openSwitchMode();
      else if (action === "analyze" || action === "rerun") void analyzeCurrent(batchAction);
      else if (action === "report" && state.currentBatch) { void showView("report"); }
      return;
    }

    const reportAction = target.closest("[data-report-action]");
    if (reportAction && state.currentBatch) {
      const action = reportAction.dataset.reportAction;
      if (action === "back-batch") void loadBatch(state.currentBatch.id, "batch");
      else if (action === "rerun") void analyzeCurrent(reportAction);
      else if (action === "override") openOverride();
      else if (action === "export-md") void exportCurrent("markdown", reportAction);
      else if (action === "export-json") void exportCurrent("json", reportAction);
      return;
    }

    const copyButton = target.closest("[data-copy-content]");
    if (copyButton) {
      const field = copyButton.dataset.copyContent;
      const fieldNode = $(`#contentForm [name="${field}"]`);
      const review = state.currentBatch?.compliance || {};
      if (!review.level || review.blocked || state.currentBatch?.mode_switch_pending) { toast("当前文案尚未通过审查，请整改并保存后再复制", "warning"); return; }
      const hasEdits = ["detail_page", "oral_script", "social_post"].some((key) => document.querySelector('[name="' + key + '"]')?.value !== state.currentBatch?.content?.[key]);
      if (hasEdits) { toast("文案已修改，请先保存并重新审查", "warning"); return; }
      if (fieldNode) void copyText(fieldNode.value);
      return;
    }

    const adminUser = target.closest("[data-admin-user]");
    if (adminUser) {
      const action = adminUser.dataset.adminAction;
      if (action === "reset-password") openResetPassword(adminUser.dataset.adminUser);
      else void updateAdminUser(adminUser.dataset.adminUser, action, adminUser);
      return;
    }

    const adminBatch = target.closest("[data-admin-batch]");
    if (adminBatch) { void openAdminBatch(adminBatch.dataset.adminBatch); return; }
  });

  document.addEventListener("submit", (event) => {
    const form = event.target;
    if (form.id === "batchForm") {
      event.preventDefault();
      void saveBatch(false, event.submitter || $("#saveDraft"));
    } else if (form.id === "contentForm") {
      event.preventDefault();
      void saveContentForm(form, event.submitter);
    } else if (form.id === "feedbackForm") {
      event.preventDefault();
      void saveFeedbackForm(form, event.submitter);
    } else if (form.id === "adminFeatureForm") {
      event.preventDefault();
      void adminFeaturesSubmit(form, event.submitter);
    } else if (form.id === "adminApiForm") {
      event.preventDefault();
      void adminApiSubmit(form, event.submitter);
    } else if (form.id === "adminSourceForm") {
      event.preventDefault();
      void adminSourcesSubmit(form, event.submitter);
    }
  });

  document.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    if (target.closest("#exampleFill") || target.closest("#exampleFillSide")) { fillExample(); return; }
    if (target.closest("#saveAnalyze")) { void saveBatch(true, target.closest("#saveAnalyze")); return; }
    if (target.closest("#openApiConfig")) { openApiConfig(); return; }
    if (target.closest("#refreshBatches")) { void loadBatches(); return; }
    if (target.closest("#adminRefresh")) { void loadAdmin(); return; }
    if (target.closest("#adminTestApi")) { void testAdminApi(target.closest("#adminTestApi")); return; }
    if (target.closest("#verifyAudit")) {
      const button = target.closest("#verifyAudit");
      setBusy(button, true, "校验中…");
      (async () => {
        try {
          const result = await api("/api/admin/audit/verify");
          if (state.admin?.audit) state.admin.audit.verification = result;
          renderAdmin();
          toast(result.ok ? `审计链完整，共 ${number(result.total, 0)} 条记录` : "审计链发现异常，请立即检查", result.ok ? "success" : "error", 7000);
        } catch (error) { toast(error.message, "error", 7000); }
        finally { setBusy(button, false); }
      })();
    }
  });

  document.addEventListener("change", (event) => {
    if (event.target.id === "photoInput") void addPhotos(event.target.files);
  });

  document.addEventListener("keydown", (event) => {
    if ((event.key === "Enter" || event.key === " ") && event.target.matches("[data-open-batch]")) {
      event.preventDefault();
      void loadBatch(event.target.dataset.openBatch);
    }
  });

  async function init() {
    try {
      state.me = await api("/api/auth/me");
      renderAccount();
      setMode("web");
      await loadBatches();
    } catch (error) {
      toast(`初始化失败：${error.message}`, "error", 9000);
      $("#recentBatches").innerHTML = emptyState("平台会话初始化失败，请刷新页面重试。");
    }
  }

  init();
})();

