/* 言之有据 · 前端逻辑（原生 JS，无构建步骤） */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const num = (n) => (n === null || n === undefined || n === "" ? "—" : n);

const S = {
  config: {},
  products: [],
  cases: [],
  product: null,
  evidence: [],
  promptVersion: "v3",
  recordId: null,
  claims: [],
  summary: null,
  gaps: [],
  adopted: new Set(),
  content: {},
  savedContent: {},
  contentKind: "detail_page",
  auditOptions: [],
  auditKey: "generated",
  compliance: null,
  decisions: [],
  caseMeta: null,
  promptInfo: {},
};

/* ------------------------------------------------------------ 基础设施 */

async function api(path, method = "GET", body) {
  const res = await fetch(path, {
    method,
    headers: body ? { "Content-Type": "application/json", "X-Requested-With": "YanZhiYouJu" } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  let data;
  try {
    data = await res.json();
  } catch (e) {
    throw new Error(`服务返回了非 JSON 响应（HTTP ${res.status}）`);
  }
  if (!res.ok || data.ok === false) throw new Error(data.error || `请求失败（HTTP ${res.status}）`);
  return data;
}

function toast(msg, type = "") {
  const root = $("#toastRoot");
  const node = document.createElement("div");
  node.className = "toast " + type;
  node.textContent = msg;
  root.appendChild(node);
  setTimeout(() => {
    node.style.transition = "opacity .3s, transform .3s";
    node.style.opacity = "0";
    node.style.transform = "translateY(6px)";
    setTimeout(() => node.remove(), 300);
  }, type === "err" ? 5200 : 3200);
}

function busy(btn, label) {
  if (!btn) return () => {};
  const html = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = `<span class="spinner"></span>${esc(label)}`;
  return () => {
    btn.disabled = false;
    btn.innerHTML = html;
  };
}

function showModal(opts) {
  return new Promise((resolve) => {
    const root = $("#modalRoot");
    const actions = opts.actions || [{ label: "关闭", value: null }];
    root.innerHTML = `
      <div class="modal-mask">
        <div class="modal">
          <div class="modal-head">
            <h3>${esc(opts.title || "")}</h3>
            ${opts.subtitle ? `<p>${esc(opts.subtitle)}</p>` : ""}
          </div>
          <div class="modal-body">${opts.body || ""}</div>
          <div class="modal-foot">
            ${actions.map((a, i) => `<button class="${a.primary ? "primary" : "ghost"} ${a.danger ? "danger" : ""}" data-i="${i}">${esc(a.label)}</button>`).join("")}
          </div>
        </div>
      </div>`;
    const mask = $(".modal-mask", root);

    const close = (v) => {
      root.innerHTML = "";
      document.removeEventListener("keydown", onKey);
      resolve(v);
    };
    const onKey = (e) => {
      if (e.key === "Escape") close(null);
    };
    document.addEventListener("keydown", onKey);

    $$(".modal-foot button", root).forEach((btn) => {
      btn.onclick = () => {
        const a = actions[+btn.dataset.i];
        let v = a.value;
        if (opts.collect) {
          v = opts.collect(root, a.value);
          if (v === false) return;
        }
        close(v);
      };
    });
    if (mask) mask.onclick = (e) => { if (e.target === mask) close(null); };
    if (opts.onOpen) opts.onOpen(root);
    const first = $(".modal-body input, .modal-body textarea", root);
    if (first) setTimeout(() => first.focus(), 60);
  });
}

async function askReason({ title, hint, placeholder }) {
  return await showModal({
    title,
    subtitle: "理由会写入运行台账，导出的运行案例里可以看到。",
    body: `
      <div class="field">
        <label>${esc(hint || "请填写理由")}</label>
        <textarea id="reasonInput" placeholder="${esc(placeholder || "例如：合作社已口头承诺 3 天内补交检测报告，且本批仅用于内部样刊测试")}"></textarea>
        <div class="help">不少于 4 个字。留空无法确认。</div>
      </div>`,
    actions: [
      { label: "取消", value: null },
      { label: "确认并留痕", value: "ok", primary: true },
    ],
    collect: (root) => {
      const v = $("#reasonInput", root).value.trim();
      if (v.length < 4) {
        $("#reasonInput", root).style.borderColor = "#b23f2c";
        return false;
      }
      return v;
    },
  });
}

function download(filename, text, mime = "text/plain") {
  const blob = new Blob([text], { type: mime + ";charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* ------------------------------------------------------------ 顶部与标签 */

function setTab(name) {
  $$(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === name));
  $$(".view").forEach((v) => (v.hidden = v.id !== "view-" + name));
  if (name === "rules") loadRules();
  if (name === "prompts") loadPrompts();
  if (name === "ledger") loadLedger();
}

function setStep(n) {
  $$(".step").forEach((s) => {
    const i = +s.dataset.step;
    s.classList.toggle("active", i === n);
    s.classList.toggle("done", i < n);
  });
}

function setModeBadge(config) {
  const badge = $("#modeBadge");
  badge.classList.toggle("live", !!config.configured);
  badge.classList.toggle("web", !config.configured && config.mode === "web");
  badge.textContent = config.configured
    ? `已连接 · ${config.model}`
    : (config.mode === "web" ? "联网模式 · 网页提取" : "未配置 Key");
  $("#demoBanner").hidden = !!config.configured;
  if (!config.configured) {
    $("#demoBanner").innerHTML = `<b>联网模式</b>：无需 API Key：读取公开网页，再用本地规则与证据门禁处理。访客台账互相独立；免费服务器重启可能清空，请及时导出。网页信息只是公开来源线索，不能替代检测报告、证书或产地原始记录。`;
  }
}

/* ------------------------------------------------------------ 初始加载 */

async function init() {
  $$(".tab").forEach((t) => (t.onclick = () => setTab(t.dataset.tab)));
  $("#btnSettings").onclick = openSettings;
  $("#modeBadge").onclick = openSettings;

  $("#selProduct").onchange = (e) => selectProduct(e.target.value);
  $("#selPrompt").onchange = (e) => {
    S.promptVersion = e.target.value;
    renderPromptNote();
  };
  $("#btnGenerate").onclick = generate;
  $("#btnSelectPassed").onclick = () => {
    S.claims.filter((c) => c.gate === "PASS" || c.override).forEach((c) => S.adopted.add(c.id));
    renderClaims();
  };
  $("#btnContent").onclick = generateContent;
  $("#btnRegen").onclick = () => generateContent(true);
  $("#btnCompliance").onclick = runCompliance;
  $("#btnReCheck").onclick = runCompliance;
  $("#btnArchive").onclick = archive;
  $("#btnExportMd").onclick = () => exportRecord("md");
  $("#btnExportJson").onclick = () => exportRecord("json");
  $("#btnNew").onclick = () => {
    resetFlow();
    setStep(1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  $("#btnRefreshLedger").onclick = loadLedger;

  $$("#contentSeg .seg-btn").forEach((b) => {
    b.onclick = () => {
      $$("#contentSeg .seg-btn").forEach((x) => x.classList.toggle("active", x === b));
      S.contentKind = b.dataset.kind;
      renderEditor();
    };
  });

  $("#editor").oninput = onEditorInput;
  $("#editor").onblur = onEditorBlur;

  try {
    S.config = await api("/api/config");
    setModeBadge(S.config);
    S.products = (await api("/api/products")).products;
    S.cases = (await api("/api/cases")).cases;
    renderCaseStrip();
    renderProductOptions();
    if (S.products.length) await selectProduct(S.products[0].id);
    setStep(1);
  } catch (e) {
    toast("初始化失败：" + e.message, "err");
  }
}

function renderProductOptions() {
  $("#selProduct").innerHTML = S.products
    .map((p) => `<option value="${esc(p.id)}">${esc(p.name)} · ${esc(p.org || "")}</option>`)
    .join("");
  $("#selPrompt").innerHTML = [
    ["v3", "v3（当前在用 · 证据约束版）"],
    ["v2", "v2（已退役 · 结构化但无证据）"],
    ["v1", "v1（已退役 · 无约束初版）"],
  ]
    .map(([v, label]) => `<option value="${v}">${esc(label)}</option>`)
    .join("");
  $("#selPrompt").value = S.promptVersion;
  renderPromptNote();
}

function renderPromptNote() {
  const notes = {
    v3: "v3 要求每条主张声明所需证据，缺证据时如实标注而不是回避。",
    v2: "v2 只输出 claim / why，模型无法说明「靠什么证明」——门禁会把全部主张拦下，这正是它被退役的原因。",
    v1: "v1 无任何约束。选它跑一遍，可以直接看到门禁和合规审查要拦的是什么。",
  };
  $("#promptNote").textContent = notes[S.promptVersion] || "";
}

function renderCaseStrip() {
  $("#caseStrip").innerHTML = S.cases
    .map(
      (c) => `
    <button class="case-chip" data-id="${esc(c.id)}">
      <span class="case-type">${esc(c.type)}</span>
      <b>${esc(c.id)} · ${esc(c.title)}</b>
      <span>${esc(c.product_name || "")}${c.prompt_version ? " · 提示词 " + esc(c.prompt_version) : ""}</span>
    </button>`
    )
    .join("");
  $$("#caseStrip .case-chip").forEach((b) => (b.onclick = () => applyCase(b.dataset.id)));
}

async function applyCase(id) {
  const c = S.cases.find((x) => x.id === id);
  if (!c) return;
  S.promptVersion = c.prompt_version || "v3";
  await selectProduct(c.product_id);
  if (c.evidence_mode === "none") S.evidence.forEach((e) => (e.provided = false));
  S.caseMeta = c;
  renderSetup();
  await showModal({
    title: `${c.id} · ${c.title}`,
    subtitle: `${c.type}｜产品：${c.product_name}`,
    body: `
      <div class="field"><label>为什么要跑这个例子</label><div class="tiny" style="color:var(--ink-2);font-size:13px">${esc(c.why)}</div></div>
      <div class="field"><label>预期会看到什么</label><div class="tiny" style="color:var(--ink-2);font-size:13px">${esc(c.expected)}</div></div>
      <div class="field"><label>本次参数</label><div class="tiny">提示词版本 ${esc(c.prompt_version)}｜证据 ${c.evidence_mode === "none" ? "全部视为未提供" : "按档案默认"}</div></div>`,
    actions: [{ label: "关闭" }, { label: "按此参数开始运行", value: "go", primary: true }],
  }).then((v) => {
    if (v === "go") generate();
  });
}

/* ------------------------------------------------------------ Step 1 */

async function selectProduct(id) {
  const data = await api("/api/product/" + encodeURIComponent(id));
  S.product = data.product;
  S.evidence = data.product.evidence.map((e) => ({ ...e }));
  S.caseMeta = null;
  resetFlow();
  renderSetup();
}

function resetFlow() {
  S.recordId = null;
  S.claims = [];
  S.summary = null;
  S.gaps = [];
  S.adopted = new Set();
  S.content = {};
  S.savedContent = {};
  S.compliance = null;
  S.decisions = [];
  S.auditOptions = [];
  ["panel-claims", "panel-content", "panel-compliance", "panel-archive"].forEach((id) => ($("#" + id).hidden = true));
}

function renderSetup() {
  $("#selProduct").value = S.product.id;
  $("#selPrompt").value = S.promptVersion;
  renderPromptNote();

  $("#evidenceGrid").innerHTML = S.evidence
    .map(
      (e) => `
    <label class="ev-card ${e.provided ? "on" : "off"}">
      <input type="checkbox" data-type="${esc(e.type)}" ${e.provided ? "checked" : ""}>
      <div class="ev-body">
        <b>${esc(e.label)}</b>
        <small>${esc(e.provided ? (e.source || "已提供") : "未提供，需要补材料")}</small>
      </div>
    </label>`
    )
    .join("");

  $$("#evidenceGrid input").forEach((cb) => {
    cb.onchange = () => {
      const type = cb.dataset.type;
      const item = S.evidence.find((e) => e.type === type);
      item.provided = cb.checked;
      cb.closest(".ev-card").classList.toggle("on", cb.checked);
      cb.closest(".ev-card").classList.toggle("off", !cb.checked);
      updateSetupHint();
    };
  });
  updateSetupHint();
}

function updateSetupHint() {
  const n = S.evidence.filter((e) => e.provided).length;
  $("#setupHint").textContent = `9 类证据中已具备 ${n} 类。门禁只放行证据齐全的主张。`;
}

/* ------------------------------------------------------------ Step 2 */

function stepPanel(id, step) {
  $("#" + id).hidden = false;
  setStep(step);
  setTimeout(() => $("#" + id).scrollIntoView({ behavior: "smooth", block: "start" }), 80);
}

async function generate() {
  const btn = $("#btnGenerate");
  const restore = busy(btn, "生成中…");
  try {
    const overrides = Object.fromEntries(S.evidence.map((e) => [e.type, e.provided]));
    const data = await api("/api/generate", "POST", {
      product_id: S.product.id,
      prompt_version: S.promptVersion,
      evidence_overrides: overrides,
    });
    S.recordId = data.record_id;
    S.claims = data.claims;
    S.summary = data.summary;
    S.gaps = data.evidence_gaps;
    S.adopted = new Set(data.claims.filter((c) => c.gate === "PASS").map((c) => c.id));
    S.content = {};
    S.savedContent = {};
    S.compliance = null;
    $("#panel-content").hidden = true;
    $("#panel-compliance").hidden = true;
    $("#panel-archive").hidden = true;

    renderClaims();
    stepPanel("panel-claims", 2);

    const alert = $("#llmAlert");
    if (data.mode === "web") {
      alert.hidden = false;
      alert.className = "alert web";
      const source = data.web_source?.url ? `来源网页：${esc(data.web_source.url)}` : "已使用配置的公开网页地址";
      alert.innerHTML = `<b>联网网页提取模式</b>：未调用 DeepSeek API，主张来自公开网页提取和本地规则处理。<br>${source}`;
    } else if (data.llm_error) {
      alert.hidden = false;
      alert.className = "alert err";
      alert.innerHTML = `<b>模型调用未成功</b>：${esc(data.llm_error)}<br>下面的内容来自内置演示样例，仅用于展示流程，不能作为交付结果。`;
    } else if (data.demo) {
      alert.hidden = false;
      alert.className = "alert";
      alert.innerHTML = `<b>兼容样例模式</b>：当前结果来自兼容历史流程的固定样例，请配置 API Key 或使用 v3 联网网页提取模式。`;
    } else {
      alert.hidden = true;
    }
  } catch (e) {
    toast(e.message, "err");
  } finally {
    restore();
  }
}

function renderClaims() {
  const s = S.summary || {};
  $("#claimStats").innerHTML = `
    <span class="stat-pill">共 ${num(s.total)} 条</span>
    <span class="stat-pill pass">通过 ${num(s.passed)}</span>
    <span class="stat-pill block">拦截 ${num(s.blocked)}</span>
    <span class="stat-pill">通过率 ${num(s.pass_rate)}%</span>`;

  const gapsBox = $("#gapsBox");
  if (S.gaps && S.gaps.length) {
    gapsBox.hidden = false;
    gapsBox.innerHTML = `
      <h4>补证优先级（按能解锁的主张条数排序）</h4>
      ${S.gaps
        .map(
          (g, i) => `
        <div class="gap-item">
          <div class="gap-rank">${i + 1}</div>
          <div>
            <b>${esc(g.label)}</b> <span class="gap-count">可解锁 ${g.blocked_claims} 条</span>
            <p>${esc(g.how_to)}</p>
          </div>
        </div>`
        )
        .join("")}`;
  } else {
    gapsBox.hidden = true;
  }

  $("#claimList").innerHTML = S.claims
    .map((c) => {
      const pass = c.gate === "PASS";
      const checked = S.adopted.has(c.id);
      const risks = { high: "高", medium: "中", low: "低" };
      return `
      <div class="claim ${pass ? "pass" : "block"} ${checked ? "selected" : ""}" data-id="${esc(c.id)}">
        <div class="claim-check">
          <input type="checkbox" data-id="${esc(c.id)}" ${checked ? "checked" : ""} ${pass || c.override ? "" : "disabled"}>
        </div>
        <div class="claim-main">
          <div class="claim-top">
            <span class="claim-id">${esc(c.id)}</span>
            <span class="claim-text">${esc(c.claim)}</span>
          </div>
          ${c.why ? `<div class="claim-why">${esc(c.why)}</div>` : ""}
          <div class="claim-tags">
            <span class="tag risk-${esc(c.risk)}">建议风险 ${risks[c.risk] || "中"}</span>
            ${
              c.required_evidence.length
                ? c.required_evidence.map((r) => `<span class="tag ev">需要 · ${esc(EVIDENCE_LABEL[r] || r)}</span>`).join("")
                : `<span class="tag" style="background:var(--red-l);color:var(--red)">未声明所需证据</span>`
            }
            ${c.override ? `<span class="tag" style="background:var(--amber-l);color:var(--amber)">人工豁免</span>` : ""}
          </div>
          <div class="gate-reason"><b>门禁判定：</b>${esc(c.gate_reason)}</div>
          ${
            c.missing_detail && c.missing_detail.length
              ? `<div class="missing"><b>补齐这些材料后可用：</b><ul>${c.missing_detail
                  .map((m) => `<li>${esc(m.label)} — ${esc(m.how_to)}</li>`)
                  .join("")}</ul></div>`
              : ""
          }
        </div>
        <div class="claim-side">
          <span class="gate-badge ${pass ? "pass" : "block"}">${pass ? "通过" : "拦截"}</span>
          ${!pass && !c.override ? `<button class="mini danger" data-override="${esc(c.id)}">仍要使用</button>` : ""}
        </div>
      </div>`;
    })
    .join("");

  $$("#claimList input[type=checkbox]").forEach((cb) => {
    cb.onchange = () => {
      const id = cb.dataset.id;
      if (cb.checked) S.adopted.add(id);
      else S.adopted.delete(id);
      renderClaims();
    };
  });
  $$("#claimList [data-override]").forEach((b) => {
    b.onclick = () => overrideClaim(b.dataset.override);
  });

  $("#adoptHint").textContent = `已选 ${S.adopted.size} 条主张`;
  $("#btnContent").disabled = S.adopted.size === 0;
}

async function overrideClaim(id) {
  const c = S.claims.find((x) => x.id === id);
  if (!c) return;
  const reason = await askReason({
    title: `强行使用被拦截的主张 ${id}`,
    hint: "说明为什么在没有证据的情况下仍要使用它",
    placeholder: "例如：检测报告已送检未出结果，本批仅用于内部评审样稿，不对外发布",
  });
  if (!reason) return;
  try {
    await api("/api/decision", "POST", {
      record_id: S.recordId,
      action: "gate_override",
      target: id,
      reason,
      before: c.gate_reason,
      after: c.claim,
    });
    c.override = true;
    S.adopted.add(id);
    renderClaims();
    toast(`${id} 已人工豁免，理由已写入台账`, "ok");
  } catch (e) {
    toast(e.message, "err");
  }
}

/* ------------------------------------------------------------ Step 3 */

async function generateContent(regen = false) {
  if (!S.adopted.size) return toast("请至少勾选一条主张", "err");
  const btn = regen ? $("#btnRegen") : $("#btnContent");
  const restore = busy(btn, "生成中…");
  try {
    const data = await api("/api/content", "POST", { record_id: S.recordId, adopted: [...S.adopted] });
    S.content = { ...data.content };
    S.savedContent = { ...data.content };
    S.contentKind = "detail_page";
    $$("#contentSeg .seg-btn").forEach((b) => b.classList.toggle("active", b.dataset.kind === "detail_page"));
    renderEditor();
    $("#contentStats").innerHTML = `<span class="stat-pill">已采纳 ${S.adopted.size} 条主张</span>
      <span class="stat-pill">提示词 ${esc(data.prompt_version)}</span>`;
    if (data.llm_error) toast("模型调用失败，已回退演示样例：" + data.llm_error, "err");
    $("#panel-compliance").hidden = true;
    $("#panel-archive").hidden = true;
    stepPanel("panel-content", 3);
  } catch (e) {
    toast(e.message, "err");
  } finally {
    restore();
  }
}

function renderEditor() {
  const text = S.content[S.contentKind] || "";
  $("#editor").value = text;
  $("#editorCount").textContent = [...text].length + " 字";
  const dirty = text !== (S.savedContent[S.contentKind] || "");
  const state = $("#editorState");
  state.textContent = dirty ? "已修改，未记录（失焦后自动写入台账）" : "与生成结果一致";
  state.className = dirty ? "dirty" : "ok";
}

function onEditorInput() {
  const text = $("#editor").value;
  S.content[S.contentKind] = text;
  $("#editorCount").textContent = [...text].length + " 字";
  const dirty = text !== (S.savedContent[S.contentKind] || "");
  const state = $("#editorState");
  state.textContent = dirty ? "已修改，未记录（失焦后自动写入台账）" : "与生成结果一致";
  state.className = dirty ? "dirty" : "ok";
}

async function onEditorBlur() {
  const kind = S.contentKind;
  const now = S.content[kind] || "";
  const before = S.savedContent[kind] || "";
  if (now === before) return;
  const names = { detail_page: "商品详情页", oral_script: "口播稿", social_post: "社群文案" };
  try {
    await api("/api/decision", "POST", {
      record_id: S.recordId,
      action: "content_edit",
      target: names[kind],
      reason: "运营人工修改生成文案",
      before,
      after: now,
    });
    S.savedContent[kind] = now;
    renderEditor();
    toast(`${names[kind]} 的修改已写入台账`, "ok");
  } catch (e) {
    toast(e.message, "err");
  }
}

/* ------------------------------------------------------------ Step 4 */

function buildAuditOptions() {
  const opts = [];
  const gen = ["detail_page", "oral_script", "social_post"]
    .map((k) => S.content[k])
    .filter(Boolean)
    .join("\n\n");
  if (gen) opts.push({ key: "generated", label: "本次生成内容（三形态合并）", text: gen });
  if (S.product?.content_draft?.body)
    opts.push({ key: "draft", label: "产品原草稿", text: S.product.content_draft.body });
  if (S.caseMeta?.resolved_text)
    opts.push({ key: "case", label: `${S.caseMeta.prompt_version} 输出卖点`, text: S.caseMeta.resolved_text });
  return opts;
}

async function runCompliance(targetKey) {
  S.auditOptions = buildAuditOptions();
  if (!S.auditOptions.length) return toast("没有可审查的文本，请先生成内容", "err");
  if (targetKey) S.auditKey = targetKey;
  const opt = S.auditOptions.find((o) => o.key === S.auditKey) || S.auditOptions[0];
  S.auditKey = opt.key;

  const btn = targetKey ? $("#btnReCheck") : $("#btnCompliance");
  const restore = busy(btn, "审查中…");
  try {
    const data = await api("/api/compliance", "POST", { text: opt.text, record_id: S.recordId, with_llm: true });
    S.compliance = data;
    renderCompliance();
    $("#panel-archive").hidden = true;
    stepPanel("panel-compliance", 4);
  } catch (e) {
    toast(e.message, "err");
  } finally {
    restore();
  }
}

function renderCompliance() {
  const A = S.compliance.A;
  const B = S.compliance.B;
  const box = $("#scoreBox");
  const labels = { blocker: "不可发布", high: "高风险", medium: "需调整", pass: "通过" };
  box.innerHTML = `
    <div class="score-num ${esc(A.level)}">${A.score}<small>/100</small></div>
    <div class="score-label ${esc(A.level)}">${esc(labels[A.level] || A.level)}</div>`;

  $("#chNote").innerHTML = B && B.mode !== "web" && B.mode !== "error"
    ? `A 通道命中 ${A.hits.length} 项（规则库 ${esc(A.ruleset_version)}）｜B 通道补充 ${(B.findings || []).length} 项${B.demo ? "（演示样例）" : ""}`
    : `A 通道命中 ${A.hits.length} 项；B 通道未执行`;

  const sevLabel = { blocker: "一票否决", high: "高", medium: "中", low: "低", notice: "提示" };
  const rows = S.compliance.merged.rows;

  $("#hitList").innerHTML = rows.length
    ? rows
        .map((r, i) => {
          const sev = r.severity;
          return `
      <div class="hit ${esc(sev)}" data-i="${i}">
        <div class="hit-head">
          <span class="sev ${esc(sev)}">${esc(sevLabel[sev] || sev)}</span>
          <span class="ch-${r.source === "A" ? "a" : "b"}">${r.source === "A" ? "A 规则引擎" : "B 大模型"}</span>
          <span class="hit-title">${esc(r.title)}</span>
          ${r.dup ? `<span class="pill">与 A 通道重复</span>` : ""}
        </div>
        <div class="hit-q">“${esc(r.quote)}”</div>
        <div class="hit-detail"><b>依据：</b>${esc(r.detail)}</div>
        ${r.evidence_note ? `<div class="hit-detail" style="margin-top:4px"><b>证据：</b>${esc(r.evidence_note)}</div>` : ""}
        <div class="hit-advice"><b>建议改法：</b>${esc(r.advice)}</div>
        ${
          sev === "notice"
            ? ""
            : `<div class="hit-actions">
                 <button class="mini" data-fix="${i}">标记已整改</button>
                 <button class="mini danger" data-pass="${i}">强制通过（需理由）</button>
               </div>`
        }
      </div>`;
        })
        .join("")
    : `<div class="empty">规则库未命中任何风险。<br>但请记住：合规通过 ≠ 有说服力，这一步只排除风险，不负责打动人心。</div>`;

  // 审查目标切换 + 引用合规
  const switcher = S.auditOptions
    .map(
      (o) =>
        `<button class="mini ${o.key === S.auditKey ? "primary-solid" : ""}" data-audit="${esc(o.key)}">${esc(o.label)}</button>`
    )
    .join("");
  $("#chNote").innerHTML += `<div style="margin-top:9px">审查对象：${switcher}</div>`;

  $$("[data-audit]").forEach((b) => {
    b.onclick = () => runCompliance(b.dataset.audit);
  });

  const cite = $("#citations");
  if (A.citations_ok && A.citations_ok.length) {
    cite.hidden = false;
    cite.innerHTML = `<h4>已合规引证的数据 ${A.citations_ok.length} 处（规则第四条：引证须标明出处）</h4>
      <ul>${A.citations_ok.map((c) => `<li>“${esc(c.matched)}” — ${esc(c.note)}</li>`).join("")}</ul>`;
  } else {
    cite.hidden = true;
  }

  const unresolved = rows.filter((r) => r.severity !== "notice").length;
  $("#complianceHint").innerHTML = unresolved
    ? `待处理风险 <b>${unresolved}</b> 项（整改或留痕后可归档）`
    : "未发现待处理风险，可归档";

  $$("[data-fix]").forEach((b) => {
    b.onclick = () => markTrend(b, "fix_compliance", "已整改");
  });
  $$("[data-pass]").forEach((b) => {
    b.onclick = () => markTrend(b, "compliance_override", "强制通过");
  });
}

async function markTrend(btn, action, label) {
  const i = Number(btn.dataset.fix ?? btn.dataset.pass);
  const row = S.compliance.merged.rows[i];
  if (!row) return;
  let reason = "已按建议修改文案";
  if (action === "compliance_override") {
    reason = await askReason({
      title: `强制通过风险项：${row.title}`,
      hint: "说明为什么这一条可以不改",
      placeholder: "例如：该表述引用自标准原文，已核对 GB/T 18965-2008 第 5.5 条，不构成绝对化用语",
    });
    if (!reason) return;
  }
  try {
    await api("/api/decision", "POST", {
      record_id: S.recordId,
      action,
      target: row.title,
      reason,
      before: row.quote,
      after: label,
    });
    btn.closest(".hit").classList.add("resolved");
    btn.closest(".hit").querySelectorAll("button").forEach((x) => (x.disabled = true));
    toast(`${label}已留痕：${row.title}`, "ok");
  } catch (e) {
    toast(e.message, "err");
  }
}

/* ------------------------------------------------------------ 归档 */

async function archive() {
  const A = S.compliance?.A;
  if (!A) return toast("请先执行合规审查", "err");
  const reason = `合规判定：${A.level_text}；已选主张 ${S.adopted.size} 条`;
  try {
    const data = await api("/api/decision", "POST", {
      record_id: S.recordId,
      action: "archive",
      target: S.product.product.name,
      reason,
      after: S.content,
    });
    renderDecisions(data.record.decisions);
    $("#archiveStats").innerHTML = `<span class="stat-pill">${esc(data.record.status)}</span>
      <span class="stat-pill">${esc(data.record.id)}</span>
      <span class="stat-pill">人工干预 ${data.record.decisions.length} 次</span>`;
    stepPanel("panel-archive", 4);
    toast("已归档，台账已更新", "ok");
  } catch (e) {
    toast(e.message, "err");
  }
}

function renderDecisions(list) {
  const label = {
    adopt_claim: "采纳主张",
    reject_claim: "驳回主张",
    gate_override: "门禁强行放行",
    content_edit: "人工修改文案",
    compliance_override: "合规风险强制通过",
    fix_compliance: "标记整改完成",
    archive: "归档发布",
  };
  $("#decisionList").innerHTML = list.length
    ? list
        .map(
          (d) => `
      <div class="decision">
        <span class="d-seq">${d.seq}</span>
        <div>
          <span class="d-act">${esc(label[d.action] || d.action)}</span>
          <span class="tiny"> · ${esc(d.target)} · ${esc(d.at)}</span>
          ${d.reason ? `<div class="d-reason">理由：${esc(d.reason)}</div>` : ""}
        </div>
      </div>`
        )
        .join("")
    : `<div class="empty">本次运行没有人工干预记录</div>`;
}

async function exportRecord(format) {
  try {
    const data = await api("/api/export", "POST", { record_id: S.recordId, format });
    download(data.filename, data.text, data.mime);
    toast("已导出 " + data.filename, "ok");
  } catch (e) {
    toast(e.message, "err");
  }
}

/* ------------------------------------------------------------ 规则库 */

let rulesLoaded = false;
async function loadRules() {
  if (rulesLoaded) return;
  try {
    const data = await api("/api/compliance/rules");
    $("#rulesMeta").textContent = `规则库版本 ${data.version}，共 ${data.rules.length} 条规则，全部条目注明法规出处。`;
    $("#ruleSources").innerHTML = data.sources
      .map((s) => `<a class="source" href="${esc(s.url || "#")}" target="_blank" rel="noopener">${esc(s.name)}</a>`)
      .join("");
    const sevLabel = { blocker: "一票否决", high: "高", medium: "中", low: "低" };
    $("#ruleList").innerHTML = data.rules
      .map(
        (r) => `
      <div class="rule">
        <div class="rule-head">
          <span class="rule-id">${esc(r.id)}</span>
          <span class="rule-name">${esc(r.name)}</span>
          <span class="sev ${esc(r.severity)}">${esc(sevLabel[r.severity] || r.severity)}</span>
          <span class="pill">${esc(r.category)}</span>
        </div>
        <div class="rule-basis">依据：${esc(r.basis)}</div>
        ${
          r.terms && r.terms.length
            ? `<div class="rule-terms">${r.terms.map((t) => `<span>${esc(t)}</span>`).join("")}</div>`
            : ""
        }
        ${r.context_note ? `<div class="rule-basis">说明：${esc(r.context_note)}</div>` : ""}
        <div class="rule-advice">建议改法：${esc(r.advice)}</div>
      </div>`
      )
      .join("");
    rulesLoaded = true;
  } catch (e) {
    toast(e.message, "err");
  }
}

/* ------------------------------------------------------------ 提示词 */

let promptsLoaded = false;
async function loadPrompts() {
  if (promptsLoaded) return;
  try {
    const ids = ["claim_gen", "content_gen"];
    const groups = [];
    for (const id of ids) {
      const data = await api("/api/prompts/" + id);
      groups.push(data.prompt);
    }
    $("#promptList").innerHTML = groups
      .map(
        (g) => `
      <div class="prompt-group">
        <h3>${esc(g.name)} <small>当前版本 ${esc(g.current)}</small></h3>
        ${g.versions
          .map(
            (v) => `
          <div class="ver ${v.retired ? "" : "current"}">
            <div class="ver-head">
              <span class="ver-tag ${v.retired ? "retired" : ""}">${esc(v.version)}</span>
              <span class="ver-date">${esc(v.date)}</span>
              <span class="pill">${v.chars} 字符</span>
              ${v.retired ? `<span class="pill">已退役</span>` : `<span class="pill pass">在用</span>`}
            </div>
            <div class="ver-changelog">${esc(v.changelog)}</div>
            ${v.retired ? `<div class="ver-retired"><b>退役原因：</b>${esc(v.retired_reason)}</div>` : ""}
            <details class="prompt-text"><summary>展开提示词全文</summary><pre>${esc(v.prompt_text)}</pre></details>
          </div>`
          )
          .join("")}
      </div>`
      )
      .join("");
    promptsLoaded = true;
  } catch (e) {
    toast(e.message, "err");
  }
}

/* ------------------------------------------------------------ 台账 */

async function loadLedger() {
  try {
    const data = await api("/api/ledger");
    const st = data.stats;
    $("#statCards").innerHTML = `
      <div class="stat-card"><span>运行次数</span><b>${st.runs}</b></div>
      <div class="stat-card"><span>已归档</span><b>${st.released}</b></div>
      <div class="stat-card"><span>通过门禁的主张</span><b>${st.passed_claims}</b></div>
      <div class="stat-card em"><span>被拦截的主张</span><b>${st.blocked_claims}</b></div>
      <div class="stat-card em"><span>拦截率</span><b>${st.block_rate}%</b></div>
      <div class="stat-card"><span>人工干预</span><b>${st.decision_count}</b></div>`;

    $("#ledgerTable").innerHTML = data.records.length
      ? `<table>
          <thead><tr><th>运行编号</th><th>产品</th><th>时间</th><th>模式</th><th>门禁</th><th>合规</th><th>干预</th><th>状态</th><th></th></tr></thead>
          <tbody>${data.records
            .map((r) => {
              const gs = r.gate_summary || {};
              const lvl = r.compliance_level || "";
              return `<tr>
                <td><b>${esc(r.id)}</b><div class="tiny">主张提示词 ${esc(r.claim_gen_version || "—")}</div></td>
                <td>${esc(r.product_name)}</td>
                <td class="tiny">${esc(r.created_at)}</td>
                <td><span class="pill ${r.mode === "live" ? "live" : ""}">${r.mode === "web" ? "网页提取" : r.mode === "live" ? "真实调用" : r.mode === "fallback" ? "降级" : "演示"}</span></td>
                <td class="tiny">${num(gs.passed)}/${num(gs.total)}</td>
                <td>${lvl ? `<span class="pill ${esc(lvl)}">${esc(lvl)}</span>` : "—"}</td>
                <td class="tiny">${r.decisions}</td>
                <td><span class="pill ${r.status === "已归档" ? "pass" : ""}">${esc(r.status)}</span></td>
                <td style="white-space:nowrap">
                  <button class="mini" data-view="${esc(r.id)}">详情</button>
                  <button class="mini" data-md="${esc(r.id)}">MD</button>
                </td>
              </tr>`;
            })
            .join("")}</tbody>
        </table>`
      : `<div class="empty">还没有运行记录。回到工作台跑一次，这里会自动留痕。</div>`;

    $$("[data-view]").forEach((b) => (b.onclick = () => viewRecord(b.dataset.view)));
    $$("[data-md]").forEach(
      (b) =>
        (b.onclick = async () => {
          const d = await api("/api/export", "POST", { record_id: b.dataset.md, format: "md" });
          download(d.filename, d.text, d.mime);
        })
    );
  } catch (e) {
    toast(e.message, "err");
  }
}

async function viewRecord(id) {
  try {
    const { record } = await api("/api/ledger/" + id);
    const content = record.final_content || record.content || {};
    const body = `
      <div class="field"><label>${esc(record.product_name)} · ${esc(record.created_at)} · ${esc(record.status)}</label>
        <div class="tiny">模式：${esc(record.mode)}｜提示词：主张生成 ${esc(record.prompt_versions.claim_gen || "—")}</div></div>
      <div class="field"><label>处理过程</label>
        <div class="tiny">${(record.stages || [])
          .map((s) => `${esc(s.stage)} · ${esc(s.at)}`)
          .join("<br>") || "—"}</div></div>
      <div class="field"><label>门禁</label>
        <div class="tiny">通过 ${num(record.gate_summary?.passed)} / 共 ${num(record.gate_summary?.total)} 条</div></div>
      ${content.detail_page ? `<div class="field"><label>详情页</label><div class="tiny" style="white-space:pre-wrap;color:var(--ink-2)">${esc(content.detail_page)}</div></div>` : ""}
      <div class="field"><label>人工干预（${(record.decisions || []).length} 次）</label>
        <div class="tiny">${(record.decisions || [])
          .map((d) => `#${d.seq} ${esc(d.action)} · ${esc(d.target)}${d.reason ? "：" + esc(d.reason) : ""}`)
          .join("<br>") || "无"}</div></div>`;
    await showModal({
      title: "运行详情 " + id,
      body,
      actions: [
        { label: "导出 Markdown", value: "md" },
        { label: "关闭", value: null, primary: true },
      ],
    }).then(async (v) => {
      if (v === "md") {
        const d = await api("/api/export", "POST", { record_id: id, format: "md" });
        download(d.filename, d.text, d.mime);
      }
    });
  } catch (e) {
    toast(e.message, "err");
  }
}

/* ------------------------------------------------------------ 设置 */

async function openSettings() {
  try {
    const cfg = await api("/api/config");
    const value = await showModal({
      title: "网页数据源设置",
      subtitle: "无需 API Key。设置仅对当前浏览器生效。",
      body: '<div class="field"><label>公开商品页或资料页地址</label>' +
        '<input id="cfgWeb" type="url" value="' + esc(cfg.web_url) + '">' +
        '<div class="help">使用 http:// 或 https:// 地址，不支持登录页、验证码或仅动态加载的网页。</div></div>',
      actions: [{label:"取消",value:null},{label:"保存",value:"save",primary:true}],
      collect: (root, action) => action === "save" ? {web_url:$("#cfgWeb",root).value.trim()} : null,
    });
    if (!value) return;
    S.config = await api("/api/config", "POST", value);
    setModeBadge(S.config);
    toast("当前浏览器的网页来源已保存", "ok");
  } catch (e) { toast(e.message, "err"); }
}

/* ------------------------------------------------------------ 启动 */

const EVIDENCE_LABEL = {
  GI_CERT: "地理标志授权",
  TEST_REPORT: "第三方检测报告",
  ORIGIN_PROOF: "产地与种植记录",
  PROCESS_RECORD: "工艺记录",
  GRADE_STANDARD: "等级判定依据",
  GREEN_CERT: "绿色食品认证",
  PRICE_REF: "价格对比依据",
  SALES_DATA: "销量数据",
  USER_FEEDBACK: "用户反馈",
};

init();
