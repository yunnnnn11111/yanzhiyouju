/* Evidence drafts contain no API credentials. Search hits never confirm evidence. */
const EvidenceUI = {results:[],busy:false};
const EvidenceWords = {GI_CERT:'地理标志 保护范围',ORIGIN_PROOF:'产地 种植记录',PROCESS_RECORD:'种植 工艺',TEST_REPORT:'检测报告 农残 糖度',GRADE_STANDARD:'等级 果径 标准',GREEN_CERT:'绿色食品 证书',PRICE_REF:'同规格 价格',USER_FEEDBACK:'买家 评价',SALES_DATA:'销量 复购'};
function evidenceDraftKey() { return 'yzyj-evidence-v1:'+S.product.id; }
function cacheEvidence() {
  try { localStorage.setItem(evidenceDraftKey(),JSON.stringify({at:Date.now(),evidence:S.evidence})); }
  catch(e) { $('#evidenceSaveStatus').textContent='本机草稿未保存，请立即导出备份。'; }
}
function restoreEvidenceDraft() {
  try {
    const saved=JSON.parse(localStorage.getItem(evidenceDraftKey())||'null');
    if(saved && Array.isArray(saved.evidence) && saved.at > Date.parse(S.product.evidence_updated_at||'1970-01-01')) {
      const rows=new Map(saved.evidence.map(e=>[e.type,e]));
      S.evidence=S.evidence.map(e=>rows.has(e.type)?{...e,...rows.get(e.type),label:e.label}:e);
      $('#evidenceSaveStatus').textContent='已恢复本机材料草稿；生成时会保存到当前访客。';
    }
  } catch(e) { $('#evidenceSaveStatus').textContent='本机草稿无法读取，请从备份恢复或重新填写。'; }
}
function initEvidenceWorkspace() {
  S.evidence=S.evidence.map(e=>!e.provided && !e.updated_at?{...e,detail:'',source:'',url:'',confirmed:false}:e);
  restoreEvidenceDraft();
  EvidenceUI.results=[];
  $('#searchQuery').value=S.product.product.name.replace(/[（(].*?[）)]/g,'');
  $('#searchType').value='';
  $('#searchResults').innerHTML='';
  $('#searchStatus').textContent='输入产品名、企业名或证书编号，检索公开来源；不会自动勾选证据。';
  $('#btnSearchEvidence').onclick=searchEvidence;
  $('#searchQuery').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();searchEvidence();}};
  $('#btnSaveEvidence').onclick=()=>saveEvidenceDrafts();
  $('#btnBackupWorkspace').onclick=backupWorkspace;
  $('#btnImportEvidence').onclick=()=>$('#evidenceImport').click();
  $('#evidenceImport').onchange=importEvidenceBackup;
}
function updateEvidenceCard(kind) {
  const e=S.evidence.find(x=>x.type===kind), card=$(`[data-evidence-card="${kind}"]`);
  card.classList.toggle('on',e.provided);card.classList.toggle('off',!e.provided);
  $('.ev-state',card).textContent=e.provided?'已确认用于本次运行':e.detail?'材料草稿 · 待核验':'可填写材料或联网匹配';
  $('.ev-confirm',card).checked=!!e.provided;
  updateSetupHint();
}
function renderEvidenceEditor() {
  $('#evidenceGrid').innerHTML=S.evidence.map(e=>`<article class="ev-card evidence-editor ${e.provided?'on':'off'}" data-evidence-card="${esc(e.type)}">
    <div class="ev-heading"><b>${esc(e.label)}</b><span class="ev-state">${e.provided?'已确认用于本次运行':e.detail?'材料草稿 · 待核验':'可填写材料或联网匹配'}</span></div>
    <label>材料内容<textarea data-field="detail" rows="3" maxlength="4000" placeholder="填写报告结论、证书编号、反馈原文或销量口径等">${esc(e.detail||'')}</textarea></label>
    <label>材料来源<input data-field="source" maxlength="500" value="${esc(e.source==='—'?'':e.source||'')}" placeholder="出具机构、店铺或记录名称"></label>
    <label>来源网页<input data-field="url" type="url" maxlength="2048" value="${esc(e.url||'')}" placeholder="https://…（可选，可直接提取）"></label>
    <div class="ev-buttons"><button class="ghost" data-action="search">联网匹配</button><button class="ghost" data-action="extract">提取此链接</button><button class="ghost" data-action="save">保存材料</button></div>
    <label class="ev-confirm-label"><input type="checkbox" class="ev-confirm" ${e.provided?'checked':''}>我已核对材料与本产品或批次相符，用于本次运行</label>
    <small class="ev-provenance">${esc(e.fetched_at?'抓取时间：'+e.fetched_at:'网页匹配为线索，检测、认证及经营数据须核验原始材料。')}</small>
  </article>`).join('');
  $$('#evidenceGrid [data-evidence-card]').forEach(card=>{
    const kind=card.dataset.evidenceCard,e=S.evidence.find(x=>x.type===kind);
    $$('[data-field]',card).forEach(input=>input.oninput=()=>{
      e[input.dataset.field]=input.value;e.provided=false;e.confirmed=false;e.verified=false;e.origin='manual';
      cacheEvidence();updateEvidenceCard(kind);$('#evidenceSaveStatus').textContent='材料已改动并保存在本机草稿，需重新确认并保存。';
    });
    $('.ev-confirm',card).onchange=event=>{
      if(event.target.checked && (String(e.detail||'').trim().length<6 || (!String(e.url||'').trim() && !String(e.source||'').trim()))){
        event.target.checked=false;toast('请先填写材料内容和来源，再确认使用。','err');return;
      }
      e.provided=event.target.checked;e.confirmed=event.target.checked;cacheEvidence();updateEvidenceCard(kind);
    };
    $('[data-action="search"]',card).onclick=()=>{
      $('#searchType').value=kind;$('#searchQuery').value=S.product.product.name.replace(/[（(].*?[）)]/g,'')+' '+EvidenceWords[kind];
      $('#evidenceSearch').scrollIntoView({behavior:'smooth',block:'start'});searchEvidence();
    };
    $('[data-action="extract"]',card).onclick=()=>previewEvidence({evidence_type:kind,url:e.url});
    $('[data-action="save"]',card).onclick=()=>saveEvidenceDrafts(kind);
  });
  updateSetupHint();
}
async function saveEvidenceDrafts(kind) {
  const rows=kind?S.evidence.filter(e=>e.type===kind):S.evidence;
  try {
    const result=await api('/api/evidence/save','POST',{product_id:S.product.id,evidence:rows});
    const updated=new Map(result.evidence.map(e=>[e.type,e]));
    S.evidence=S.evidence.map(e=>(!kind||kind===e.type)?updated.get(e.type)||e:e);
    cacheEvidence();renderEvidenceEditor();
    $('#evidenceSaveStatus').textContent='已保存到当前访客和本机草稿。免费服务器记录请另行导出备份。';
    toast('材料已保存','ok');
  } catch(e){toast(e.message,'err');}
}
async function searchEvidence(){
  if(EvidenceUI.busy)return;EvidenceUI.busy=true;
  const restore=busy($('#btnSearchEvidence'),'检索中…');
  $('#searchStatus').textContent='正在检索公开网页并按材料类型匹配…';
  EvidenceUI.results=[];$('#searchResults').innerHTML='';
  try{
    const data=await api('/api/search','POST',{product_id:S.product.id,query:$('#searchQuery').value.trim(),evidence_type:$('#searchType').value});
    EvidenceUI.results=data.results;
    $('#searchStatus').textContent=`${data.engine} · ${data.results.length} 条候选来源 · ${new Date(data.searched_at).toLocaleString('zh-CN')}。请核对后提取。`;
    renderEvidenceResults();
  }catch(e){$('#searchStatus').textContent=e.message;}finally{EvidenceUI.busy=false;restore();}
}
function renderEvidenceResults(){
  const selected=$('#searchType').value;
  $('#searchResults').innerHTML=EvidenceUI.results.map((r,i)=>{
    const kinds=r.matched_types||[];const target=selected||kinds[0]||'GI_CERT';
    return `<article class="search-result"><a href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">${esc(r.title)}</a><p>${esc(r.snippet)}</p>
    <small>${esc(r.host)} · ${r.product_match?'含产品关键词':'主体关联待核对'} · ${kinds.length?'匹配：'+kinds.map(k=>esc(EVIDENCE_LABEL[k]||k)).join('、'):'未匹配到具体类型'}</small>
    <div class="ev-buttons"><select aria-label="来源 ${i+1} 填入证据类型" data-target="${i}">${S.evidence.map(e=>`<option value="${e.type}" ${e.type===target?'selected':''}>${esc(e.label)}</option>`).join('')}</select><button class="ghost" data-extract-result="${i}">提取并预览</button></div></article>`;
  }).join('');
  $$('[data-extract-result]').forEach(btn=>btn.onclick=()=>{const i=Number(btn.dataset.extractResult);previewEvidence({candidate_id:EvidenceUI.results[i].id,evidence_type:$(`[data-target="${i}"]`).value});});
}
async function previewEvidence(payload){
  const kind=payload.evidence_type;
  if(!payload.candidate_id && !String(payload.url||'').trim()){toast('请先填写来源网页链接','err');return;}
  if(EvidenceUI.busy)return;EvidenceUI.busy=true;$('#searchStatus').textContent='正在读取来源正文…';
  try{
    const result=await api('/api/evidence/extract','POST',{product_id:S.product.id,...payload}),draft=result.draft;
    const choice=await showModal({title:'核对来源后填入材料',subtitle:result.notice,
      body:`<p><b>${esc(draft.source)}</b></p><p><a href="${esc(draft.url)}" target="_blank" rel="noopener noreferrer">打开原网页</a></p><pre class="source-preview">${esc(draft.detail)}</pre><p class="help">${result.matched?'已找到相关关键词。':'未找到该类材料关键词，请特别核对相关性。'}填入会替换此项内容，并取消该项已确认状态。</p>`,
      actions:[{label:'取消',value:null},{label:'填入此项，保留待核验',value:'use',primary:true}]});
    if(choice==='use'){S.evidence=S.evidence.map(e=>e.type===kind?{...e,...draft}:e);cacheEvidence();renderEvidenceEditor();$('#searchStatus').textContent='已填入材料草稿；请补充批次、编号或有效期，核对后勾选确认并保存。';}
    else $('#searchStatus').textContent='未修改材料，可继续选择来源。';
  }catch(e){$('#searchStatus').textContent=e.message;toast(e.message,'err');}finally{EvidenceUI.busy=false;}
}
async function backupWorkspace(){
  let server=null,notice='';
  try{server=await api('/api/workspace/backup');}catch(e){notice='服务器记录未能导出；此次备份只含当前材料草稿。';}
  const backup={format:'yzyj-evidence-backup-v1',exported_at:new Date().toISOString(),product_id:S.product.id,evidence:S.evidence,workspace:server};
  download('言之有据-工作台备份-'+new Date().toISOString().slice(0,10)+'.json',JSON.stringify(backup,null,2),'application/json');
  toast(notice||'已导出材料及当前访客运行记录，不含 API Key',notice?'err':'ok');
}
async function importEvidenceBackup(event){
  const file=event.target.files[0];if(!file)return;
  try{
    if(file.size>5*1024*1024)throw Error('备份文件超过 5MB');
    const data=JSON.parse(await file.text());
    if(data.format!=='yzyj-evidence-backup-v1'||data.product_id!==S.product.id||!Array.isArray(data.evidence))throw Error('请选择当前产品的材料备份文件');
    const choice=await showModal({title:'恢复材料备份',body:'将把备份中的材料恢复到当前访客。此操作不导入 API 密钥，不恢复历史台账。',actions:[{label:'取消',value:null},{label:'恢复材料',value:'restore',primary:true}]});
    if(choice!=='restore')return;
    const result=await api('/api/evidence/save','POST',{product_id:S.product.id,evidence:data.evidence});
    S.evidence=result.evidence;cacheEvidence();renderEvidenceEditor();toast('材料已恢复','ok');
  }catch(e){toast(e.message,'err');}finally{event.target.value='';}
}
