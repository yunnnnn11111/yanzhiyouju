(function () {
  const parts = location.pathname.split("/").filter(Boolean);
  const id = (parts[1] || "").toUpperCase();
  const code = new URLSearchParams(location.search).get("k") || "";
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  function fail(msg) {
    document.getElementById("title").textContent = "这个链接打不开";
    document.getElementById("lead").textContent = msg;
  }

  if (!/^BAT-[A-Z0-9-]{8,40}$/.test(id)) { fail("批次编号格式不对。"); return; }

  fetch("/api/trace/" + encodeURIComponent(id) + "?k=" + encodeURIComponent(code), { headers: { Accept: "application/json" } })
    .then((res) => res.json().then((data) => ({ res, data })))
    .then(({ res, data }) => {
      if (!res.ok) { fail(data && data.error ? data.error : "没有找到这一批的公开记录。"); return; }
      const p = data.product || {};
      const s = data.summary || {};
      document.getElementById("title").textContent = (p["产品"] || "这一批农产品") + " · 批次溯源";
      const qrBox = document.getElementById("qrBox");
      const qrImg = document.getElementById("qrImg");
      qrImg.src = "/api/trace/" + encodeURIComponent(id) + "/qr.svg?v=1&k=" + encodeURIComponent(code);
      if (qrBox) qrBox.hidden = false;
      document.getElementById("lead").textContent =
        "产地 " + (p["产地"] || "未填写") + "，本批 " + (p["本批重量"] == null ? "—" : p["本批重量"] + " kg") +
        "。以下信息由生产主体提交，「言之有据」按证据逐条核对，缺的、过期的都照实标注。";

      let html = "";
      html += '<section class="card"><h2>这一批是什么</h2><dl class="kv">';
      Object.keys(p).forEach((k) => { html += "<dt>" + esc(k) + "</dt><dd>" + esc(p[k]) + "</dd>"; });
      html += "<dt>批次编号</dt><dd><code>" + esc(data.batch_id) + "</code></dd>";
      html += "<dt>建档时间</dt><dd>" + esc((data.created_at || "").replace("T", " ").slice(0, 16)) + "</dd>";
      html += "</dl></section>";

      html += '<section class="card"><h2>核对结果</h2><div class="stats">';
      html += '<div class="stat"><b>' + (s.evidence_provided || 0) + " / " + (s.evidence_total || 0) + '</b><span>证据已提供</span></div>';
      html += '<div class="stat"><b>' + (s.claims_passed || 0) + " / " + (s.claims_total || 0) + '</b><span>宣传主张已通过</span></div>';
      html += '<div class="stat"><b>' + (s.claims_blocked || 0) + '</b><span>被拦下的主张</span></div>';
      html += '<div class="stat"><b>' + (s.compliance_blocked ? "有风险" : "未见高风险") + "</b><span>合规筛查</span></div>";
      html += "</div></section>";

      html += '<section class="card"><h2>逐条证据</h2>';
      if (!(data.evidence || []).length) { html += '<p class="empty">这一批还没有录入证据。</p>'; }
      (data.evidence || []).forEach((e) => {
        const ok = e.status === "verified";
        html += '<div class="ev"><div><div class="name">' + esc(e.label || e.type) + "</div>" +
          (e.detail ? '<div class="note">' + esc(e.detail) + "</div>" : "") +
          (e.sha256 ? '<div class="note">SHA-256 <code>' + esc(e.sha256) + "</code></div>" : "") +
          (e.verification_note ? '<div class="note">核验备注：' + esc(e.verification_note) + "</div>" : "") +
          "</div><div><span class=\"tag " + (ok ? "ok" : "bad") + '">' + esc(e.status_text) + "</span></div></div>";
      });
      html += "</section>";

      if ((data.media || []).length) {
        html += '<section class="card"><h2>现场材料</h2>';
        data.media.forEach((m) => {
          html += '<div class="ev"><div><div class="name">' + esc(m.caption || m.name) + "</div>" +
            (m.sha256 ? '<div class="note">SHA-256 <code>' + esc(m.sha256) + "</code></div>" : "") + "</div></div>";
        });
        html += "</section>";
      }

      const integ = data.integrity || {};
      html += '<section class="card"><h2>可核验指纹</h2><dl class="kv">';
      html += "<dt>档案哈希</dt><dd><code>" + esc(integ.archive_sha256 || "—") + "</code></dd>";
      html += "<dt>档案大小</dt><dd>" + (integ.archive_bytes || 0) + " 字节</dd>";
      html += "<dt>生成时间</dt><dd>" + esc((data.generated_at || "").replace("T", " ").slice(0, 19)) + " UTC</dd>";
      html += "</dl></div></section>";
      document.getElementById("body").innerHTML = html;
      document.getElementById("foot").textContent = data.notice || "";
    })
    .catch(() => fail("网络异常，暂时读不到这一批的记录。"));
})();
