(function () {
  const parts = location.pathname.split("/").filter(Boolean);
  const id = (parts[1] || "").toUpperCase();
  const code = new URLSearchParams(location.search).get("k") || "";
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  function fail(msg) {
    document.getElementById("title").textContent = "这个链接打不开";
    document.getElementById("lead").textContent = msg;
  }

  if (!/^BAT-[A-Z0-9-]{8,40}$/.test(id)) { fail("批次编号格式不对。"); return; }

  fetch("/api/trace/" + encodeURIComponent(id) + "?k=" + encodeURIComponent(code), { headers: { Accept: "application/json" } })
    .then((res) => res.json().then((data) => ({ res, data })))
    .then(({ res, data }) => {
      if (!res.ok) { fail(data && data.error ? data.error : "没有找到这一批的公开记录。"); return; }
      const p = data.product || {};
      const s = data.summary || {};
      document.getElementById("title").textContent = (p["产品"] || "这一批农产品") + " · 批次溯源";
      const qrBox = document.getElementById("qrBox");
      const qrImg = document.getElementById("qrImg");
      qrImg.src = "/api/trace/" + encodeURIComponent(id) + "/qr.svg?v=1&k=" + encodeURIComponent(code);
      if (qrBox) qrBox.hidden = false;
      document.getElementById("lead").textContent =
        "产地 " + (p["产地"] || "未填写") + "，本批 " + (p["本批重量"] == null ? "—" : p["本批重量"] + " kg") +
        "。以下信息由生产主体提交。";

      let html = "";
      html += '<section class="card"><h2>这一批是什么</h2><dl class="kv">';
      Object.keys(p).forEach((k) => { html += "<dt>" + esc(k) + "</dt><dd>" + esc(p[k]) + "</dd>"; });
      html += "<dt>批次编号</dt><dd><code>" + esc(data.batch_id) + "</code></dd>";
      html += "<dt>建档时间</dt><dd>" + esc((data.created_at || "").replace("T", " ").slice(0, 16)) + "</dd>";
      html += "</dl></section>";
      document.getElementById("body").innerHTML = html;
      document.getElementById("foot").textContent = data.notice || "";
    })
    .catch(() => fail("网络异常，暂时读不到这一批的记录。"));
})();
